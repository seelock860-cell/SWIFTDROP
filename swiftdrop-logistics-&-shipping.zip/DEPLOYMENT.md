# SWIFTDROP – Logistics & Shipping Platform
## Deployment & Supabase Setup Guide

This document details how to connect Supabase and deploy SWIFTDROP to **Cloudflare Pages**.

---

### 1. Project Architecture Overview

- **Framework**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS v4 + Plus Jakarta Sans Typography
- **Icons**: Lucide React
- **Payment Architecture**: Strict manual bank transfer with receipt upload and manual administrator review (no third-party card processors per security requirements).
- **Database**: Supabase (PostgreSQL with Row Level Security)
- **Deployment Target**: Cloudflare Pages (SPA configuration with `public/_redirects` and `public/_headers`)

---

### 2. Setting Up Supabase Database

1. Sign in to your [Supabase Dashboard](https://supabase.com).
2. Create a new project (e.g. `swiftdrop-logistics`).
3. Open the **SQL Editor** in the left sidebar.
4. Copy the complete SQL script located in `/supabase/schema.sql` and run it. This creates:
   - `profiles` (Auth profiles)
   - `customers` (Client directory)
   - `bank_settings` (Manual bank transfer accounts)
   - `delivery_pricing` (Local, nationwide, and international rates)
   - `bookings` (Unique tracking numbers e.g. `SWD-2026-XXXXX`)
   - `deliveries` (Couriers and arrival times)
   - `tracking_history` (Checkpoint milestones)
   - `payments` (Manual receipts and audit logs)
   - `admin_users` (Auditors)
   - `website_settings` (Contact numbers & WhatsApp)
   - Row Level Security (RLS) policies for protected records
5. Navigate to **Project Settings** → **API**.
6. Copy:
   - **Project URL**
   - **anon / public key**

---

### 3. Environment Variables Configuration

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Set the following variables:

```ini
VITE_SUPABASE_URL="https://your-project-id.supabase.co"
VITE_SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.your-anon-key-here"
VITE_WHATSAPP_NUMBER="2349024971419"
VITE_COMPANY_EMAIL="support@swiftdrop.ng"
VITE_COMPANY_PHONE="+234 902 497 1419"
APP_URL="https://swiftdrop.pages.dev"
```

*Note: If Supabase credentials are not yet supplied, SWIFTDROP automatically runs in persistent local browser storage mode, allowing immediate client booking, receipt upload, and admin audit testing without any blocking errors.*

---

### 4. Admin Access Details

- **Admin Login Route**: `/` → click **Admin Portal** or navigate directly via `#admin-login`
- **Initial Setup Username**: `swift`
- **Initial Setup Password**: `swift234`

Admin capabilities:
- **Bank Transfer Settings**: Update Bank Name, Account Name, and Account Number. Changes update the customer checkout page in real time.
- **Payment Verification**: Review uploaded receipts in high-resolution, approve payments, or reject with a custom message.
- **Tracking Checkpoints**: Add waypoint milestones with location stamps and operational notes.
- **Rate Management**: Adjust base fares and per-kg pricing for local, nationwide, and international tiers.

---

### 5. Deploying to Cloudflare Pages

SWIFTDROP is pre-configured specifically for Cloudflare Pages:

1. Push your repository to **GitHub** or **GitLab**.
2. Go to the [Cloudflare Dashboard](https://dash.cloudflare.com/) → **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**.
3. Select your SWIFTDROP repository.
4. Set Build Settings:
   - **Framework preset**: `Vite`
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
   - **Root directory**: `/`
5. Under **Environment variables**, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_WHATSAPP_NUMBER`
6. Click **Save and Deploy**.

#### Why SPA Routing Works on Cloudflare Pages
The repository includes `public/_redirects`:
```
/*    /index.html   200
```
This instructs Cloudflare Pages edge servers to route all deep links (e.g., `/track-package`, `/admin-dashboard`, `/checkout`) to `index.html` with a 200 HTTP status, eliminating 404 errors on browser page reloads.

---

### 6. Local Testing & Verification

```bash
# Install dependencies
npm install

# Test production build
npm run build

# Start dev server
npm run dev
```
