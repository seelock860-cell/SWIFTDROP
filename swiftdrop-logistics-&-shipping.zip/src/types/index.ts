export type UserRole = 'customer' | 'admin' | 'superadmin';

export type DeliveryType = 'local' | 'nationwide' | 'international';

export type PackageCategory = 
  | 'documents' 
  | 'parcel' 
  | 'electronics' 
  | 'fashion' 
  | 'fragile' 
  | 'perishables' 
  | 'industrial';

export type DeliveryStatus = 
  | 'Booking Received'
  | 'Payment Pending'
  | 'Payment Confirmed'
  | 'Package Picked Up'
  | 'In Transit'
  | 'Arrived at Destination'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled';

export type PaymentStatus = 
  | 'Awaiting Payment'
  | 'Receipt Submitted'
  | 'Under Verification'
  | 'Payment Approved'
  | 'Payment Rejected';

export interface Profile {
  id: string;
  email: string;
  fullName: string;
  phone: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  role: UserRole;
  createdAt: string;
}

export interface Customer {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  companyName?: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  totalBookings: number;
  totalSpent: number;
  createdAt: string;
}

export interface Booking {
  id: string;
  trackingNumber: string;
  customerId?: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  
  // Pickup
  pickupCountry: string;
  pickupState: string;
  pickupCity: string;
  pickupAddress: string;
  
  // Destination
  destinationCountry: string;
  destinationState: string;
  destinationCity: string;
  destinationAddress: string;
  
  // Package
  packageDescription: string;
  packageCategory: PackageCategory;
  packageWeight: number; // kg
  deliveryType: DeliveryType;
  preferredPickupDate: string;
  additionalInstructions?: string;
  
  // Financials & Fulfillment
  totalAmount: number;
  currency: string;
  bookingStatus: DeliveryStatus;
  estimatedDeliveryDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TrackingCheckpoint {
  id: string;
  bookingId: string;
  trackingNumber: string;
  status: DeliveryStatus;
  location: string;
  notes?: string;
  recordedBy: string;
  timestamp: string;
}

export interface PaymentRecord {
  id: string;
  bookingId: string;
  trackingNumber: string;
  amount: number;
  currency: string;
  bankNamePaidTo: string;
  accountNumberPaidTo: string;
  senderAccountName?: string;
  senderBankName?: string;
  transactionReference?: string;
  receiptImageUrl?: string;
  receiptFilename?: string;
  paymentStatus: PaymentStatus;
  rejectionReason?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BankSettings {
  id: string;
  bankName: string;
  accountName: string;
  accountNumber: string;
  sortCode?: string;
  instructions?: string;
  isActive: boolean;
  updatedAt: string;
}

export interface DeliveryPricing {
  id: string;
  deliveryType: DeliveryType;
  destinationRegion: string;
  basePrice: number;
  pricePerKg: number;
  estimatedDaysMin: number;
  estimatedDaysMax: number;
  currency: string;
  isActive: boolean;
}

export interface WebsiteSettings {
  companyName: string;
  whatsappNumber: string;
  contactEmail: string;
  phoneNumber: string;
  officeAddress: string;
  workingHours: string;
  announcementBanner?: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  createdAt: string;
}
