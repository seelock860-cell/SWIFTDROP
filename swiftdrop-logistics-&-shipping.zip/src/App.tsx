import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { WhatsAppButton } from './components/common/WhatsAppButton';

// Pages
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { ServicesPage } from './pages/ServicesPage';
import { LocalDeliveryPage } from './pages/LocalDeliveryPage';
import { NationwideDeliveryPage } from './pages/NationwideDeliveryPage';
import { InternationalShippingPage } from './pages/InternationalShippingPage';
import { TrackPackagePage } from './pages/TrackPackagePage';
import { BookDeliveryPage } from './pages/BookDeliveryPage';
import { PricingPage } from './pages/PricingPage';
import { ContactPage } from './pages/ContactPage';
import { CustomerLoginPage } from './pages/CustomerLoginPage';
import { CustomerRegisterPage } from './pages/CustomerRegisterPage';
import { CustomerDashboardPage } from './pages/CustomerDashboardPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { CheckoutPage } from './pages/CheckoutPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [navParams, setNavParams] = useState<any>({});

  // Parse initial URL params or hash if any
  useEffect(() => {
    const handleUrlChange = () => {
      const hash = window.location.hash.replace('#', '');
      const searchParams = new URLSearchParams(window.location.search);
      const trackingQuery = searchParams.get('tracking') || searchParams.get('t');

      if (trackingQuery) {
        setCurrentPage('track-package');
        setNavParams({ trackingNumber: trackingQuery });
      } else if (hash) {
        setCurrentPage(hash);
      }
    };

    handleUrlChange();
    window.addEventListener('popstate', handleUrlChange);
    return () => window.removeEventListener('popstate', handleUrlChange);
  }, []);

  const handleNavigate = useCallback((page: string, params: any = {}) => {
    setCurrentPage(page);
    setNavParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Update URL hash quietly without full reload
    try {
      if (params.trackingNumber) {
        window.history.pushState(null, '', `?tracking=${params.trackingNumber}#track-package`);
      } else {
        window.history.pushState(null, '', `#${page}`);
      }
    } catch (e) {
      // Ignore in sandbox environment
    }
  }, []);

  const isAdminView = currentPage === 'admin-dashboard';

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 text-neutral-900 selection:bg-orange-500 selection:text-white">
      
      {/* Show Navbar on all non-admin-dashboard views */}
      {!isAdminView && (
        <Navbar currentPage={currentPage} onNavigate={handleNavigate} />
      )}

      {/* Main Content Router */}
      <main className="flex-1">
        {currentPage === 'home' && <HomePage onNavigate={handleNavigate} />}
        {currentPage === 'about' && <AboutPage onNavigate={handleNavigate} />}
        {currentPage === 'services' && <ServicesPage onNavigate={handleNavigate} />}
        {currentPage === 'local-delivery' && <LocalDeliveryPage onNavigate={handleNavigate} />}
        {currentPage === 'nationwide-delivery' && <NationwideDeliveryPage onNavigate={handleNavigate} />}
        {currentPage === 'international-shipping' && <InternationalShippingPage onNavigate={handleNavigate} />}
        {currentPage === 'track-package' && (
          <TrackPackagePage 
            initialTrackingNumber={navParams.trackingNumber || ''} 
            onNavigate={handleNavigate} 
          />
        )}
        {currentPage === 'book-delivery' && (
          <BookDeliveryPage 
            initialDeliveryType={navParams.deliveryType || 'local'} 
            onNavigate={handleNavigate} 
          />
        )}
        {currentPage === 'pricing' && <PricingPage onNavigate={handleNavigate} />}
        {currentPage === 'contact' && <ContactPage onNavigate={handleNavigate} />}
        {currentPage === 'customer-login' && <CustomerLoginPage onNavigate={handleNavigate} />}
        {currentPage === 'customer-register' && <CustomerRegisterPage onNavigate={handleNavigate} />}
        {currentPage === 'customer-dashboard' && <CustomerDashboardPage onNavigate={handleNavigate} />}
        {currentPage === 'admin-login' && <AdminLoginPage onNavigate={handleNavigate} />}
        {currentPage === 'admin-dashboard' && <AdminDashboardPage onNavigate={handleNavigate} />}
        {currentPage === 'checkout' && (
          <CheckoutPage 
            bookingId={navParams.bookingId} 
            onNavigate={handleNavigate} 
          />
        )}
      </main>

      {/* Floating WhatsApp Button (on public views) */}
      {!isAdminView && (
        <WhatsAppButton variant="floating" />
      )}

      {/* Show Footer on non-admin-dashboard views */}
      {!isAdminView && (
        <Footer onNavigate={handleNavigate} />
      )}

    </div>
  );
}
