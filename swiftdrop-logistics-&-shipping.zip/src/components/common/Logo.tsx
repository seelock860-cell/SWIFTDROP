import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark';
  size?: 'sm' | 'md' | 'lg';
}

export const Logo: React.FC<LogoProps> = ({ className = '', variant = 'dark', size = 'md' }) => {
  const isLight = variant === 'light';

  const sizeClasses = {
    sm: 'h-7 text-lg',
    md: 'h-9 text-xl',
    lg: 'h-11 text-2xl',
  };

  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-11 h-11',
  };

  return (
    <div className={`flex items-center gap-2.5 font-bold tracking-tight select-none ${className}`}>
      {/* Premium Geometric Arrow-Box Mark */}
      <div className={`relative ${iconSizes[size]} bg-black rounded-lg p-1.5 flex items-center justify-center shadow-sm overflow-hidden`}>
        <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
          {/* Outer angled box facet */}
          <path d="M4 11L18 3L32 11V25L18 33L4 25V11Z" stroke="white" strokeWidth="2.2" strokeLinejoin="round" />
          {/* Inner swift orange chevron */}
          <path d="M12 17L18 21L24 17" stroke="#F97316" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 12L18 16L24 12" stroke="#F97316" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" />
          {/* Vertical central speed spine */}
          <path d="M18 16V27" stroke="#F97316" strokeWidth="2.8" strokeLinecap="round" />
        </svg>
      </div>

      <div className="flex flex-col leading-none">
        <div className={`font-black tracking-tight ${sizeClasses[size]}`}>
          <span className={isLight ? 'text-white' : 'text-neutral-900'}>SWIFT</span>
          <span className="text-orange-600">DROP</span>
        </div>
        <span className={`text-[9px] tracking-widest font-semibold uppercase ${isLight ? 'text-neutral-400' : 'text-neutral-500'}`}>
          Express Logistics
        </span>
      </div>
    </div>
  );
};
