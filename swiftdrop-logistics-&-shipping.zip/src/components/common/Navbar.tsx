import React, { useState } from 'react';
import { Logo } from './Logo';
import { Menu, X, ChevronDown, User, Shield, PackagePlus, Search } from 'lucide-react';
import { StorageService } from '../../services/storageService';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string, params?: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesDropdownOpen, setServicesDropdownOpen] = useState(false);

  const currentUser = StorageService.getCurrentUser();
  const adminSession = StorageService.getAdminSession();

  const handleNav = (page: string, params?: any) => {
    onNavigate(page, params);
    setMobileMenuOpen(false);
    setServicesDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200/80 transition-all">
      {/* Top micro-bar for quick phone / tracking note */}
      <div className="bg-neutral-950 text-neutral-300 text-xs py-1.5 px-4 hidden md:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-neutral-400">Headquarters: Lekki Phase 1, Lagos, Nigeria</span>
            <span className="text-neutral-600">·</span>
            <span>Customer Line: +234 902 497 1419</span>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => handleNav('track-package')} 
              className="hover:text-orange-400 text-neutral-300 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Search className="w-3 h-3" /> Quick Package Tracker
            </button>
            <span className="text-neutral-700">|</span>
            <button
              onClick={() => handleNav('admin-login')}
              className="hover:text-orange-400 text-neutral-400 transition-colors flex items-center gap-1 cursor-pointer text-[11px]"
            >
              <Shield className="w-3 h-3" /> Admin Portal
            </button>
          </div>
        </div>
      </div>

      {/* Main 3-Zone Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center">
            <button 
              onClick={() => handleNav('home')} 
              className="text-left cursor-pointer focus:outline-none"
              aria-label="SWIFTDROP Home"
            >
              <Logo size="md" />
            </button>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-neutral-700">
            <button
              onClick={() => handleNav('home')}
              className={`hover:text-orange-600 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                currentPage === 'home' ? 'text-orange-600 font-semibold' : ''
              }`}
            >
              Home
            </button>

            {/* Services Dropdown */}
            <div className="relative" onMouseLeave={() => setServicesDropdownOpen(false)}>
              <button
                onClick={() => setServicesDropdownOpen(!servicesDropdownOpen)}
                onMouseEnter={() => setServicesDropdownOpen(true)}
                className={`flex items-center gap-1 hover:text-orange-600 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  ['services', 'local-delivery', 'nationwide-delivery', 'international-shipping'].includes(currentPage)
                    ? 'text-orange-600 font-semibold'
                    : ''
                }`}
              >
                <span>Services</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </button>

              {servicesDropdownOpen && (
                <div 
                  className="absolute left-0 mt-1 w-64 bg-white rounded-xl shadow-xl border border-neutral-100 py-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150"
                  onMouseEnter={() => setServicesDropdownOpen(true)}
                  onMouseLeave={() => setServicesDropdownOpen(false)}
                >
                  <button
                    onClick={() => handleNav('services')}
                    className="w-full text-left px-4 py-2.5 text-xs font-semibold text-neutral-900 hover:bg-orange-50 hover:text-orange-600 transition-colors flex items-center justify-between"
                  >
                    <span>All Services Overview</span>
                    <span className="text-[10px] text-neutral-400 font-normal">View all</span>
                  </button>
                  <div className="border-t border-neutral-100 my-1"></div>
                  <button
                    onClick={() => handleNav('local-delivery')}
                    className="w-full text-left px-4 py-2.5 text-xs text-neutral-700 hover:bg-orange-50 hover:text-orange-600 transition-colors"
                  >
                    <div className="font-semibold text-neutral-900">Local Delivery</div>
                    <div className="text-[11px] text-neutral-500">Intra-city dispatch in Lagos, Abuja & cities</div>
                  </button>
                  <button
                    onClick={() => handleNav('nationwide-delivery')}
                    className="w-full text-left px-4 py-2.5 text-xs text-neutral-700 hover:bg-orange-50 hover:text-orange-600 transition-colors"
                  >
                    <div className="font-semibold text-neutral-900">Nationwide Delivery</div>
                    <div className="text-[11px] text-neutral-500">Interstate logistics across all 36 States + FCT</div>
                  </button>
                  <button
                    onClick={() => handleNav('international-shipping')}
                    className="w-full text-left px-4 py-2.5 text-xs text-neutral-700 hover:bg-orange-50 hover:text-orange-600 transition-colors"
                  >
                    <div className="font-semibold text-neutral-900">International Shipping</div>
                    <div className="text-[11px] text-neutral-500">Fast air cargo from Nigeria to UK, US, Europe</div>
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => handleNav('track-package')}
              className={`hover:text-orange-600 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                currentPage === 'track-package' ? 'text-orange-600 font-semibold' : ''
              }`}
            >
              Track Package
            </button>

            <button
              onClick={() => handleNav('pricing')}
              className={`hover:text-orange-600 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                currentPage === 'pricing' ? 'text-orange-600 font-semibold' : ''
              }`}
            >
              Pricing
            </button>

            <button
              onClick={() => handleNav('about')}
              className={`hover:text-orange-600 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                currentPage === 'about' ? 'text-orange-600 font-semibold' : ''
              }`}
            >
              About Us
            </button>

            <button
              onClick={() => handleNav('contact')}
              className={`hover:text-orange-600 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                currentPage === 'contact' ? 'text-orange-600 font-semibold' : ''
              }`}
            >
              Contact Us
            </button>
          </nav>

          {/* Zone 3: Primary Action & Auth */}
          <div className="hidden lg:flex items-center gap-3 shrink-0">
            {currentUser ? (
              <button
                onClick={() => handleNav('customer-dashboard')}
                className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                <User className="w-3.5 h-3.5 text-neutral-600" />
                <span>My Dashboard</span>
              </button>
            ) : adminSession?.isAuthenticated ? (
              <button
                onClick={() => handleNav('admin-dashboard')}
                className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                <Shield className="w-3.5 h-3.5 text-orange-600" />
                <span>Admin Console</span>
              </button>
            ) : (
              <button
                onClick={() => handleNav('customer-login')}
                className="px-3.5 py-2 text-xs font-medium text-neutral-700 hover:text-neutral-900 transition-colors cursor-pointer whitespace-nowrap"
              >
                Client Login
              </button>
            )}

            <button
              onClick={() => handleNav('book-delivery')}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-orange-600 hover:bg-orange-700 active:bg-orange-800 rounded-lg transition-colors shadow-sm cursor-pointer whitespace-nowrap"
            >
              <PackagePlus className="w-4 h-4" />
              <span>Book a Delivery</span>
            </button>
          </div>

          {/* Mobile Menu Hamburger */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => handleNav('book-delivery')}
              className="px-3 py-1.5 text-xs font-bold text-white bg-orange-600 rounded-lg whitespace-nowrap"
            >
              Book
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-neutral-700 hover:bg-neutral-100 focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-neutral-200 px-4 pt-2 pb-6 space-y-3 animate-in fade-in duration-200">
          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => handleNav('track-package')}
              className="flex items-center justify-center gap-2 py-2.5 px-3 bg-neutral-100 rounded-lg text-xs font-semibold text-neutral-800"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Track Package</span>
            </button>
            <button
              onClick={() => handleNav('book-delivery')}
              className="flex items-center justify-center gap-2 py-2.5 px-3 bg-orange-600 text-white rounded-lg text-xs font-bold"
            >
              <PackagePlus className="w-3.5 h-3.5" />
              <span>Book Delivery</span>
            </button>
          </div>

          <div className="border-t border-neutral-100 pt-3 space-y-1">
            <button
              onClick={() => handleNav('home')}
              className={`w-full text-left py-2 px-2 text-sm font-medium rounded-md ${
                currentPage === 'home' ? 'text-orange-600 bg-orange-50' : 'text-neutral-700'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNav('local-delivery')}
              className="w-full text-left py-2 px-2 text-sm text-neutral-700"
            >
              Local Delivery (Within Cities)
            </button>
            <button
              onClick={() => handleNav('nationwide-delivery')}
              className="w-full text-left py-2 px-2 text-sm text-neutral-700"
            >
              Nationwide Delivery (Across Nigeria)
            </button>
            <button
              onClick={() => handleNav('international-shipping')}
              className="w-full text-left py-2 px-2 text-sm text-neutral-700"
            >
              International Cargo Shipping
            </button>
            <button
              onClick={() => handleNav('pricing')}
              className="w-full text-left py-2 px-2 text-sm text-neutral-700"
            >
              Pricing Matrix
            </button>
            <button
              onClick={() => handleNav('about')}
              className="w-full text-left py-2 px-2 text-sm text-neutral-700"
            >
              About Us
            </button>
            <button
              onClick={() => handleNav('contact')}
              className="w-full text-left py-2 px-2 text-sm text-neutral-700"
            >
              Contact Us
            </button>
          </div>

          <div className="border-t border-neutral-100 pt-3 flex flex-col gap-2">
            {currentUser ? (
              <button
                onClick={() => handleNav('customer-dashboard')}
                className="w-full py-2.5 px-3 text-center text-xs font-semibold bg-neutral-900 text-white rounded-lg"
              >
                Customer Dashboard ({currentUser.fullName.split(' ')[0]})
              </button>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleNav('customer-login')}
                  className="py-2.5 px-3 text-center text-xs font-semibold bg-neutral-100 text-neutral-800 rounded-lg"
                >
                  Customer Login
                </button>
                <button
                  onClick={() => handleNav('customer-register')}
                  className="py-2.5 px-3 text-center text-xs font-semibold bg-neutral-200 text-neutral-900 rounded-lg"
                >
                  Register
                </button>
              </div>
            )}
            <button
              onClick={() => handleNav('admin-login')}
              className="text-center py-2 text-xs text-neutral-500 hover:text-neutral-900"
            >
              Admin Portal
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
