import React from 'react';
import { Logo } from './Logo';
import { Phone, Mail, MapPin, Clock, ArrowRight, ShieldCheck, Truck, Plane } from 'lucide-react';
import { WhatsAppButton } from './WhatsAppButton';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-neutral-950 text-neutral-300 pt-16 pb-12 border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Feature Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pb-12 border-b border-neutral-900">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-neutral-900 border border-neutral-800 flex items-center justify-center shrink-0 text-orange-500">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white text-sm font-bold">Nigeria-Wide Coverage</h4>
              <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                Intra-city express dispatch across Lagos, Abuja, Port Harcourt and secure interstate delivery to all 36 States.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-neutral-900 border border-neutral-800 flex items-center justify-center shrink-0 text-orange-500">
              <Plane className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white text-sm font-bold">Global Cargo & Air Freight</h4>
              <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                Seamless international export and parcel shipping connecting Nigeria to the UK, United States, Canada, and Europe.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-neutral-900 border border-neutral-800 flex items-center justify-center shrink-0 text-orange-500">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white text-sm font-bold">Direct Verified Bank Transfer</h4>
              <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                Safe and auditable manual payment verification. Every transfer receipt is reviewed by authorized operations staff.
              </p>
            </div>
          </div>
        </div>

        {/* Main Footer Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 py-12 border-b border-neutral-900">
          
          {/* Brand & Intro */}
          <div className="lg:col-span-2 space-y-4">
            <Logo variant="light" size="lg" />
            <p className="text-xs text-neutral-400 leading-relaxed max-w-sm">
              SWIFTDROP is Nigeria's premier modern logistics and dispatch corporation. We deliver reliability, speed, and real-time package accountability from your doorstep to destinations worldwide.
            </p>
            <div className="pt-2">
              <WhatsAppButton 
                variant="button" 
                label="Chat on WhatsApp (09024971419)" 
                className="text-xs py-2 px-3.5"
              />
            </div>
          </div>

          {/* Logistics Services */}
          <div>
            <h5 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Our Services</h5>
            <ul className="space-y-2.5 text-xs text-neutral-400">
              <li>
                <button onClick={() => onNavigate('local-delivery')} className="hover:text-orange-400 transition-colors text-left">
                  Local City Dispatch
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('nationwide-delivery')} className="hover:text-orange-400 transition-colors text-left">
                  Nationwide Interstate Shipping
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('international-shipping')} className="hover:text-orange-400 transition-colors text-left">
                  International Air Freight
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('pricing')} className="hover:text-orange-400 transition-colors text-left">
                  Rate Calculator & Pricing
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('book-delivery')} className="hover:text-orange-400 transition-colors text-left text-orange-400 font-medium">
                  Book A Delivery →
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Tracking & Client Portals */}
          <div>
            <h5 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Portals & Tracking</h5>
            <ul className="space-y-2.5 text-xs text-neutral-400">
              <li>
                <button onClick={() => onNavigate('track-package')} className="hover:text-orange-400 transition-colors text-left">
                  Live Package Tracker
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('customer-login')} className="hover:text-orange-400 transition-colors text-left">
                  Customer Account Login
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('customer-register')} className="hover:text-orange-400 transition-colors text-left">
                  Open Business Account
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('customer-dashboard')} className="hover:text-orange-400 transition-colors text-left">
                  Customer Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('admin-login')} className="hover:text-orange-400 transition-colors text-left">
                  Operations Admin Portal
                </button>
              </li>
            </ul>
          </div>

          {/* Official Contact Info */}
          <div>
            <h5 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Head Office</h5>
            <div className="space-y-3 text-xs text-neutral-400">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                <span>Plot 14B Admiralty Way, Lekki Phase 1, Lagos State, Nigeria</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-orange-500 shrink-0" />
                <a href="tel:+2349024971419" className="hover:text-white transition-colors">
                  +234 902 497 1419
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-orange-500 shrink-0" />
                <a href="mailto:support@swiftdrop.ng" className="hover:text-white transition-colors">
                  support@swiftdrop.ng
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-orange-500 shrink-0" />
                <span>Mon - Sat: 8:00 AM - 7:00 PM</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Legal & Deployment Spec */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between text-xs text-neutral-500 gap-4">
          <p>© {new Date().getFullYear()} SWIFTDROP Logistics & Shipping Limited. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="text-neutral-400 font-mono text-[11px]">Cloudflare Pages & Supabase Architecture</span>
            <button onClick={() => onNavigate('about')} className="hover:text-neutral-300">About</button>
            <button onClick={() => onNavigate('contact')} className="hover:text-neutral-300">Support</button>
          </div>
        </div>

      </div>
    </footer>
  );
};
