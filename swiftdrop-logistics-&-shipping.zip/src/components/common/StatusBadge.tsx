import React from 'react';
import { DeliveryStatus, PaymentStatus } from '../../types';
import { CheckCircle2, Clock, Truck, Package, XCircle, AlertCircle, FileCheck } from 'lucide-react';

interface StatusBadgeProps {
  status: DeliveryStatus | PaymentStatus | string;
  type?: 'delivery' | 'payment';
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, type = 'delivery', className = '' }) => {
  // Config for Delivery Statuses
  if (type === 'delivery') {
    switch (status) {
      case 'Booking Received':
        return (
          <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-neutral-700 ${className}`}>
            <Clock className="w-3.5 h-3.5 text-neutral-500" />
            <span>Booking Received</span>
          </span>
        );
      case 'Payment Pending':
        return (
          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 ${className}`}>
            <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
            <span>Payment Pending</span>
          </span>
        );
      case 'Payment Confirmed':
        return (
          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold text-blue-700 ${className}`}>
            <FileCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Payment Confirmed</span>
          </span>
        );
      case 'Package Picked Up':
        return (
          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-700 ${className}`}>
            <Package className="w-3.5 h-3.5 text-indigo-600" />
            <span>Package Picked Up</span>
          </span>
        );
      case 'In Transit':
        return (
          <span className={`inline-flex items-center gap-1.5 text-xs font-bold text-orange-700 ${className}`}>
            <Truck className="w-3.5 h-3.5 text-orange-600" />
            <span>In Transit</span>
          </span>
        );
      case 'Arrived at Destination':
        return (
          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold text-purple-700 ${className}`}>
            <Package className="w-3.5 h-3.5 text-purple-600" />
            <span>Arrived at Destination</span>
          </span>
        );
      case 'Out for Delivery':
        return (
          <span className={`inline-flex items-center gap-1.5 text-xs font-bold text-amber-700 ${className}`}>
            <Truck className="w-3.5 h-3.5 text-amber-600" />
            <span>Out for Delivery</span>
          </span>
        );
      case 'Delivered':
        return (
          <span className={`inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 ${className}`}>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Delivered</span>
          </span>
        );
      case 'Cancelled':
        return (
          <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-rose-700 ${className}`}>
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            <span>Cancelled</span>
          </span>
        );
      default:
        return <span className={`text-xs text-neutral-600 ${className}`}>{status}</span>;
    }
  }

  // Payment Statuses
  switch (status) {
    case 'Awaiting Payment':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 ${className}`}>
          <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
          <span>Awaiting Payment</span>
        </span>
      );
    case 'Receipt Submitted':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-700 ${className}`}>
          <Clock className="w-3.5 h-3.5 text-indigo-600" />
          <span>Receipt Submitted</span>
        </span>
      );
    case 'Under Verification':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-semibold text-purple-700 ${className}`}>
          <Clock className="w-3.5 h-3.5 text-purple-600" />
          <span>Under Verification</span>
        </span>
      );
    case 'Payment Approved':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 ${className}`}>
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>Payment Approved</span>
        </span>
      );
    case 'Payment Rejected':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-bold text-rose-700 ${className}`}>
          <XCircle className="w-3.5 h-3.5 text-rose-600" />
          <span>Payment Rejected</span>
        </span>
      );
    default:
      return <span className={`text-xs text-neutral-600 ${className}`}>{status}</span>;
  }
};
