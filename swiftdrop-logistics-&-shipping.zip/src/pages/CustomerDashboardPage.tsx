import React, { useState, useEffect } from 'react';
import { StorageService } from '../services/storageService';
import { Booking, Profile } from '../types';
import { StatusBadge } from '../components/common/StatusBadge';
import { 
  Package, 
  PackagePlus, 
  Search, 
  CreditCard, 
  User, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  CheckCircle2, 
  ArrowRight, 
  LogOut,
  Upload,
  Settings,
  HelpCircle,
  AlertCircle
} from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface CustomerDashboardPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const CustomerDashboardPage: React.FC<CustomerDashboardPageProps> = ({ onNavigate }) => {
  const [currentUser, setCurrentUser] = useState<Profile | null>(() => StorageService.getCurrentUser());
  const [bookings, setBookings] = useState<Booking[]>(() => {
    const user = StorageService.getCurrentUser();
    if (user) {
      const userBookings = StorageService.getBookingsByCustomer(user.email);
      return userBookings.length > 0 ? userBookings : StorageService.getBookings();
    }
    return StorageService.getBookings();
  });
  const [activeTab, setActiveTab] = useState<'bookings' | 'profile' | 'support'>('bookings');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Edit profile state
  const [profileForm, setProfileForm] = useState(() => {
    const user = StorageService.getCurrentUser();
    return {
      fullName: user?.fullName || '',
      phone: user?.phone || '',
      address: user?.address || '',
      city: user?.city || '',
      state: user?.state || '',
    };
  });
  const [profileSuccess, setProfileSuccess] = useState('');

  useEffect(() => {
    const user = StorageService.getCurrentUser();
    if (!user) {
      onNavigate('customer-login');
    }
  }, [onNavigate]);

  const handleLogout = () => {
    StorageService.setCurrentUser(null);
    onNavigate('home');
  };

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const updatedUser: Profile = {
      ...currentUser,
      fullName: profileForm.fullName,
      phone: profileForm.phone,
      address: profileForm.address,
      city: profileForm.city,
      state: profileForm.state,
    };

    StorageService.setCurrentUser(updatedUser);
    setCurrentUser(updatedUser);
    setProfileSuccess('Profile details saved successfully.');
    setTimeout(() => setProfileSuccess(''), 3000);
  };

  const filteredBookings = bookings.filter(b => {
    if (statusFilter === 'all') return true;
    if (statusFilter === 'transit') return ['Package Picked Up', 'In Transit', 'Out for Delivery'].includes(b.bookingStatus);
    if (statusFilter === 'pending') return ['Booking Received', 'Payment Pending'].includes(b.bookingStatus);
    if (statusFilter === 'delivered') return b.bookingStatus === 'Delivered';
    return true;
  });

  if (!currentUser) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Top Welcome Header */}
      <div className="bg-neutral-950 text-white rounded-3xl p-6 sm:p-8 border border-neutral-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="text-xs font-mono text-orange-400 font-semibold uppercase tracking-wider">Customer Portal</div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Welcome back, {currentUser.fullName}
          </h1>
          <p className="text-xs text-neutral-400">
            {currentUser.email} · Registered Client Account
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => onNavigate('book-delivery')}
            className="px-5 py-2.5 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center gap-2 cursor-pointer shadow-md"
          >
            <PackagePlus className="w-4 h-4" />
            <span>Book New Delivery</span>
          </button>
          
          <button
            onClick={handleLogout}
            className="px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        </div>
      </div>

      {/* Tabs / Segmented Control */}
      <div className="flex items-center gap-2 border-b border-neutral-200 pb-3">
        <button
          onClick={() => setActiveTab('bookings')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'bookings'
              ? 'bg-neutral-950 text-white shadow-sm'
              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>My Consignments ({bookings.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'profile'
              ? 'bg-neutral-950 text-white shadow-sm'
              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Profile & Account</span>
        </button>

        <button
          onClick={() => setActiveTab('support')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'support'
              ? 'bg-neutral-950 text-white shadow-sm'
              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>Customer Support</span>
        </button>
      </div>

      {/* TAB 1: BOOKINGS LIST */}
      {activeTab === 'bookings' && (
        <div className="space-y-6">
          
          {/* Sub-Filters */}
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-1 bg-neutral-100 p-1 rounded-xl">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  statusFilter === 'all' ? 'bg-white text-neutral-900 shadow-sm font-bold' : 'text-neutral-600'
                }`}
              >
                All ({bookings.length})
              </button>
              <button
                onClick={() => setStatusFilter('pending')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  statusFilter === 'pending' ? 'bg-white text-neutral-900 shadow-sm font-bold' : 'text-neutral-600'
                }`}
              >
                Pending Payment
              </button>
              <button
                onClick={() => setStatusFilter('transit')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  statusFilter === 'transit' ? 'bg-white text-neutral-900 shadow-sm font-bold' : 'text-neutral-600'
                }`}
              >
                In Transit
              </button>
              <button
                onClick={() => setStatusFilter('delivered')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  statusFilter === 'delivered' ? 'bg-white text-neutral-900 shadow-sm font-bold' : 'text-neutral-600'
                }`}
              >
                Delivered
              </button>
            </div>

            <div className="text-xs text-neutral-500 font-mono">
              Showing {filteredBookings.length} order{filteredBookings.length === 1 ? '' : 's'}
            </div>
          </div>

          {filteredBookings.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-neutral-200 space-y-4">
              <Package className="w-12 h-12 text-neutral-300 mx-auto" />
              <h3 className="text-base font-bold text-neutral-900">No shipments found in this category</h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Ready to dispatch your next consignment? Book a pickup in minutes.
              </p>
              <button
                onClick={() => onNavigate('book-delivery')}
                className="px-5 py-2.5 bg-orange-600 text-white rounded-lg text-xs font-bold"
              >
                Book a Delivery
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {filteredBookings.map((b) => {
                const p = StorageService.getPaymentByBookingId(b.id);
                const isAwaitingPayment = b.bookingStatus === 'Payment Pending' || b.bookingStatus === 'Booking Received';

                return (
                  <div
                    key={b.id}
                    className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-sm hover:border-neutral-300 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-6"
                  >
                    {/* Left: Tracking & Origin/Dest */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-bold font-mono text-neutral-900">{b.trackingNumber}</span>
                        <StatusBadge status={b.bookingStatus} type="delivery" />
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 text-xs text-neutral-600">
                        <span className="capitalize font-semibold text-neutral-800">{b.deliveryType} Delivery</span>
                        <span className="hidden sm:inline text-neutral-300">·</span>
                        <span>From: <strong>{b.pickupCity}, {b.pickupState}</strong></span>
                        <span className="hidden sm:inline text-neutral-300">→</span>
                        <span>To: <strong>{b.destinationCity}, {b.destinationCountry}</strong></span>
                      </div>

                      <p className="text-xs text-neutral-500 line-clamp-1">
                        {b.packageDescription} ({b.packageWeight} kg)
                      </p>
                    </div>

                    {/* Middle: Financials & Audit */}
                    <div className="flex flex-col lg:items-end text-xs space-y-1">
                      <span className="text-neutral-500">Amount:</span>
                      <span className="text-base font-extrabold font-mono text-neutral-900">
                        ₦{b.totalAmount.toLocaleString()}
                      </span>
                      <div>
                        <StatusBadge status={p?.paymentStatus || 'Awaiting Payment'} type="payment" className="text-[11px]" />
                      </div>
                    </div>

                    {/* Right: Action Buttons */}
                    <div className="flex flex-wrap items-center gap-2 pt-2 lg:pt-0 border-t lg:border-t-0 border-neutral-100">
                      <button
                        onClick={() => onNavigate('track-package', { trackingNumber: b.trackingNumber })}
                        className="px-3.5 py-2 bg-neutral-950 hover:bg-neutral-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                      >
                        <Search className="w-3.5 h-3.5" />
                        <span>Track</span>
                      </button>

                      {isAwaitingPayment && (
                        <button
                          onClick={() => onNavigate('checkout', { bookingId: b.id })}
                          className="px-3.5 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>Upload Receipt</span>
                        </button>
                      )}
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

      {/* TAB 2: PROFILE SETTINGS */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-neutral-200 shadow-sm max-w-2xl space-y-6">
          <div className="border-b border-neutral-100 pb-3">
            <h2 className="text-base font-bold text-neutral-900">Update Profile Details</h2>
            <p className="text-xs text-neutral-500 mt-0.5">Keep your default dispatch address and contact phone up to date.</p>
          </div>

          {profileSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{profileSuccess}</span>
            </div>
          )}

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={profileForm.fullName}
                  onChange={(e) => setProfileForm({ ...profileForm, fullName: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  required
                  value={profileForm.phone}
                  onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">Registered Email (Read-Only)</label>
              <input
                type="email"
                readOnly
                value={currentUser.email}
                className="w-full px-3 py-2 bg-neutral-100 border border-neutral-200 rounded-lg text-xs text-neutral-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">City</label>
                <input
                  type="text"
                  value={profileForm.city}
                  onChange={(e) => setProfileForm({ ...profileForm, city: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">State</label>
                <input
                  type="text"
                  value={profileForm.state}
                  onChange={(e) => setProfileForm({ ...profileForm, state: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">Default Pickup Address</label>
              <textarea
                rows={2}
                value={profileForm.address}
                onChange={(e) => setProfileForm({ ...profileForm, address: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 bg-neutral-950 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
            >
              Save Profile Changes
            </button>
          </form>
        </div>
      )}

      {/* TAB 3: CUSTOMER SUPPORT */}
      {activeTab === 'support' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-emerald-50 rounded-2xl p-6 border border-emerald-200 space-y-4">
            <h3 className="text-base font-bold text-emerald-950">Direct WhatsApp Helpdesk</h3>
            <p className="text-xs text-emerald-800 leading-relaxed">
              Have an urgent question regarding an active booking or need immediate proof of delivery? Connect with our dedicated operations agent on WhatsApp.
            </p>
            <WhatsAppButton 
              variant="button" 
              label="Chat on WhatsApp (09024971419)" 
              message={`Hello SWIFTDROP! I am logged into my client dashboard (${currentUser.email}) and need dispatch assistance.`}
              className="w-full text-xs py-3" 
            />
          </div>

          <div className="bg-white rounded-2xl p-6 border border-neutral-200 space-y-4">
            <h3 className="text-base font-bold text-neutral-900">Phone & Email Inquiries</h3>
            <div className="space-y-3 text-xs text-neutral-600">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-orange-600" />
                <span>+234 902 497 1419</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-600" />
                <span>support@swiftdrop.ng</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-orange-600" />
                <span>Plot 14B Admiralty Way, Lekki Phase 1, Lagos</span>
              </div>
            </div>
            <button
              onClick={() => onNavigate('contact')}
              className="w-full py-2.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-900 rounded-lg text-xs font-bold transition-colors"
            >
              Open Full Contact Page
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
