import React, { useState, useMemo } from 'react';
import { StorageService } from '../services/storageService';
import { DeliveryPricing, DeliveryType } from '../types';
import { Calculator, ArrowRight, CheckCircle2, ShieldCheck, Scale, Plane, Truck } from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface PricingPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({ onNavigate }) => {
  const [pricingList] = useState<DeliveryPricing[]>(() => StorageService.getPricing());

  // Interactive Calculator State
  const [selectedType, setSelectedType] = useState<DeliveryType>('local');
  const [calcWeight, setCalcWeight] = useState<number>(2.5);

  const estimate = useMemo(() => {
    return StorageService.calculatePrice(selectedType, calcWeight);
  }, [selectedType, calcWeight]);

  const localTiers = pricingList.filter(p => p.deliveryType === 'local');
  const nationwideTiers = pricingList.filter(p => p.deliveryType === 'nationwide');
  const internationalTiers = pricingList.filter(p => p.deliveryType === 'international');

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Transparent Rates</div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
          Delivery Rates & Interactive Shipping Calculator
        </h1>
        <p className="text-xs sm:text-sm text-neutral-600">
          Clear, competitive, and honest pricing with zero hidden surcharges. Calculate instant shipping costs across Nigerian cities, nationwide states, and global destinations.
        </p>
      </div>

      {/* Interactive Live Calculator Card */}
      <div className="bg-neutral-950 text-white rounded-3xl p-6 sm:p-10 border border-neutral-800 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-orange-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl mx-auto space-y-8 relative z-10">
          <div className="flex items-center gap-3 border-b border-neutral-800 pb-4">
            <div className="w-10 h-10 rounded-xl bg-orange-600 flex items-center justify-center text-white">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Instant Shipping Fare Calculator</h2>
              <p className="text-xs text-neutral-400">Select coverage and package weight to calculate the exact bank transfer amount.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            
            {/* Service Type Selection */}
            <div>
              <label className="block text-xs font-medium text-neutral-300 uppercase tracking-wider mb-2">
                1. Delivery Coverage
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedType('local')}
                  className={`py-3 px-2 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                    selectedType === 'local'
                      ? 'bg-orange-600 text-white shadow-md'
                      : 'bg-neutral-900 text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  Local
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedType('nationwide')}
                  className={`py-3 px-2 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                    selectedType === 'nationwide'
                      ? 'bg-orange-600 text-white shadow-md'
                      : 'bg-neutral-900 text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  Nationwide
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedType('international')}
                  className={`py-3 px-2 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                    selectedType === 'international'
                      ? 'bg-orange-600 text-white shadow-md'
                      : 'bg-neutral-900 text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  International
                </button>
              </div>
            </div>

            {/* Package Weight Slider & Input */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-medium text-neutral-300 uppercase tracking-wider">
                  2. Weight (kg)
                </label>
                <span className="text-xs font-mono font-bold text-orange-400">{calcWeight} kg</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="50"
                step="0.5"
                value={calcWeight}
                onChange={(e) => setCalcWeight(parseFloat(e.target.value) || 1)}
                className="w-full accent-orange-600 cursor-pointer h-2 bg-neutral-800 rounded-lg"
              />
              <div className="flex justify-between text-[11px] text-neutral-500 font-mono mt-1">
                <span>0.5 kg (Document)</span>
                <span>25 kg</span>
                <span>50 kg (Heavy Cargo)</span>
              </div>
            </div>

          </div>

          {/* Calculator Output Box */}
          <div className="p-5 bg-neutral-900 rounded-2xl border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div>
              <div className="text-xs text-neutral-400">Estimated Total Fare</div>
              <div className="text-3xl sm:text-4xl font-extrabold text-white font-mono mt-1 tracking-tight">
                ₦{estimate.amount.toLocaleString()}
              </div>
              <div className="text-xs text-orange-400 font-medium mt-1">
                Estimated Transit: {estimate.estimatedDays}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <button
                onClick={() => onNavigate('book-delivery', { deliveryType: selectedType })}
                className="w-full sm:w-auto px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-lg shadow-orange-600/30 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <span>Book With This Rate</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <WhatsAppButton 
                variant="button" 
                label="WhatsApp Quote" 
                message={`Hello SWIFTDROP! I calculated an estimate of ₦${estimate.amount.toLocaleString()} for a ${calcWeight}kg ${selectedType} shipment and would like to confirm details.`}
                className="w-full sm:w-auto text-xs py-3" 
              />
            </div>
          </div>

        </div>
      </div>

      {/* Detailed Rate Tables */}
      <div className="space-y-12">
        
        {/* Local Table */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-neutral-200 pb-2">
            <Truck className="w-5 h-5 text-orange-600" />
            <h2 className="text-lg font-bold text-neutral-900">Local Delivery Pricing (Intra-City)</h2>
          </div>
          <div className="bg-white rounded-2xl border border-neutral-200 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 text-neutral-500 uppercase tracking-wider border-b border-neutral-200 font-semibold">
                  <tr>
                    <th className="py-3 px-4">Coverage Region</th>
                    <th className="py-3 px-4">Base Fare (First 1 kg)</th>
                    <th className="py-3 px-4">Per Additional Kg</th>
                    <th className="py-3 px-4">Transit Time</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 font-medium">
                  {localTiers.map(tier => (
                    <tr key={tier.id} className="hover:bg-neutral-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-neutral-900">{tier.destinationRegion}</td>
                      <td className="py-3.5 px-4 font-mono">₦{tier.basePrice.toLocaleString()}</td>
                      <td className="py-3.5 px-4 font-mono">+₦{tier.pricePerKg.toLocaleString()} / kg</td>
                      <td className="py-3.5 px-4 text-emerald-600 font-semibold">
                        {tier.estimatedDaysMin === 0 ? 'Same Day (Within 2-4 hrs)' : `${tier.estimatedDaysMin}-${tier.estimatedDaysMax} Days`}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => onNavigate('book-delivery', { deliveryType: 'local' })}
                          className="text-xs font-bold text-orange-600 hover:text-orange-700"
                        >
                          Book →
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Nationwide Table */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-neutral-200 pb-2">
            <Truck className="w-5 h-5 text-orange-600" />
            <h2 className="text-lg font-bold text-neutral-900">Nationwide Interstate Rates (All 36 States)</h2>
          </div>
          <div className="bg-white rounded-2xl border border-neutral-200 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 text-neutral-500 uppercase tracking-wider border-b border-neutral-200 font-semibold">
                  <tr>
                    <th className="py-3 px-4">Geopolitical Zone / State Route</th>
                    <th className="py-3 px-4">Base Fare (First 1 kg)</th>
                    <th className="py-3 px-4">Per Additional Kg</th>
                    <th className="py-3 px-4">Transit Window</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 font-medium">
                  {nationwideTiers.map(tier => (
                    <tr key={tier.id} className="hover:bg-neutral-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-neutral-900">{tier.destinationRegion}</td>
                      <td className="py-3.5 px-4 font-mono">₦{tier.basePrice.toLocaleString()}</td>
                      <td className="py-3.5 px-4 font-mono">+₦{tier.pricePerKg.toLocaleString()} / kg</td>
                      <td className="py-3.5 px-4 text-neutral-700 font-mono">{tier.estimatedDaysMin} - {tier.estimatedDaysMax} business days</td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => onNavigate('book-delivery', { deliveryType: 'nationwide' })}
                          className="text-xs font-bold text-orange-600 hover:text-orange-700"
                        >
                          Book →
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* International Table */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-neutral-200 pb-2">
            <Plane className="w-5 h-5 text-orange-600" />
            <h2 className="text-lg font-bold text-neutral-900">International Express Air Cargo Rates</h2>
          </div>
          <div className="bg-white rounded-2xl border border-neutral-200 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 text-neutral-500 uppercase tracking-wider border-b border-neutral-200 font-semibold">
                  <tr>
                    <th className="py-3 px-4">Destination Country / Region</th>
                    <th className="py-3 px-4">Base Fare (First 1 kg)</th>
                    <th className="py-3 px-4">Per Additional Kg</th>
                    <th className="py-3 px-4">Air Freight Transit</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 font-medium">
                  {internationalTiers.map(tier => (
                    <tr key={tier.id} className="hover:bg-neutral-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-neutral-900">{tier.destinationRegion}</td>
                      <td className="py-3.5 px-4 font-mono">₦{tier.basePrice.toLocaleString()}</td>
                      <td className="py-3.5 px-4 font-mono">+₦{tier.pricePerKg.toLocaleString()} / kg</td>
                      <td className="py-3.5 px-4 text-neutral-700 font-mono">{tier.estimatedDaysMin} - {tier.estimatedDaysMax} business days</td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => onNavigate('book-delivery', { deliveryType: 'international' })}
                          className="text-xs font-bold text-orange-600 hover:text-orange-700"
                        >
                          Book →
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
