import React, { useState, useEffect } from 'react';
import { StorageService } from '../services/storageService';
import { 
  Booking, 
  Customer, 
  DeliveryPricing, 
  PaymentRecord, 
  TrackingCheckpoint, 
  BankSettings, 
  WebsiteSettings,
  DeliveryStatus,
  PaymentStatus,
  DeliveryType
} from '../types';
import { SupabaseRemote, SUPABASE_URL, isSupabaseConfigured } from '../lib/supabase';
import { StatusBadge } from '../components/common/StatusBadge';
import { 
  LayoutDashboard, 
  Package, 
  Truck, 
  CreditCard, 
  Building2, 
  DollarSign, 
  Users, 
  Settings, 
  Database,
  Search, 
  Plus, 
  Check, 
  X, 
  Eye, 
  Edit3, 
  Calendar, 
  MapPin, 
  LogOut, 
  CheckCircle2, 
  AlertCircle,
  Clock,
  ArrowRight,
  FileText,
  Copy,
  ExternalLink,
  ChevronDown
} from 'lucide-react';

interface AdminDashboardPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onNavigate }) => {
  const [adminSession, setAdminSession] = useState(() => StorageService.getAdminSession());

  // Active admin section tab
  const [activeTab, setActiveTab] = useState<
    'overview' | 'bookings' | 'deliveries' | 'payments' | 'bank' | 'pricing' | 'customers' | 'settings' | 'supabase'
  >('overview');

  // Core Data Lists initialized from Storage
  const [bookings, setBookings] = useState<Booking[]>(() => StorageService.getBookings());
  const [payments, setPayments] = useState<PaymentRecord[]>(() => StorageService.getPayments());
  const [customers, setCustomers] = useState<Customer[]>(() => StorageService.getCustomers());
  const [pricing, setPricing] = useState<DeliveryPricing[]>(() => StorageService.getPricing());
  const [bankSettings, setBankSettings] = useState<BankSettings>(() => StorageService.getBankSettings());
  const [websiteSettings, setWebsiteSettings] = useState<WebsiteSettings>(() => StorageService.getWebsiteSettings());

  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Modals & Action States
  const [viewingReceipt, setViewingReceipt] = useState<PaymentRecord | null>(null);
  const [rejectingPayment, setRejectingPayment] = useState<PaymentRecord | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);
  const [addCheckpointBooking, setAddCheckpointBooking] = useState<Booking | null>(null);
  const [checkpointForm, setCheckpointForm] = useState({
    status: 'In Transit' as DeliveryStatus,
    location: '',
    notes: '',
  });

  // Bank Form State
  const [bankForm, setBankForm] = useState<BankSettings>(() => StorageService.getBankSettings());
  const [bankSavedMessage, setBankSavedMessage] = useState('');

  // Website Settings Form State
  const [webForm, setWebForm] = useState<WebsiteSettings>(() => StorageService.getWebsiteSettings());
  const [webSavedMessage, setWebSavedMessage] = useState('');

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [testingDb, setTestingDb] = useState(false);
  const [dbTestResult, setDbTestResult] = useState<string | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleTestSupabase = async () => {
    setTestingDb(true);
    setDbTestResult(null);
    const res = await SupabaseRemote.testConnection();
    setTestingDb(false);
    setDbTestResult(res.message);
    showToast(res.ok ? 'Connection verified!' : 'Connection attempted.');
  };

  const refreshData = () => {
    setBookings(StorageService.getBookings());
    setPayments(StorageService.getPayments());
    setCustomers(StorageService.getCustomers());
    setPricing(StorageService.getPricing());
    setBankSettings(StorageService.getBankSettings());
    setBankForm(StorageService.getBankSettings());
    setWebsiteSettings(StorageService.getWebsiteSettings());
    setWebForm(StorageService.getWebsiteSettings());
  };

  useEffect(() => {
    const session = StorageService.getAdminSession();
    if (!session?.isAuthenticated) {
      onNavigate('admin-login');
    } else {
      setAdminSession(session);
    }
  }, [onNavigate]);

  const handleLogout = () => {
    StorageService.setAdminSession(null);
    onNavigate('home');
  };

  // --- STATS CALCULATIONS (Section 8.A) ---
  const totalBookings = bookings.length;
  const totalCustomers = customers.length;
  const pendingPayments = payments.filter(p => p.paymentStatus === 'Awaiting Payment' || p.paymentStatus === 'Receipt Submitted' || p.paymentStatus === 'Under Verification').length;
  const approvedPayments = payments.filter(p => p.paymentStatus === 'Payment Approved').length;
  const totalDeliveries = bookings.length;
  const deliveredPackages = bookings.filter(b => b.bookingStatus === 'Delivered').length;
  const packagesInTransit = bookings.filter(b => ['Package Picked Up', 'In Transit', 'Out for Delivery'].includes(b.bookingStatus)).length;
  const totalRevenue = bookings
    .filter(b => b.bookingStatus !== 'Cancelled')
    .reduce((acc, curr) => acc + (curr.totalAmount || 0), 0);

  // --- PAYMENT ACTIONS (Section 8.D) ---
  const handleApprovePayment = (paymentId: string) => {
    const res = StorageService.approvePayment(paymentId, adminSession?.username || 'swift');
    if (res) {
      refreshData();
      setViewingReceipt(null);
      showToast(`Payment of ₦${res.amount.toLocaleString()} approved. Shipment status updated to Payment Confirmed.`);
    }
  };

  const handleRejectPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectingPayment) return;
    const res = StorageService.rejectPayment(rejectingPayment.id, rejectReason || 'Receipt was illegible or invalid', adminSession?.username || 'swift');
    if (res) {
      refreshData();
      setRejectingPayment(null);
      setRejectReason('');
      showToast(`Payment rejected. Customer will be notified to re-upload.`, 'error');
    }
  };

  // --- BOOKING ACTIONS (Section 8.B & 8.C) ---
  const handleSaveBookingEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBooking) return;

    StorageService.updateBookingStatus(
      editingBooking.id, 
      editingBooking.bookingStatus, 
      `Admin updated status to ${editingBooking.bookingStatus}`
    );

    // Also update estimated date if changed
    const all = StorageService.getBookings();
    const idx = all.findIndex(b => b.id === editingBooking.id);
    if (idx !== -1) {
      all[idx].estimatedDeliveryDate = editingBooking.estimatedDeliveryDate;
      all[idx].trackingNumber = editingBooking.trackingNumber;
      localStorage.setItem('swiftdrop_bookings', JSON.stringify(all));
    }

    refreshData();
    setEditingBooking(null);
    showToast('Booking details updated successfully.');
  };

  const handleAddCheckpoint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addCheckpointBooking) return;

    StorageService.addTrackingCheckpoint({
      bookingId: addCheckpointBooking.id,
      trackingNumber: addCheckpointBooking.trackingNumber,
      status: checkpointForm.status,
      location: checkpointForm.location,
      notes: checkpointForm.notes,
      recordedBy: `Admin (${adminSession?.username || 'swift'})`,
    });

    // Also update current booking status
    StorageService.updateBookingStatus(
      addCheckpointBooking.id, 
      checkpointForm.status, 
      checkpointForm.location
    );

    refreshData();
    setAddCheckpointBooking(null);
    setCheckpointForm({ status: 'In Transit', location: '', notes: '' });
    showToast(`New tracking milestone logged for ${addCheckpointBooking.trackingNumber}.`);
  };

  // --- BANK SETTINGS SAVE (Section 8.E) ---
  const handleSaveBankSettings = (e: React.FormEvent) => {
    e.preventDefault();
    StorageService.updateBankSettings(bankForm);
    refreshData();
    setBankSavedMessage('Bank transfer account settings updated! Changes are live on customer checkout.');
    setTimeout(() => setBankSavedMessage(''), 3500);
    showToast('Bank details saved.');
  };

  // --- WEBSITE SETTINGS SAVE (Section 8.H) ---
  const handleSaveWebSettings = (e: React.FormEvent) => {
    e.preventDefault();
    StorageService.updateWebsiteSettings(webForm);
    refreshData();
    setWebSavedMessage('Website configuration saved.');
    setTimeout(() => setWebSavedMessage(''), 3500);
    showToast('Website settings saved.');
  };

  // Filtered Bookings List
  const filteredBookings = bookings.filter(b => {
    const matchesSearch = 
      b.trackingNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.destinationCity.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = typeFilter === 'all' || b.deliveryType === typeFilter;
    const matchesStatus = statusFilter === 'all' || b.bookingStatus === statusFilter;

    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-neutral-900 text-neutral-100 flex flex-col">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`fixed top-5 right-5 z-50 p-4 rounded-xl shadow-2xl border text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-top-2 duration-200 ${
          toastMessage.type === 'success' 
            ? 'bg-emerald-950 text-emerald-200 border-emerald-800' 
            : 'bg-rose-950 text-rose-200 border-rose-800'
        }`}>
          {toastMessage.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-rose-400" />}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Admin Top Header */}
      <header className="bg-neutral-950 border-b border-neutral-800 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-orange-600 flex items-center justify-center font-black text-white text-xs">
            SD
          </div>
          <div>
            <div className="font-extrabold tracking-tight text-white text-sm">SWIFTDROP Admin Console</div>
            <div className="text-[11px] text-neutral-400">Authenticated: <span className="text-orange-400 font-mono">@{adminSession?.username}</span></div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => onNavigate('home')}
            className="text-xs text-neutral-400 hover:text-white transition-colors"
          >
            Live Site
          </button>
          <span className="text-neutral-700">|</span>
          <button
            onClick={handleLogout}
            className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-rose-400 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main Admin Layout: Sidebar + Content */}
      <div className="flex-1 flex flex-col md:flex-row">
        
        {/* Navigation Sidebar */}
        <aside className="w-full md:w-64 bg-neutral-950 border-r border-neutral-800 p-4 space-y-1 shrink-0">
          <div className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider px-3 py-2">
            Operations & Control
          </div>

          <button
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-left ${
              activeTab === 'overview' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('bookings')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-left ${
              activeTab === 'bookings' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <Package className="w-4 h-4" />
              <span>Bookings Management</span>
            </div>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300">
              {totalBookings}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('deliveries')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-left ${
              activeTab === 'deliveries' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <Truck className="w-4 h-4" />
              <span>Delivery & Checkpoints</span>
            </div>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300">
              {packagesInTransit}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-left ${
              activeTab === 'payments' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <CreditCard className="w-4 h-4" />
              <span>Payment Receipts</span>
            </div>
            {pendingPayments > 0 && (
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500 text-black font-bold">
                {pendingPayments}
              </span>
            )}
          </button>

          <div className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider px-3 pt-6 pb-2">
            Configuration
          </div>

          <button
            onClick={() => setActiveTab('bank')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-left ${
              activeTab === 'bank' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>Bank Transfer Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('pricing')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-left ${
              activeTab === 'pricing' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>Pricing Matrix</span>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-left ${
              activeTab === 'customers' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Registered Clients</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-left ${
              activeTab === 'settings' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Website Info & WhatsApp</span>
          </button>

          <button
            onClick={() => setActiveTab('supabase')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-left ${
              activeTab === 'supabase' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Supabase & Cloudflare</span>
          </button>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 p-6 lg:p-8 space-y-8 overflow-y-auto">
          
          {/* TAB: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-8">
              
              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-tight">Logistics Operations Overview</h1>
                <p className="text-xs text-neutral-400 mt-1">Real-time metrics, payment audits, and shipment lifecycle.</p>
              </div>

              {/* 7 KPI Stat Cards (Section 8.A) */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                
                <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-1">
                  <div className="text-xs text-neutral-400">Total Bookings</div>
                  <div className="text-2xl font-bold font-mono text-white tabular-nums">{totalBookings}</div>
                  <div className="text-[11px] text-neutral-500">All registered shipments</div>
                </div>

                <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-1">
                  <div className="text-xs text-neutral-400">Total Customers</div>
                  <div className="text-2xl font-bold font-mono text-white tabular-nums">{totalCustomers}</div>
                  <div className="text-[11px] text-neutral-500">Verified corporate & clients</div>
                </div>

                <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-1">
                  <div className="text-xs text-neutral-400">Pending Payments</div>
                  <div className="text-2xl font-bold font-mono text-amber-400 tabular-nums">{pendingPayments}</div>
                  <div className="text-[11px] text-amber-500/80">Requires manual receipt review</div>
                </div>

                <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-1">
                  <div className="text-xs text-neutral-400">Approved Payments</div>
                  <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">{approvedPayments}</div>
                  <div className="text-[11px] text-emerald-500/80">Audited bank transfers</div>
                </div>

                <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-1">
                  <div className="text-xs text-neutral-400">Packages in Transit</div>
                  <div className="text-2xl font-bold font-mono text-orange-400 tabular-nums">{packagesInTransit}</div>
                  <div className="text-[11px] text-orange-500/80">Active on road / flights</div>
                </div>

                <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-1">
                  <div className="text-xs text-neutral-400">Delivered Packages</div>
                  <div className="text-2xl font-bold font-mono text-white tabular-nums">{deliveredPackages}</div>
                  <div className="text-[11px] text-neutral-500">Successfully completed</div>
                </div>

                <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-1 col-span-2">
                  <div className="text-xs text-neutral-400">Gross Freight Turnover</div>
                  <div className="text-2xl font-bold font-mono text-white tabular-nums">₦{totalRevenue.toLocaleString()}</div>
                  <div className="text-[11px] text-neutral-500">Direct manual bank transfer revenue</div>
                </div>

              </div>

              {/* Action Required: Pending Payment Receipts */}
              <div className="bg-neutral-950 rounded-2xl border border-neutral-800 p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-400" />
                    <h3 className="text-sm font-bold text-white">Pending Receipt Audit Queue</h3>
                  </div>
                  <button
                    onClick={() => setActiveTab('payments')}
                    className="text-xs text-orange-400 hover:text-orange-300 font-semibold"
                  >
                    View All Payments →
                  </button>
                </div>

                {payments.filter(p => p.paymentStatus === 'Receipt Submitted' || p.paymentStatus === 'Under Verification').length === 0 ? (
                  <div className="text-xs text-neutral-500 py-4 text-center">
                    All submitted transfer receipts have been audited. No pending approvals in queue.
                  </div>
                ) : (
                  <div className="divide-y divide-neutral-800">
                    {payments
                      .filter(p => p.paymentStatus === 'Receipt Submitted' || p.paymentStatus === 'Under Verification')
                      .map(p => (
                        <div key={p.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                          <div>
                            <span className="font-mono font-bold text-white">{p.trackingNumber}</span>
                            <span className="text-neutral-400 ml-2">Sender: {p.senderAccountName || 'Customer'} ({p.senderBankName})</span>
                            <div className="text-[11px] text-neutral-500">Ref: {p.transactionReference}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="font-mono font-bold text-white">₦{p.amount.toLocaleString()}</span>
                            <button
                              onClick={() => setViewingReceipt(p)}
                              className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg font-medium text-xs flex items-center gap-1 cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" /> Inspect Receipt
                            </button>
                            <button
                              onClick={() => handleApprovePayment(p.id)}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs cursor-pointer"
                            >
                              Approve
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB: BOOKINGS MANAGEMENT (Section 8.B) */}
          {activeTab === 'bookings' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-extrabold text-white tracking-tight">Booking Management</h1>
                  <p className="text-xs text-neutral-400 mt-1">Audit, edit, approve, or reject customer delivery bookings.</p>
                </div>
                <button
                  onClick={() => onNavigate('book-delivery')}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer self-start"
                >
                  <Plus className="w-4 h-4" /> Book New Package
                </button>
              </div>

              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    placeholder="Search by tracking number, customer name, email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <select
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value)}
                  className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-300"
                >
                  <option value="all">All Delivery Types</option>
                  <option value="local">Local Delivery</option>
                  <option value="nationwide">Nationwide</option>
                  <option value="international">International</option>
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-300"
                >
                  <option value="all">All Statuses</option>
                  <option value="Booking Received">Booking Received</option>
                  <option value="Payment Pending">Payment Pending</option>
                  <option value="Payment Confirmed">Payment Confirmed</option>
                  <option value="In Transit">In Transit</option>
                  <option value="Delivered">Delivered</option>
                </select>
              </div>

              {/* Table */}
              <div className="bg-neutral-950 rounded-2xl border border-neutral-800 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-neutral-900/60 text-neutral-400 uppercase tracking-wider border-b border-neutral-800">
                      <tr>
                        <th className="py-3 px-4">Tracking Code</th>
                        <th className="py-3 px-4">Customer</th>
                        <th className="py-3 px-4">Coverage</th>
                        <th className="py-3 px-4">Route</th>
                        <th className="py-3 px-4">Amount</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-850">
                      {filteredBookings.map(b => (
                        <tr key={b.id} className="hover:bg-neutral-900/50 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-white">{b.trackingNumber}</td>
                          <td className="py-3 px-4">
                            <div className="font-semibold text-white">{b.customerName}</div>
                            <div className="text-[11px] text-neutral-400">{b.customerEmail}</div>
                          </td>
                          <td className="py-3 px-4 capitalize text-neutral-300">{b.deliveryType}</td>
                          <td className="py-3 px-4 text-neutral-300">
                            {b.pickupCity} → {b.destinationCity}
                          </td>
                          <td className="py-3 px-4 font-mono font-semibold text-white">₦{b.totalAmount.toLocaleString()}</td>
                          <td className="py-3 px-4">
                            <StatusBadge status={b.bookingStatus} type="delivery" />
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => setEditingBooking(b)}
                                className="p-1.5 hover:bg-neutral-800 rounded text-neutral-300 hover:text-white"
                                title="Edit Booking Details"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => {
                                  setAddCheckpointBooking(b);
                                  setCheckpointForm({
                                    status: b.bookingStatus,
                                    location: `${b.pickupCity} Terminal`,
                                    notes: '',
                                  });
                                }}
                                className="p-1.5 hover:bg-neutral-800 rounded text-orange-400 hover:text-orange-300"
                                title="Add Tracking Waypoint"
                              >
                                <MapPin className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB: DELIVERIES & CHECKPOINTS (Section 8.C) */}
          {activeTab === 'deliveries' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-tight">Delivery & Waypoints Log</h1>
                <p className="text-xs text-neutral-400 mt-1">Update fulfillment progress and log physical transit checkpoints.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {bookings.map(b => {
                  const checkList = StorageService.getTrackingCheckpoints(b.trackingNumber);
                  return (
                    <div key={b.id} className="bg-neutral-950 p-6 rounded-2xl border border-neutral-800 space-y-4 flex flex-col justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-white text-sm">{b.trackingNumber}</span>
                          <span className="text-[10px] uppercase font-bold text-orange-400">{b.deliveryType}</span>
                        </div>
                        <div className="text-xs text-neutral-400">
                          {b.pickupCity} → {b.destinationCity}, {b.destinationCountry}
                        </div>
                        <div className="pt-2">
                          <StatusBadge status={b.bookingStatus} type="delivery" />
                        </div>
                        <div className="text-[11px] text-neutral-500 font-mono">
                          {checkList.length} checkpoint{checkList.length === 1 ? '' : 's'} recorded
                        </div>
                      </div>

                      <div className="pt-4 border-t border-neutral-900 flex items-center justify-between">
                        <button
                          onClick={() => {
                            setAddCheckpointBooking(b);
                            setCheckpointForm({
                              status: 'In Transit',
                              location: `${b.destinationCity} Gateway`,
                              notes: 'Consignment departed transit terminal.',
                            });
                          }}
                          className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold cursor-pointer"
                        >
                          + Add Checkpoint
                        </button>
                        <button
                          onClick={() => onNavigate('track-package', { trackingNumber: b.trackingNumber })}
                          className="text-xs text-neutral-400 hover:text-white"
                        >
                          Live View →
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB: PAYMENTS MANAGEMENT (Section 8.D) */}
          {activeTab === 'payments' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-tight">Payment Receipts Management</h1>
                <p className="text-xs text-neutral-400 mt-1">Inspect uploaded bank transfer receipts and approve or reject payments.</p>
              </div>

              <div className="bg-neutral-950 rounded-2xl border border-neutral-800 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-neutral-900/60 text-neutral-400 uppercase tracking-wider border-b border-neutral-800">
                      <tr>
                        <th className="py-3 px-4">Tracking Code</th>
                        <th className="py-3 px-4">Sender Details</th>
                        <th className="py-3 px-4">Amount</th>
                        <th className="py-3 px-4">Bank Paid To</th>
                        <th className="py-3 px-4">Receipt Attached</th>
                        <th className="py-3 px-4">Audit Status</th>
                        <th className="py-3 px-4 text-right">Review Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-850">
                      {payments.map(p => (
                        <tr key={p.id} className="hover:bg-neutral-900/50 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-white">{p.trackingNumber}</td>
                          <td className="py-3 px-4">
                            <div className="font-semibold text-white">{p.senderAccountName || 'Pending Customer'}</div>
                            <div className="text-[11px] text-neutral-400">{p.senderBankName || '—'} · Ref: {p.transactionReference || '—'}</div>
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-white">₦{p.amount.toLocaleString()}</td>
                          <td className="py-3 px-4 text-neutral-300">{p.bankNamePaidTo}</td>
                          <td className="py-3 px-4">
                            {p.receiptImageUrl ? (
                              <button
                                onClick={() => setViewingReceipt(p)}
                                className="text-xs font-semibold text-orange-400 hover:text-orange-300 flex items-center gap-1 cursor-pointer"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>View Receipt</span>
                              </button>
                            ) : (
                              <span className="text-neutral-500 italic">No receipt yet</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <StatusBadge status={p.paymentStatus} type="payment" />
                          </td>
                          <td className="py-3 px-4 text-right">
                            {p.paymentStatus !== 'Payment Approved' ? (
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  onClick={() => handleApprovePayment(p.id)}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs font-bold cursor-pointer"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => setRejectingPayment(p)}
                                  className="px-2.5 py-1 bg-rose-900/80 hover:bg-rose-800 text-rose-200 rounded-md text-xs font-semibold cursor-pointer"
                                >
                                  Reject
                                </button>
                              </div>
                            ) : (
                              <span className="text-[11px] text-emerald-400 font-semibold flex items-center justify-end gap-1">
                                <Check className="w-3.5 h-3.5" /> Approved
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB: BANK TRANSFER SETTINGS (Section 8.E) */}
          {activeTab === 'bank' && (
            <div className="max-w-2xl bg-neutral-950 p-6 sm:p-8 rounded-2xl border border-neutral-800 space-y-6">
              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-tight">Bank Transfer Settings</h1>
                <p className="text-xs text-neutral-400 mt-1">
                  Configure the corporate bank account details displayed to customers during manual bank transfer checkout.
                </p>
              </div>

              {bankSavedMessage && (
                <div className="p-3.5 bg-emerald-950/80 border border-emerald-800 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{bankSavedMessage}</span>
                </div>
              )}

              <form onSubmit={handleSaveBankSettings} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Bank Name *</label>
                  <input
                    type="text"
                    required
                    value={bankForm.bankName}
                    onChange={(e) => setBankForm({ ...bankForm, bankName: e.target.value })}
                    placeholder="e.g. Zenith Bank Nigeria"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Account Name *</label>
                  <input
                    type="text"
                    required
                    value={bankForm.accountName}
                    onChange={(e) => setBankForm({ ...bankForm, accountName: e.target.value })}
                    placeholder="e.g. SWIFTDROP LOGISTICS LTD"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Account Number *</label>
                  <input
                    type="text"
                    required
                    value={bankForm.accountNumber}
                    onChange={(e) => setBankForm({ ...bankForm, accountNumber: e.target.value })}
                    placeholder="e.g. 1019842590"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Sort Code / Branch (Optional)</label>
                  <input
                    type="text"
                    value={bankForm.sortCode || ''}
                    onChange={(e) => setBankForm({ ...bankForm, sortCode: e.target.value })}
                    placeholder="057150013"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Customer Instructions</label>
                  <textarea
                    rows={3}
                    value={bankForm.instructions || ''}
                    onChange={(e) => setBankForm({ ...bankForm, instructions: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <button
                  type="submit"
                  className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
                >
                  Save Bank Account Settings
                </button>
              </form>
            </div>
          )}

          {/* TAB: PRICING MANAGEMENT (Section 8.F) */}
          {activeTab === 'pricing' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-tight">Pricing Management</h1>
                <p className="text-xs text-neutral-400 mt-1">Adjust base delivery prices and per-kg rates for local, nationwide, and international shipments.</p>
              </div>

              <div className="bg-neutral-950 rounded-2xl border border-neutral-800 overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-900/60 text-neutral-400 uppercase tracking-wider border-b border-neutral-800">
                    <tr>
                      <th className="py-3 px-4">Tier / Destination</th>
                      <th className="py-3 px-4">Type</th>
                      <th className="py-3 px-4">Base Rate (₦)</th>
                      <th className="py-3 px-4">Per Kg Rate (₦)</th>
                      <th className="py-3 px-4">Est. Days</th>
                      <th className="py-3 px-4 text-right">Quick Save</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-850">
                    {pricing.map(p => (
                      <tr key={p.id} className="hover:bg-neutral-900/50">
                        <td className="py-3 px-4 font-bold text-white">{p.destinationRegion}</td>
                        <td className="py-3 px-4 capitalize text-neutral-400">{p.deliveryType}</td>
                        <td className="py-3 px-4">
                          <input
                            type="number"
                            value={p.basePrice}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              setPricing(prev => prev.map(item => item.id === p.id ? { ...item, basePrice: val } : item));
                            }}
                            className="w-24 px-2 py-1 bg-neutral-900 border border-neutral-800 rounded text-xs font-mono text-white"
                          />
                        </td>
                        <td className="py-3 px-4">
                          <input
                            type="number"
                            value={p.pricePerKg}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              setPricing(prev => prev.map(item => item.id === p.id ? { ...item, pricePerKg: val } : item));
                            }}
                            className="w-24 px-2 py-1 bg-neutral-900 border border-neutral-800 rounded text-xs font-mono text-white"
                          />
                        </td>
                        <td className="py-3 px-4 font-mono text-neutral-300">
                          {p.estimatedDaysMin}-{p.estimatedDaysMax} days
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => {
                              StorageService.updatePricing(p.id, { basePrice: p.basePrice, pricePerKg: p.pricePerKg });
                              showToast(`Updated rates for ${p.destinationRegion}`);
                            }}
                            className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs font-semibold cursor-pointer"
                          >
                            Save
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: CUSTOMER MANAGEMENT (Section 8.G) */}
          {activeTab === 'customers' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-tight">Registered Customers</h1>
                <p className="text-xs text-neutral-400 mt-1">Review customer profiles, contact numbers, and lifetime delivery volume.</p>
              </div>

              <div className="bg-neutral-950 rounded-2xl border border-neutral-800 overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-900/60 text-neutral-400 uppercase tracking-wider border-b border-neutral-800">
                    <tr>
                      <th className="py-3 px-4">Customer Name</th>
                      <th className="py-3 px-4">Email</th>
                      <th className="py-3 px-4">Phone</th>
                      <th className="py-3 px-4">City / State</th>
                      <th className="py-3 px-4">Bookings</th>
                      <th className="py-3 px-4 text-right">Total Spent</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-850">
                    {customers.map(c => (
                      <tr key={c.id} className="hover:bg-neutral-900/50">
                        <td className="py-3 px-4 font-bold text-white">{c.fullName}</td>
                        <td className="py-3 px-4 text-neutral-400">{c.email}</td>
                        <td className="py-3 px-4 font-mono text-neutral-300">{c.phone}</td>
                        <td className="py-3 px-4 text-neutral-300">{c.city}, {c.state}</td>
                        <td className="py-3 px-4 font-mono text-white">{c.totalBookings}</td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                          ₦{(c.totalSpent || 0).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: WEBSITE SETTINGS (Section 8.H) */}
          {activeTab === 'settings' && (
            <div className="max-w-2xl bg-neutral-950 p-6 sm:p-8 rounded-2xl border border-neutral-800 space-y-6">
              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-tight">Website & WhatsApp Settings</h1>
                <p className="text-xs text-neutral-400 mt-1">Update company telephone, official WhatsApp contact number, and office address.</p>
              </div>

              {webSavedMessage && (
                <div className="p-3.5 bg-emerald-950/80 border border-emerald-800 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{webSavedMessage}</span>
                </div>
              )}

              <form onSubmit={handleSaveWebSettings} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Company Display Name</label>
                  <input
                    type="text"
                    value={webForm.companyName}
                    onChange={(e) => setWebForm({ ...webForm, companyName: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Company WhatsApp Number (e.g. 09024971419)</label>
                  <input
                    type="text"
                    value={webForm.whatsappNumber}
                    onChange={(e) => setWebForm({ ...webForm, whatsappNumber: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Support Email</label>
                  <input
                    type="email"
                    value={webForm.contactEmail}
                    onChange={(e) => setWebForm({ ...webForm, contactEmail: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Direct Phone Number</label>
                  <input
                    type="text"
                    value={webForm.phoneNumber}
                    onChange={(e) => setWebForm({ ...webForm, phoneNumber: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Headquarters Office Address</label>
                  <textarea
                    rows={2}
                    value={webForm.officeAddress}
                    onChange={(e) => setWebForm({ ...webForm, officeAddress: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <button
                  type="submit"
                  className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
                >
                  Save Website Configuration
                </button>
              </form>
            </div>
          )}

          {/* TAB: SUPABASE & CLOUDFLARE SYNC (Section 10 & 14) */}
          {activeTab === 'supabase' && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-tight">Supabase & Cloudflare Deployment Sync</h1>
                <p className="text-xs text-neutral-400 mt-1">Integration bridge for persistent PostgreSQL database and Cloudflare Pages production distribution.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Supabase Status Box */}
                <div className="bg-neutral-950 p-6 rounded-2xl border border-neutral-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">Supabase Connection</span>
                    <span className="text-[11px] font-mono text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Connected
                    </span>
                  </div>
                  <div className="space-y-1 text-xs text-neutral-300">
                    <div className="text-[11px] text-neutral-400">Endpoint:</div>
                    <div className="font-mono text-orange-400 text-[11px] bg-neutral-900 px-2 py-1 rounded truncate">
                      {SUPABASE_URL}
                    </div>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Database tables: <code className="text-white">profiles</code>, <code className="text-white">customers</code>, <code className="text-white">bookings</code>, <code className="text-white">payments</code>, <code className="text-white">bank_settings</code>, <code className="text-white">tracking_history</code>.
                  </p>
                  
                  <div className="pt-1">
                    <button
                      type="button"
                      disabled={testingDb}
                      onClick={handleTestSupabase}
                      className="px-3.5 py-1.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      {testingDb ? <Clock className="w-3.5 h-3.5 animate-spin" /> : <Database className="w-3.5 h-3.5" />}
                      <span>{testingDb ? 'Pinging Supabase...' : 'Test Database Connection'}</span>
                    </button>
                    {dbTestResult && (
                      <div className="mt-2 p-2.5 bg-neutral-900 border border-neutral-800 rounded-lg text-[11px] text-neutral-300 font-mono">
                        {dbTestResult}
                      </div>
                    )}
                  </div>

                  <div className="text-[11px] text-neutral-500 pt-1 border-t border-neutral-900">
                    SQL Migration script is ready in <code className="text-orange-400">/supabase/schema.sql</code>.
                  </div>
                </div>

                {/* Cloudflare Pages Box */}
                <div className="bg-neutral-950 p-6 rounded-2xl border border-neutral-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">Cloudflare Pages Spec</span>
                    <span className="text-[11px] font-mono text-orange-400 font-bold">SPA Configured</span>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Build command: <code className="text-white">npm run build</code><br />
                    Output directory: <code className="text-white">dist</code><br />
                    SPA Routing rule: <code className="text-white">public/_redirects</code>
                  </p>
                  <div className="text-[11px] text-neutral-500">
                    Includes automatic 200 rewrite rule and security cache headers.
                  </div>
                </div>

              </div>

              {/* SQL Schema Preview */}
              <div className="bg-neutral-950 p-6 rounded-2xl border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">Complete PostgreSQL Schema & RLS Policies</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('-- Run /supabase/schema.sql in your Supabase SQL Editor');
                      showToast('Copied SQL reference note.');
                    }}
                    className="text-xs text-orange-400 hover:text-orange-300 font-semibold flex items-center gap-1"
                  >
                    <Copy className="w-3.5 h-3.5" /> Copy SQL Path
                  </button>
                </div>
                <div className="p-3 bg-neutral-900 rounded-xl text-neutral-300 font-mono text-[11px] overflow-x-auto max-h-48">
                  <pre>{`-- SWIFTDROP SUPABASE DATABASE
CREATE TABLE public.bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tracking_number TEXT NOT NULL UNIQUE,
    customer_name TEXT NOT NULL,
    customer_email TEXT NOT NULL,
    total_amount NUMERIC(12, 2) NOT NULL,
    booking_status TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);
-- See /supabase/schema.sql for complete tables & RLS policies`}</pre>
                </div>
              </div>

            </div>
          )}

        </main>
      </div>

      {/* MODAL 1: VIEW RECEIPT MODAL */}
      {viewingReceipt && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-950 text-white rounded-3xl p-6 sm:p-8 max-w-lg w-full border border-neutral-800 space-y-5 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white">Manual Bank Transfer Receipt</h3>
                <span className="text-xs font-mono text-orange-400">{viewingReceipt.trackingNumber}</span>
              </div>
              <button
                onClick={() => setViewingReceipt(null)}
                className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-neutral-300">
              <div className="flex justify-between">
                <span>Sender Account Name:</span>
                <span className="font-bold text-white">{viewingReceipt.senderAccountName || 'Customer'}</span>
              </div>
              <div className="flex justify-between">
                <span>Sender Bank:</span>
                <span className="font-bold text-white">{viewingReceipt.senderBankName || '—'}</span>
              </div>
              <div className="flex justify-between">
                <span>Transaction Ref:</span>
                <span className="font-mono text-neutral-300">{viewingReceipt.transactionReference || '—'}</span>
              </div>
              <div className="flex justify-between">
                <span>Amount:</span>
                <span className="font-mono text-lg font-bold text-white">₦{viewingReceipt.amount.toLocaleString()}</span>
              </div>
            </div>

            {/* Receipt Image Container */}
            <div className="rounded-xl overflow-hidden border border-neutral-800 bg-neutral-900 max-h-64 flex items-center justify-center p-2">
              {viewingReceipt.receiptImageUrl ? (
                <img
                  src={viewingReceipt.receiptImageUrl}
                  alt="Bank transfer receipt"
                  className="max-h-60 object-contain rounded-lg"
                />
              ) : (
                <div className="text-xs text-neutral-500 py-8">No preview available</div>
              )}
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => handleApprovePayment(viewingReceipt.id)}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Approve Payment (₦{viewingReceipt.amount.toLocaleString()})
              </button>
              <button
                onClick={() => {
                  setRejectingPayment(viewingReceipt);
                  setViewingReceipt(null);
                }}
                className="px-4 py-2.5 bg-rose-900/70 hover:bg-rose-800 text-rose-200 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Reject Receipt
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: REJECT PAYMENT PROMPT */}
      {rejectingPayment && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-950 text-white rounded-3xl p-6 max-w-md w-full border border-neutral-800 space-y-4">
            <h3 className="text-sm font-bold text-white">Reject Transfer Receipt</h3>
            <p className="text-xs text-neutral-400">
              Provide a clear reason for rejecting this payment for <span className="font-mono font-bold text-white">{rejectingPayment.trackingNumber}</span>. The customer will see this message.
            </p>
            <form onSubmit={handleRejectPaymentSubmit} className="space-y-4">
              <textarea
                required
                rows={3}
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="e.g. Incomplete transaction details or blurry screenshot. Please re-upload official bank receipt."
                className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-rose-500"
              />
              <div className="flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold"
                >
                  Confirm Rejection
                </button>
                <button
                  type="button"
                  onClick={() => setRejectingPayment(null)}
                  className="px-4 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-xl text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: EDIT BOOKING STATUS & DETAILS */}
      {editingBooking && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-950 text-white rounded-3xl p-6 sm:p-8 max-w-md w-full border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-sm font-bold text-white">Edit Shipment Status</h3>
              <button onClick={() => setEditingBooking(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBookingEdit} className="space-y-4 text-xs">
              <div>
                <label className="block text-neutral-400 mb-1">Tracking Number</label>
                <input
                  type="text"
                  value={editingBooking.trackingNumber}
                  onChange={(e) => setEditingBooking({ ...editingBooking, trackingNumber: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl font-mono text-white"
                />
              </div>

              <div>
                <label className="block text-neutral-400 mb-1">Delivery Status</label>
                <select
                  value={editingBooking.bookingStatus}
                  onChange={(e) => setEditingBooking({ ...editingBooking, bookingStatus: e.target.value as DeliveryStatus })}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white"
                >
                  <option value="Booking Received">Booking Received</option>
                  <option value="Payment Pending">Payment Pending</option>
                  <option value="Payment Confirmed">Payment Confirmed</option>
                  <option value="Package Picked Up">Package Picked Up</option>
                  <option value="In Transit">In Transit</option>
                  <option value="Arrived at Destination">Arrived at Destination</option>
                  <option value="Out for Delivery">Out for Delivery</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-400 mb-1">Estimated Delivery Date</label>
                <input
                  type="date"
                  value={editingBooking.estimatedDeliveryDate || ''}
                  onChange={(e) => setEditingBooking({ ...editingBooking, estimatedDeliveryDate: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white"
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold"
                >
                  Save Changes
                </button>
                <button
                  type="button"
                  onClick={() => setEditingBooking(null)}
                  className="px-4 py-2.5 bg-neutral-800 text-neutral-300 rounded-xl"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: ADD CHECKPOINT MODAL */}
      {addCheckpointBooking && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-950 text-white rounded-3xl p-6 sm:p-8 max-w-md w-full border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-sm font-bold text-white">Log Transit Waypoint Checkpoint</h3>
              <button onClick={() => setAddCheckpointBooking(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-neutral-400">
              Logging checkpoint for: <span className="font-mono text-orange-400 font-bold">{addCheckpointBooking.trackingNumber}</span>
            </p>

            <form onSubmit={handleAddCheckpoint} className="space-y-4 text-xs">
              <div>
                <label className="block text-neutral-400 mb-1">Checkpoint Status</label>
                <select
                  value={checkpointForm.status}
                  onChange={(e) => setCheckpointForm({ ...checkpointForm, status: e.target.value as DeliveryStatus })}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white"
                >
                  <option value="Package Picked Up">Package Picked Up</option>
                  <option value="In Transit">In Transit</option>
                  <option value="Arrived at Destination">Arrived at Destination</option>
                  <option value="Out for Delivery">Out for Delivery</option>
                  <option value="Delivered">Delivered</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-400 mb-1">Physical Location / Hub *</label>
                <input
                  type="text"
                  required
                  value={checkpointForm.location}
                  onChange={(e) => setCheckpointForm({ ...checkpointForm, location: e.target.value })}
                  placeholder="e.g. Ore Expressway Transit Tollgate or Abuja Hub"
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white"
                />
              </div>

              <div>
                <label className="block text-neutral-400 mb-1">Operational Notes (Optional)</label>
                <textarea
                  rows={2}
                  value={checkpointForm.notes}
                  onChange={(e) => setCheckpointForm({ ...checkpointForm, notes: e.target.value })}
                  placeholder="e.g. Scanned at regional sorter. Scheduled for dispatch van #12."
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white"
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold"
                >
                  Log Waypoint Checkpoint
                </button>
                <button
                  type="button"
                  onClick={() => setAddCheckpointBooking(null)}
                  className="px-4 py-2.5 bg-neutral-800 text-neutral-300 rounded-xl"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
