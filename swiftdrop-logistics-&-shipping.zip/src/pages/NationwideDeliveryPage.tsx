import React from 'react';
import { IMAGES } from '../assets/images';
import { CheckCircle2, MapPin, Truck, ArrowRight, ShieldCheck, Clock, Shield } from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface NationwideDeliveryPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const NationwideDeliveryPage: React.FC<NationwideDeliveryPageProps> = ({ onNavigate }) => {
  const regions = [
    {
      name: 'South-West Corridor',
      states: 'Lagos, Ogun, Oyo, Osun, Ondo, Ekiti',
      transit: '1 - 2 Business Days',
      rate: 'From ₦6,500',
    },
    {
      name: 'South-South & Niger Delta',
      states: 'Rivers, Delta, Edo, Akwa Ibom, Cross River, Bayelsa',
      transit: '2 - 3 Business Days',
      rate: 'From ₦6,500',
    },
    {
      name: 'South-East Region',
      states: 'Enugu, Anambra, Imo, Abia, Ebonyi',
      transit: '2 - 3 Business Days',
      rate: 'From ₦6,500',
    },
    {
      name: 'North-Central & Federal Capital',
      states: 'Abuja (FCT), Plateau, Benue, Kwara, Niger, Nasarawa, Kogi',
      transit: '2 - 4 Business Days',
      rate: 'From ₦7,500',
    },
    {
      name: 'North-West Commercial Hubs',
      states: 'Kano, Kaduna, Sokoto, Katsina, Zamfara, Kebbi, Jigawa',
      transit: '3 - 5 Business Days',
      rate: 'From ₦8,500',
    },
    {
      name: 'North-East Network',
      states: 'Bauchi, Gombe, Adamawa, Taraba, Borno, Yobe',
      transit: '3 - 5 Business Days',
      rate: 'From ₦8,500',
    },
  ];

  return (
    <div className="space-y-16 pb-20">
      
      {/* Hero */}
      <section className="bg-neutral-950 text-white py-16 border-b border-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="text-xs font-bold text-orange-400 uppercase tracking-widest">Interstate Cargo & Parcel Logistics</div>
              <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
                Nationwide Delivery Across All 36 Nigerian States & FCT
              </h1>
              <p className="text-sm text-neutral-300 leading-relaxed">
                Seamlessly distribute commercial inventory, spare parts, merchandise, and personal packages between any cities in Nigeria. Operating dedicated interstate highway carriers with 24/7 telematics and terminal checkpoints.
              </p>
              <div className="pt-2 flex flex-wrap gap-4">
                <button
                  onClick={() => onNavigate('book-delivery', { deliveryType: 'nationwide' })}
                  className="px-6 py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Book Nationwide Delivery</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <WhatsAppButton variant="button" label="Inquire on WhatsApp" className="text-xs py-3.5" />
              </div>
            </div>
            <div className="lg:col-span-5">
              <div className="rounded-2xl overflow-hidden border border-neutral-800 shadow-xl">
                <img
                  src={IMAGES.warehouseHub}
                  alt="Nationwide logistics sorting terminal"
                  className="w-full h-80 object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Regional Zones Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">State-By-State Network</div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900">
            Regional Transit Schedules & Rates
          </h2>
          <p className="text-xs sm:text-sm text-neutral-600">
            Predictable delivery timelines connecting businesses and families nationwide.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {regions.map((region, idx) => (
            <div key={idx} className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-neutral-900">{region.name}</span>
                  <span className="text-xs font-bold font-mono text-orange-600">{region.rate}</span>
                </div>
                <div className="text-[11px] text-neutral-500 font-medium mt-1">
                  Est. Transit: <span className="text-neutral-800">{region.transit}</span>
                </div>
                <p className="text-xs text-neutral-600 mt-3 leading-relaxed">
                  <span className="font-semibold text-neutral-700">States Covered:</span> {region.states}
                </p>
              </div>

              <div className="pt-3 border-t border-neutral-100 flex items-center justify-between">
                <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Doorstep or Hub Drop
                </span>
                <button
                  onClick={() => onNavigate('book-delivery', { deliveryType: 'nationwide' })}
                  className="text-xs font-bold text-orange-600 hover:text-orange-700"
                >
                  Book →
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-neutral-900 text-white rounded-2xl p-8 sm:p-10 border border-neutral-800 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-2">
            <div className="w-9 h-9 rounded-lg bg-orange-600 flex items-center justify-center text-white">
              <Truck className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white">GPS Fleet Telematics</h4>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Every interstate carrier is tracked via real-time satellite GPS, preventing route deviations and ensuring timely transit arrivals.
            </p>
          </div>

          <div className="space-y-2">
            <div className="w-9 h-9 rounded-lg bg-orange-600 flex items-center justify-center text-white">
              <Shield className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white">Tamper-Proof Barcode Seals</h4>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Consignments are scanned at each state sorting hub before loading onto regional last-mile delivery vans.
            </p>
          </div>

          <div className="space-y-2">
            <div className="w-9 h-9 rounded-lg bg-orange-600 flex items-center justify-center text-white">
              <Clock className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white">Scheduled Departures</h4>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Consignments do not sit idle in warehouses waiting for full loads. Our scheduled route trucks depart on timetable schedules daily.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
