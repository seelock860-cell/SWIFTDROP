import React, { useState, useEffect } from 'react';
import { StorageService } from '../services/storageService';
import { Booking, TrackingCheckpoint, PaymentRecord } from '../types';
import { StatusBadge } from '../components/common/StatusBadge';
import { 
  Search, 
  MapPin, 
  Calendar, 
  Clock, 
  Truck, 
  Package, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  ExternalLink,
  ShieldCheck,
  CreditCard
} from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface TrackPackagePageProps {
  initialTrackingNumber?: string;
  onNavigate: (page: string, params?: any) => void;
}

export const TrackPackagePage: React.FC<TrackPackagePageProps> = ({ 
  initialTrackingNumber = '', 
  onNavigate 
}) => {
  const [searchInput, setSearchInput] = useState(initialTrackingNumber);
  const [currentTrackingNumber, setCurrentTrackingNumber] = useState(initialTrackingNumber);
  const [booking, setBooking] = useState<Booking | null>(null);
  const [checkpoints, setCheckpoints] = useState<TrackingCheckpoint[]>([]);
  const [payment, setPayment] = useState<PaymentRecord | null>(null);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');

  const performSearch = (num: string) => {
    setError('');
    const clean = num.trim().toUpperCase();
    if (!clean) return;

    setCurrentTrackingNumber(clean);
    setSearched(true);

    const foundBooking = StorageService.getBookingByTrackingNumber(clean);
    if (foundBooking) {
      setBooking(foundBooking);
      const points = StorageService.getTrackingCheckpoints(clean);
      setCheckpoints(points);
      const p = StorageService.getPaymentByBookingId(foundBooking.id);
      setPayment(p);
    } else {
      setBooking(null);
      setCheckpoints([]);
      setPayment(null);
      setError(`No shipment found matching tracking ID "${clean}". Please verify your code.`);
    }
  };

  useEffect(() => {
    if (initialTrackingNumber) {
      setSearchInput(initialTrackingNumber);
      performSearch(initialTrackingNumber);
    }
  }, [initialTrackingNumber]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(searchInput);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      
      {/* Search Header */}
      <div className="max-w-2xl mx-auto text-center space-y-4">
        <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Live Milestone Tracking</div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
          Track Your Consignment
        </h1>
        <p className="text-xs sm:text-sm text-neutral-600">
          Enter your official SWIFTDROP tracking code to view verified facility checkpoints and delivery progression.
        </p>

        {/* Search Input Box */}
        <form onSubmit={handleSubmit} className="pt-2">
          <div className="flex flex-col sm:flex-row gap-2 bg-white p-2 rounded-2xl border border-neutral-300 shadow-md">
            <div className="relative flex-1 flex items-center">
              <Search className="w-5 h-5 text-neutral-400 absolute left-3.5" />
              <input
                type="text"
                placeholder="e.g. SWD-2026-89412"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="w-full pl-11 pr-4 py-3 text-sm text-neutral-900 placeholder-neutral-400 bg-transparent focus:outline-none uppercase font-mono font-semibold"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 bg-neutral-950 hover:bg-neutral-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Track Package</span>
              <ArrowRight className="w-4 h-4 text-orange-500" />
            </button>
          </div>
        </form>

        {/* Quick Sample Links */}
        <div className="flex items-center justify-center gap-3 text-xs text-neutral-500 pt-1">
          <span>Try demo tracking numbers:</span>
          <button
            type="button"
            onClick={() => { setSearchInput('SWD-2026-89412'); performSearch('SWD-2026-89412'); }}
            className="text-orange-600 font-mono font-semibold hover:underline"
          >
            SWD-2026-89412
          </button>
          <span>·</span>
          <button
            type="button"
            onClick={() => { setSearchInput('SWD-2026-63104'); performSearch('SWD-2026-63104'); }}
            className="text-orange-600 font-mono font-semibold hover:underline"
          >
            SWD-2026-63104
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 text-center flex items-center justify-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600" />
          <span>{error}</span>
        </div>
      )}

      {/* Shipment Details & Timeline */}
      {booking && (
        <div className="space-y-8 animate-in fade-in duration-300">
          
          {/* Status Header Banner */}
          <div className="bg-neutral-950 text-white rounded-2xl p-6 sm:p-8 border border-neutral-800 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-800 pb-5">
              <div>
                <div className="text-[11px] font-mono text-neutral-400 uppercase tracking-wider">Tracking Number</div>
                <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white tracking-tight mt-0.5">
                  {booking.trackingNumber}
                </div>
              </div>
              <div className="flex flex-col sm:items-end">
                <div className="text-[11px] text-neutral-400 uppercase tracking-wide">Current Delivery Status</div>
                <div className="mt-1 bg-neutral-900 px-3 py-1.5 rounded-lg border border-neutral-800">
                  <StatusBadge status={booking.bookingStatus} type="delivery" className="text-white text-xs" />
                </div>
              </div>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-xs">
              <div>
                <span className="text-neutral-400 block">Delivery Type</span>
                <span className="text-white font-semibold capitalize mt-0.5 block">{booking.deliveryType} Delivery</span>
              </div>
              <div>
                <span className="text-neutral-400 block">Origin</span>
                <span className="text-white font-semibold mt-0.5 block truncate">{booking.pickupCity}, {booking.pickupCountry}</span>
              </div>
              <div>
                <span className="text-neutral-400 block">Destination</span>
                <span className="text-white font-semibold mt-0.5 block truncate">{booking.destinationCity}, {booking.destinationCountry}</span>
              </div>
              <div>
                <span className="text-neutral-400 block">Est. Delivery</span>
                <span className="text-orange-400 font-semibold font-mono mt-0.5 block">
                  {booking.estimatedDeliveryDate || 'Processing'}
                </span>
              </div>
            </div>

            {/* Action Bar if payment pending */}
            {booking.bookingStatus === 'Payment Pending' && (
              <div className="pt-4 border-t border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-amber-950/40 p-4 rounded-xl border-amber-800/50">
                <div className="text-xs text-amber-200">
                  <span className="font-bold">Manual Bank Payment Required:</span> This shipment requires bank transfer confirmation before courier dispatch.
                </div>
                <button
                  onClick={() => onNavigate('checkout', { bookingId: booking.id })}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Transfer / Upload Receipt</span>
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left: Interactive Checkpoints Timeline */}
            <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-7 border border-neutral-200 shadow-sm space-y-6">
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <h3 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-orange-600" />
                  <span>Milestone Tracking History</span>
                </h3>
                <span className="text-[11px] text-neutral-500 font-mono">
                  {checkpoints.length} checkpoint{checkpoints.length === 1 ? '' : 's'} recorded
                </span>
              </div>

              {checkpoints.length === 0 ? (
                <div className="text-center py-8 text-xs text-neutral-500">
                  No tracking milestones logged yet.
                </div>
              ) : (
                <div className="relative pl-6 space-y-8 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-neutral-200">
                  {checkpoints.map((cp, idx) => {
                    const isLatest = idx === checkpoints.length - 1;
                    return (
                      <div key={cp.id || idx} className="relative group">
                        {/* Dot indicator */}
                        <div className={`absolute -left-6 top-1 w-4 h-4 rounded-full border-2 bg-white flex items-center justify-center ${
                          isLatest ? 'border-orange-600 ring-4 ring-orange-100' : 'border-neutral-400'
                        }`}>
                          <div className={`w-1.5 h-1.5 rounded-full ${isLatest ? 'bg-orange-600' : 'bg-neutral-400'}`} />
                        </div>

                        <div className="space-y-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-bold text-neutral-900">
                              {cp.status}
                            </span>
                            <span className="text-[11px] font-mono text-neutral-500">
                              {new Date(cp.timestamp).toLocaleString('en-NG', {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 text-xs text-neutral-600 font-medium">
                            <MapPin className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                            <span>{cp.location}</span>
                          </div>

                          {cp.notes && (
                            <p className="text-xs text-neutral-500 leading-relaxed pt-0.5">
                              {cp.notes}
                            </p>
                          )}

                          <div className="text-[10px] text-neutral-400 pt-0.5">
                            Logged by: {cp.recordedBy}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Right: Consignment & Sender Details */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Package Details Box */}
              <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-sm space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-900 border-b border-neutral-100 pb-3">
                  Consignment Particulars
                </h4>

                <div className="space-y-3 text-xs text-neutral-600">
                  <div className="flex justify-between">
                    <span>Sender Name:</span>
                    <span className="font-semibold text-neutral-900">{booking.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Package Weight:</span>
                    <span className="font-semibold text-neutral-900 font-mono">{booking.packageWeight} kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Category:</span>
                    <span className="font-semibold text-neutral-900 capitalize">{booking.packageCategory}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Description:</span>
                    <span className="font-medium text-neutral-900 truncate max-w-[200px]" title={booking.packageDescription}>
                      {booking.packageDescription}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pickup Address:</span>
                    <span className="font-medium text-neutral-900 truncate max-w-[200px]" title={booking.pickupAddress}>
                      {booking.pickupAddress}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Destination Address:</span>
                    <span className="font-medium text-neutral-900 truncate max-w-[200px]" title={booking.destinationAddress}>
                      {booking.destinationAddress}
                    </span>
                  </div>
                </div>

                <div className="border-t border-neutral-100 pt-3 flex justify-between items-center text-xs">
                  <span className="text-neutral-500">Declared Fee:</span>
                  <span className="text-sm font-bold font-mono text-neutral-900">
                    ₦{booking.totalAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Verified Security Support Card */}
              <div className="bg-neutral-50 rounded-2xl p-6 border border-neutral-200 space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-neutral-900">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>SWIFTDROP Dispatch Support</span>
                </div>
                <p className="text-xs text-neutral-600 leading-relaxed">
                  Need priority rerouting, customs assistance, or proof-of-delivery copy? Contact our logistics support desk with this tracking ID.
                </p>
                <div className="pt-1">
                  <WhatsAppButton 
                    variant="button" 
                    label="Chat with Support on WhatsApp" 
                    message={`Hello SWIFTDROP! I am tracking shipment ID ${booking.trackingNumber} and need assistance.`}
                    className="w-full text-xs py-2.5" 
                  />
                </div>
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
};
