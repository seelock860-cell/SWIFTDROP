import React, { useState, useMemo } from 'react';
import { StorageService } from '../services/storageService';
import { DeliveryType, PackageCategory } from '../types';
import { ArrowRight, Package, Calculator, Calendar, MapPin, User, FileText, CheckCircle2 } from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface BookDeliveryPageProps {
  onNavigate: (page: string, params?: any) => void;
  initialDeliveryType?: DeliveryType;
}

export const BookDeliveryPage: React.FC<BookDeliveryPageProps> = ({ 
  onNavigate, 
  initialDeliveryType = 'local' 
}) => {
  const currentUser = StorageService.getCurrentUser();

  const [formData, setFormData] = useState({
    customerName: currentUser?.fullName || '',
    customerEmail: currentUser?.email || '',
    customerPhone: currentUser?.phone || '',
    
    pickupCountry: 'Nigeria',
    pickupState: currentUser?.state || 'Lagos',
    pickupCity: currentUser?.city || 'Ikeja',
    pickupAddress: currentUser?.address || '',
    
    destinationCountry: initialDeliveryType === 'international' ? 'United Kingdom' : 'Nigeria',
    destinationState: initialDeliveryType === 'nationwide' ? 'Abuja' : 'Lagos',
    destinationCity: initialDeliveryType === 'international' ? 'London' : (initialDeliveryType === 'nationwide' ? 'Central Area' : 'Victoria Island'),
    destinationAddress: '',
    
    packageDescription: '',
    packageCategory: 'parcel' as PackageCategory,
    packageWeight: 2.0,
    deliveryType: initialDeliveryType as DeliveryType,
    preferredPickupDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    additionalInstructions: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Derived price quote on weight / deliveryType
  const calculatedQuote = useMemo(() => {
    return StorageService.calculatePrice(formData.deliveryType, formData.packageWeight);
  }, [formData.deliveryType, formData.packageWeight]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'packageWeight' ? parseFloat(value) || 1 : value,
    }));
  };

  const handleDeliveryTypeChange = (type: DeliveryType) => {
    setFormData(prev => {
      let destCountry = 'Nigeria';
      let destState = 'Lagos';
      let destCity = 'Victoria Island';

      if (type === 'nationwide') {
        destCountry = 'Nigeria';
        destState = 'Abuja';
        destCity = 'Central Business District';
      } else if (type === 'international') {
        destCountry = 'United Kingdom';
        destState = 'Greater London';
        destCity = 'London';
      }

      return {
        ...prev,
        deliveryType: type,
        destinationCountry: destCountry,
        destinationState: destState,
        destinationCity: destCity,
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.customerName || !formData.customerEmail || !formData.customerPhone) {
      setErrorMessage('Please fill in your contact information.');
      return;
    }
    if (!formData.pickupAddress || !formData.destinationAddress) {
      setErrorMessage('Please provide complete pickup and destination addresses.');
      return;
    }
    if (!formData.packageDescription) {
      setErrorMessage('Please describe the contents of your package.');
      return;
    }

    setIsSubmitting(true);

    try {
      const newBooking = StorageService.createBooking({
        customerId: currentUser?.id,
        customerName: formData.customerName,
        customerEmail: formData.customerEmail,
        customerPhone: formData.customerPhone,
        pickupCountry: formData.pickupCountry,
        pickupState: formData.pickupState,
        pickupCity: formData.pickupCity,
        pickupAddress: formData.pickupAddress,
        destinationCountry: formData.destinationCountry,
        destinationState: formData.destinationState,
        destinationCity: formData.destinationCity,
        destinationAddress: formData.destinationAddress,
        packageDescription: formData.packageDescription,
        packageCategory: formData.packageCategory,
        packageWeight: formData.packageWeight,
        deliveryType: formData.deliveryType,
        preferredPickupDate: formData.preferredPickupDate,
        additionalInstructions: formData.additionalInstructions,
        totalAmount: calculatedQuote.amount,
        currency: 'NGN',
        bookingStatus: 'Booking Received',
      });

      // Navigate straight to checkout / payment receipt upload page
      onNavigate('checkout', { bookingId: newBooking.id });
    } catch (err: any) {
      setErrorMessage('Failed to save booking. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      
      {/* Header */}
      <div className="max-w-3xl mb-8">
        <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Dispatch Booking</div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight mt-1">
          Book a Delivery
        </h1>
        <p className="text-sm text-neutral-600 mt-2">
          Fill out the consignment details below to generate your official SWIFTDROP tracking code and proceed to manual bank transfer checkout.
        </p>
      </div>

      {errorMessage && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium">
          {errorMessage}
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Form Inputs */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* 1. Delivery Type Selection (Segmented Control) */}
          <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-4">
            <label className="block text-xs font-bold text-neutral-900 uppercase tracking-wide">
              1. Select Delivery Service Tier
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => handleDeliveryTypeChange('local')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  formData.deliveryType === 'local'
                    ? 'border-orange-600 bg-orange-50/50 text-neutral-900 ring-2 ring-orange-500/20'
                    : 'border-neutral-200 hover:border-neutral-300 text-neutral-700 bg-white'
                }`}
              >
                <div className="font-bold text-sm">Local Delivery</div>
                <div className="text-[11px] text-neutral-500 mt-0.5">Intra-city express</div>
                <div className="text-xs font-mono font-bold text-orange-600 mt-2">From ₦3,000</div>
              </button>

              <button
                type="button"
                onClick={() => handleDeliveryTypeChange('nationwide')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  formData.deliveryType === 'nationwide'
                    ? 'border-orange-600 bg-orange-50/50 text-neutral-900 ring-2 ring-orange-500/20'
                    : 'border-neutral-200 hover:border-neutral-300 text-neutral-700 bg-white'
                }`}
              >
                <div className="font-bold text-sm">Nationwide Delivery</div>
                <div className="text-[11px] text-neutral-500 mt-0.5">All 36 States + FCT</div>
                <div className="text-xs font-mono font-bold text-orange-600 mt-2">From ₦6,500</div>
              </button>

              <button
                type="button"
                onClick={() => handleDeliveryTypeChange('international')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  formData.deliveryType === 'international'
                    ? 'border-orange-600 bg-orange-50/50 text-neutral-900 ring-2 ring-orange-500/20'
                    : 'border-neutral-200 hover:border-neutral-300 text-neutral-700 bg-white'
                }`}
              >
                <div className="font-bold text-sm">International Shipping</div>
                <div className="text-[11px] text-neutral-500 mt-0.5">UK, US, Europe & Beyond</div>
                <div className="text-xs font-mono font-bold text-orange-600 mt-2">From ₦35,000</div>
              </button>
            </div>
          </div>

          {/* 2. Customer Contact Info */}
          <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2 border-b border-neutral-100 pb-3">
              <User className="w-4 h-4 text-orange-600" />
              <h2 className="text-sm font-bold text-neutral-900">2. Sender & Contact Details</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Customer Full Name *</label>
                <input
                  type="text"
                  name="customerName"
                  required
                  value={formData.customerName}
                  onChange={handleChange}
                  placeholder="e.g. Tunde Balogun"
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Email Address *</label>
                <input
                  type="email"
                  name="customerEmail"
                  required
                  value={formData.customerEmail}
                  onChange={handleChange}
                  placeholder="tunde@example.com"
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Phone Number *</label>
                <input
                  type="tel"
                  name="customerPhone"
                  required
                  value={formData.customerPhone}
                  onChange={handleChange}
                  placeholder="08012345678"
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>
          </div>

          {/* 3. Pickup Location */}
          <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2 border-b border-neutral-100 pb-3">
              <MapPin className="w-4 h-4 text-orange-600" />
              <h2 className="text-sm font-bold text-neutral-900">3. Pickup Address Details</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Pickup Country *</label>
                <input
                  type="text"
                  name="pickupCountry"
                  required
                  value={formData.pickupCountry}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-neutral-100 border border-neutral-200 rounded-lg text-xs text-neutral-700"
                  readOnly
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Pickup State *</label>
                <input
                  type="text"
                  name="pickupState"
                  required
                  value={formData.pickupState}
                  onChange={handleChange}
                  placeholder="e.g. Lagos, Rivers, FCT"
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Pickup City *</label>
                <input
                  type="text"
                  name="pickupCity"
                  required
                  value={formData.pickupCity}
                  onChange={handleChange}
                  placeholder="e.g. Ikeja, Lekki, Port Harcourt"
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">Pickup Street Address *</label>
              <textarea
                name="pickupAddress"
                required
                rows={2}
                value={formData.pickupAddress}
                onChange={handleChange}
                placeholder="House/Plot number, street name, landmark, estate name"
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          {/* 4. Destination Location */}
          <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2 border-b border-neutral-100 pb-3">
              <MapPin className="w-4 h-4 text-orange-600" />
              <h2 className="text-sm font-bold text-neutral-900">4. Destination Address Details</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Destination Country *</label>
                <input
                  type="text"
                  name="destinationCountry"
                  required
                  value={formData.destinationCountry}
                  onChange={handleChange}
                  placeholder="e.g. Nigeria, United Kingdom, USA"
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Destination State / Province *</label>
                <input
                  type="text"
                  name="destinationState"
                  required
                  value={formData.destinationState}
                  onChange={handleChange}
                  placeholder="e.g. Abuja, London, Texas"
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Destination City *</label>
                <input
                  type="text"
                  name="destinationCity"
                  required
                  value={formData.destinationCity}
                  onChange={handleChange}
                  placeholder="e.g. Wuse 2, Manchester, Houston"
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">Destination Street Address *</label>
              <textarea
                name="destinationAddress"
                required
                rows={2}
                value={formData.destinationAddress}
                onChange={handleChange}
                placeholder="Full delivery address, recipient apartment number, building name, postcode"
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          {/* 5. Package Information */}
          <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2 border-b border-neutral-100 pb-3">
              <Package className="w-4 h-4 text-orange-600" />
              <h2 className="text-sm font-bold text-neutral-900">5. Package Specifications</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Package Category *</label>
                <select
                  name="packageCategory"
                  value={formData.packageCategory}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                >
                  <option value="parcel">Standard Parcel / Box</option>
                  <option value="documents">Official Documents / Letters</option>
                  <option value="electronics">Electronics & Gadgets</option>
                  <option value="fashion">Fashion & Clothing</option>
                  <option value="fragile">Fragile / Glassware</option>
                  <option value="perishables">Packaged Foodstuffs / Dry Goods</option>
                  <option value="industrial">Industrial Spare Parts</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Package Weight (kg) *</label>
                <input
                  type="number"
                  name="packageWeight"
                  step="0.1"
                  min="0.5"
                  max="100"
                  required
                  value={formData.packageWeight}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Preferred Pickup Date *</label>
                <input
                  type="date"
                  name="preferredPickupDate"
                  required
                  value={formData.preferredPickupDate}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">Package Description *</label>
              <input
                type="text"
                name="packageDescription"
                required
                value={formData.packageDescription}
                onChange={handleChange}
                placeholder="Brief item description (e.g. 2 cartons of organic skincare jars)"
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">Additional Courier Instructions (Optional)</label>
              <textarea
                name="additionalInstructions"
                rows={2}
                value={formData.additionalInstructions}
                onChange={handleChange}
                placeholder="Gate code, caller instructions, fragile notes, customs notes..."
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

        </div>

        {/* Right Column: Dynamic Price Summary & Instant Submit */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-neutral-950 text-white p-6 rounded-2xl border border-neutral-800 shadow-xl sticky top-28 space-y-6">
            
            <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
              <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider">Order Summary</span>
              <span className="text-xs text-orange-400 font-medium capitalize">{formData.deliveryType} Delivery</span>
            </div>

            <div className="space-y-3 text-xs text-neutral-300">
              <div className="flex justify-between">
                <span className="text-neutral-400">Destination:</span>
                <span className="font-semibold text-white">{formData.destinationCity}, {formData.destinationCountry}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Total Weight:</span>
                <span className="font-semibold text-white font-mono">{formData.packageWeight} kg</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Estimated Transit:</span>
                <span className="font-semibold text-orange-400">{calculatedQuote.estimatedDays}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Payment Method:</span>
                <span className="font-semibold text-emerald-400">Direct Bank Transfer</span>
              </div>
            </div>

            <div className="border-t border-neutral-800 pt-4">
              <div className="text-xs text-neutral-400">Total Delivery Fee</div>
              <div className="text-3xl font-extrabold text-white font-mono mt-1">
                ₦{calculatedQuote.amount.toLocaleString()}
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">
                Includes all transit insurance and dispatch tracking.
              </p>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-lg shadow-orange-600/30 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{isSubmitting ? 'Creating Booking...' : 'Proceed to Bank Transfer'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="text-[11px] text-neutral-400 leading-relaxed border-t border-neutral-800/80 pt-3 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>
                You will be issued your official tracking ID immediately and shown our Zenith Bank account details for manual transfer.
              </span>
            </div>

            <div className="pt-2">
              <WhatsAppButton 
                variant="button" 
                label="Have Questions? WhatsApp Us" 
                className="w-full text-xs py-2.5" 
              />
            </div>

          </div>
        </div>

      </form>

    </div>
  );
};
