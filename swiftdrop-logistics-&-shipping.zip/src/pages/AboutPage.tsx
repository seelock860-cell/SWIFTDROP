import React from 'react';
import { IMAGES } from '../assets/images';
import { ShieldCheck, Truck, Plane, Users, Award, MapPin, ArrowRight } from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface AboutPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-20 pb-20">
      
      {/* Hero */}
      <section className="bg-neutral-950 text-white py-16 sm:py-24 border-b border-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="text-xs font-bold text-orange-400 uppercase tracking-widest">About SWIFTDROP</div>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
              Pioneering Dependable Logistics Across Nigeria & Beyond
            </h1>
            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
              Founded on the bedrock principle that every parcel carries somebody's trust, SWIFTDROP delivers state-of-the-art dispatch, interstate haulage, and international cargo export.
            </p>
          </div>
        </div>
      </section>

      {/* Story & Image */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-5">
            <div className="text-xs font-bold text-orange-600 uppercase tracking-wider">Our Story</div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900">
              Transforming Parcel Delivery From Stress into Certainty
            </h2>
            <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
              Logistics in Nigeria has traditionally suffered from uncommunicative riders, missed delivery windows, and obscure payment deductions. SWIFTDROP was founded to create an institution of predictability.
            </p>
            <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
              By combining disciplined dispatch teams, rigorous manual bank payment audits, and continuous milestone tracking, we ensure every consignment from a confidential document in Ikeja to a 20kg fashion export to London is handled with corporate integrity.
            </p>
            <div className="pt-2 flex items-center gap-4">
              <button
                onClick={() => onNavigate('book-delivery')}
                className="px-6 py-3 bg-neutral-950 hover:bg-neutral-800 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-2"
              >
                <span>Ship With SWIFTDROP</span>
                <ArrowRight className="w-4 h-4 text-orange-500" />
              </button>
            </div>
          </div>
          <div className="lg:col-span-6">
            <div className="rounded-2xl overflow-hidden border border-neutral-200 shadow-md">
              <img
                src={IMAGES.warehouseHub}
                alt="SWIFTDROP Sorting and Logistics Hub"
                className="w-full h-80 object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="bg-neutral-100/70 py-16 border-y border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
            <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Our DNA</div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900">
              The Principles That Guide Every Delivery
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-3">
              <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-neutral-900">100% Financial Accountability</h3>
              <p className="text-xs text-neutral-600 leading-relaxed">
                We utilize verified direct manual bank transfers. Every customer payment is individually reviewed and confirmed by our finance desk before order clearance.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-3">
              <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center">
                <Truck className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-neutral-900">Predictable Route Schedules</h3>
              <p className="text-xs text-neutral-600 leading-relaxed">
                Whether motorcycle dispatch or interstate trunk lines, our vehicles operate on established time windows rather than waiting for ad-hoc aggregations.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-3">
              <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center">
                <Plane className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-neutral-900">Cross-Border Compliance</h3>
              <p className="text-xs text-neutral-600 leading-relaxed">
                Our international export cargo specialists prepare authentic manifests, air waybills, and customs declarations to ensure zero delays at foreign destination ports.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership & Location */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-neutral-950 text-white rounded-2xl p-8 sm:p-12 border border-neutral-800 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-2 max-w-xl">
            <div className="text-xs font-bold text-orange-400 uppercase tracking-widest">Head Office</div>
            <h3 className="text-2xl font-bold text-white">Visit Our Lekki Operations Hub</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Plot 14B Admiralty Way, Lekki Phase 1, Lagos State, Nigeria.<br />
              Open Monday through Saturday, 8:00 AM – 7:00 PM for physical package dropping and corporate consultations.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <WhatsAppButton variant="button" label="WhatsApp Hub Support" className="text-xs py-3" />
            <button
              onClick={() => onNavigate('contact')}
              className="px-5 py-3 bg-neutral-900 hover:bg-neutral-800 text-white border border-neutral-800 rounded-lg text-xs font-bold"
            >
              Contact Directory
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
