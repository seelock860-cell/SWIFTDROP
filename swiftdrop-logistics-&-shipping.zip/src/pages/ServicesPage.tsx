import React from 'react';
import { IMAGES } from '../assets/images';
import { Truck, Plane, MapPin, ShieldCheck, CheckCircle2, ArrowRight, Clock, Box } from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface ServicesPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-20 pb-20">
      
      {/* Hero */}
      <section className="bg-neutral-950 text-white py-16 sm:py-24 border-b border-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="text-xs font-bold text-orange-400 uppercase tracking-widest">Comprehensive Solutions</div>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
              Logistics Services Engineered For Speed & Precision
            </h1>
            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
              From on-demand urban motorcycle couriers in Nigerian metropolitan cities to intercontinental air cargo flights, SWIFTDROP provides end-to-end supply chain reliability.
            </p>
            <div className="pt-2 flex flex-wrap gap-4">
              <button
                onClick={() => onNavigate('book-delivery')}
                className="px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>Book a Consignment</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onNavigate('pricing')}
                className="px-6 py-3 bg-neutral-900 hover:bg-neutral-800 text-white border border-neutral-800 font-semibold text-xs rounded-lg transition-colors cursor-pointer"
              >
                View Rate Card
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 3 Main Services Detailed */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Service 1: Local Delivery */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 rounded-2xl overflow-hidden border border-neutral-200 shadow-sm">
            <img
              src={IMAGES.dispatchRider}
              alt="Urban dispatch motorcycle delivery"
              className="w-full h-80 object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="lg:col-span-6 space-y-4">
            <div className="text-xs font-bold text-orange-600 uppercase tracking-wider">Same-Day Intra-City</div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900">
              Local Delivery & Motorcycle Dispatch
            </h2>
            <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
              Beat city traffic with our dedicated fleet of professional dispatch motorbikes, cargo tricycles, and express vans. We operate throughout Lagos (Island, Mainland, Ikorodu), Abuja, Port Harcourt, and Ibadan.
            </p>
            <div className="grid grid-cols-2 gap-3 text-xs text-neutral-700 pt-1">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Under 45-min rapid pickup</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Weatherproof cargo boxes</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>E-commerce cash-free drop</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>GPS courier tracking</span>
              </div>
            </div>
            <div className="pt-2 flex items-center gap-4">
              <button
                onClick={() => onNavigate('local-delivery')}
                className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold"
              >
                Local Delivery Details
              </button>
              <button
                onClick={() => onNavigate('book-delivery', { deliveryType: 'local' })}
                className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1"
              >
                <span>Book Local</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Service 2: Nationwide Delivery */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center lg:flex-row-reverse">
          <div className="lg:col-span-6 lg:order-2 rounded-2xl overflow-hidden border border-neutral-200 shadow-sm">
            <img
              src={IMAGES.warehouseHub}
              alt="Interstate logistics sorting hub"
              className="w-full h-80 object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="lg:col-span-6 lg:order-1 space-y-4">
            <div className="text-xs font-bold text-orange-600 uppercase tracking-wider">All 36 States + FCT</div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900">
              Nationwide Delivery & Interstate Cargo
            </h2>
            <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
              Connect your business to customers across every state in Nigeria. We operate direct arterial trunk routes departing daily from primary commercial hubs to regional sorting distribution terminals.
            </p>
            <div className="grid grid-cols-2 gap-3 text-xs text-neutral-700 pt-1">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>2-4 days transit window</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Doorstep or terminal pickup</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Bulk carton & freight rates</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Tamper-evident seals</span>
              </div>
            </div>
            <div className="pt-2 flex items-center gap-4">
              <button
                onClick={() => onNavigate('nationwide-delivery')}
                className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold"
              >
                Nationwide Coverage
              </button>
              <button
                onClick={() => onNavigate('book-delivery', { deliveryType: 'nationwide' })}
                className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1"
              >
                <span>Book Nationwide</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Service 3: International Shipping */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 rounded-2xl overflow-hidden border border-neutral-200 shadow-sm">
            <img
              src={IMAGES.internationalCargo}
              alt="International ocean and air freight logistics"
              className="w-full h-80 object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="lg:col-span-6 space-y-4">
            <div className="text-xs font-bold text-orange-600 uppercase tracking-wider">Global Air & Sea Freight</div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900">
              International Cargo Shipping
            </h2>
            <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
              Export personal packages, dry foodstuffs, commercial fashion, and corporate consignments worldwide. SWIFTDROP simplifies customs documentation and ensures priority air cargo clearance.
            </p>
            <div className="grid grid-cols-2 gap-3 text-xs text-neutral-700 pt-1">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Direct flights to UK, US, Canada</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Full export customs clearance</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Safe transport of dry foods</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Door-to-door global delivery</span>
              </div>
            </div>
            <div className="pt-2 flex items-center gap-4">
              <button
                onClick={() => onNavigate('international-shipping')}
                className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold"
              >
                International Details
              </button>
              <button
                onClick={() => onNavigate('book-delivery', { deliveryType: 'international' })}
                className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1"
              >
                <span>Book International</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

      </section>

      {/* Trust & WhatsApp CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-neutral-100 rounded-2xl p-8 border border-neutral-200 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-neutral-900">Need a customized business logistics contract?</h3>
            <p className="text-xs text-neutral-600">
              We provide dedicated fleet allocation and tailored corporate dispatch agreements for retail chains, pharmacies, and manufacturers.
            </p>
          </div>
          <WhatsAppButton variant="button" label="Consult on WhatsApp (09024971419)" className="whitespace-nowrap" />
        </div>
      </section>

    </div>
  );
};
