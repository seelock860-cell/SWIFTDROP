import React, { useState } from 'react';
import { StorageService } from '../services/storageService';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle2, MessageSquare } from 'lucide-react';
import { WhatsAppButton, getWhatsAppUrl } from '../components/common/WhatsAppButton';

interface ContactPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onNavigate }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Inquiry',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: 'General Inquiry',
        message: '',
      });
    }, 600);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Header */}
      <div className="max-w-2xl space-y-2">
        <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Connect With Us</div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
          Contact SWIFTDROP Support
        </h1>
        <p className="text-xs sm:text-sm text-neutral-600">
          Have an inquiry regarding a delivery booking, need custom corporate dispatch, or want urgent parcel tracking assistance? We are here to help.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Left Column: Contact Form */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 border border-neutral-200 shadow-sm space-y-6">
          <h2 className="text-base font-bold text-neutral-900 border-b border-neutral-100 pb-3">
            Send an Electronic Message
          </h2>

          {submitted ? (
            <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-3">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
              <h3 className="text-sm font-bold text-emerald-900">Message Dispatched Successfully</h3>
              <p className="text-xs text-emerald-700 leading-relaxed">
                Thank you for reaching out. A SWIFTDROP logistics coordinator will review your request and reply shortly via phone or email.
              </p>
              <button
                type="button"
                onClick={() => setSubmitted(false)}
                className="text-xs font-semibold text-emerald-800 underline cursor-pointer"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Samuel Adekunle"
                    className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="samuel@example.com"
                    className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="09024971419"
                    className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">Subject</label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                  >
                    <option value="General Inquiry">General Inquiry</option>
                    <option value="Booking & Tracking Help">Booking & Tracking Help</option>
                    <option value="Payment Verification">Manual Bank Payment Verification</option>
                    <option value="Corporate Fleet Logistics">Corporate Dispatch Contract</option>
                    <option value="International Export Freight">International Cargo Export</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">Detailed Message *</label>
                <textarea
                  required
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Describe your delivery requirements, pickup address, tracking number, or inquiry..."
                  className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-neutral-950 hover:bg-neutral-800 active:bg-black text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4 text-orange-500" />
                <span>{isSubmitting ? 'Sending...' : 'Transmit Message'}</span>
              </button>
            </form>
          )}
        </div>

        {/* Right Column: Direct Contact Info & WhatsApp */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Quick WhatsApp Support Box */}
          <div className="bg-emerald-50 rounded-2xl p-6 border border-emerald-200 space-y-3">
            <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
              <MessageSquare className="w-4 h-4 text-emerald-600" />
              <span>Instant WhatsApp Desk</span>
            </div>
            <p className="text-xs text-emerald-800 leading-relaxed">
              Need instant answers or wish to share your transfer receipt directly with our dispatch manager? Chat on WhatsApp now!
            </p>
            <div className="pt-1">
              <WhatsAppButton 
                variant="button" 
                label="Launch WhatsApp (09024971419)" 
                className="w-full text-xs py-2.5" 
              />
            </div>
          </div>

          {/* Directory Details */}
          <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-sm space-y-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 border-b border-neutral-100 pb-3">
              Operations Directory
            </h3>

            <div className="space-y-4 text-xs text-neutral-700">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-neutral-900 block">Lekki Logistics Hub (HQ)</span>
                  <span className="text-neutral-600 text-[11px] leading-snug block">
                    Plot 14B Admiralty Way, Lekki Phase 1, Lagos, Nigeria
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-neutral-900 block">Direct Telephone</span>
                  <a href="tel:+2349024971419" className="text-neutral-600 hover:text-orange-600 font-mono text-[11px]">
                    +234 902 497 1419
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-neutral-900 block">Official Support Email</span>
                  <a href="mailto:support@swiftdrop.ng" className="text-neutral-600 hover:text-orange-600 font-mono text-[11px]">
                    support@swiftdrop.ng
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-neutral-900 block">Operating Hours</span>
                  <span className="text-neutral-600 text-[11px]">
                    Monday - Saturday: 8:00 AM – 7:00 PM<br />
                    Sunday: Emergency dispatch on-call only
                  </span>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
