import React, { useState } from 'react';
import { StorageService } from '../services/storageService';
import { Logo } from '../components/common/Logo';
import { Shield, Lock, User, ArrowRight, AlertCircle } from 'lucide-react';

interface AdminLoginPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onNavigate }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      // Valid credentials per specification: swift / swift234
      if (username.trim() === 'swift' && password.trim() === 'swift234') {
        StorageService.setAdminSession({
          isAuthenticated: true,
          username: 'swift',
        });
        onNavigate('admin-dashboard');
      } else {
        setError('Invalid administrative credentials. Access restricted.');
      }
    }, 400);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md bg-neutral-950 text-white rounded-3xl p-8 border border-neutral-800 shadow-2xl space-y-6">
        
        <div className="text-center space-y-2">
          <div className="flex justify-center">
            <Logo variant="light" size="md" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-neutral-900 border border-neutral-800 rounded-lg text-xs font-mono text-orange-400 mt-2">
            <Shield className="w-3.5 h-3.5" />
            <span>SWIFTDROP Operations Console</span>
          </div>
          <h1 className="text-xl font-extrabold text-white tracking-tight pt-1">
            Administrator Authentication
          </h1>
          <p className="text-xs text-neutral-400">
            Restricted access for authorized logistics operations and finance auditing staff.
          </p>
        </div>

        {error && (
          <div className="p-3.5 bg-rose-950/80 border border-rose-800 rounded-xl text-xs text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">Admin Username</label>
            <div className="relative flex items-center">
              <User className="w-4 h-4 text-neutral-500 absolute left-3" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username"
                className="w-full pl-9 pr-3 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">Admin Password</label>
            <div className="relative flex items-center">
              <Lock className="w-4 h-4 text-neutral-500 absolute left-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-orange-600/30"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In as Administrator'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center pt-2">
          <button
            onClick={() => onNavigate('home')}
            className="text-xs text-neutral-500 hover:text-neutral-300 underline"
          >
            ← Back to Public Website
          </button>
        </div>

      </div>
    </div>
  );
};
