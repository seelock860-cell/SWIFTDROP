import React, { useState } from 'react';
import { StorageService } from '../services/storageService';
import { Profile } from '../types';
import { Logo } from '../components/common/Logo';
import { Lock, Mail, ArrowRight, AlertCircle } from 'lucide-react';

interface CustomerLoginPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const CustomerLoginPage: React.FC<CustomerLoginPageProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      const cleanEmail = email.trim().toLowerCase();

      // Check registered customers or create session profile
      const customers = StorageService.getCustomers();
      const existing = customers.find(c => c.email.toLowerCase() === cleanEmail);

      const profile: Profile = {
        id: existing?.id || `cust-${Date.now()}`,
        email: cleanEmail,
        fullName: existing?.fullName || 'Adewale Johnson',
        phone: existing?.phone || '08034567890',
        city: existing?.city || 'Lagos',
        state: existing?.state || 'Lagos',
        country: 'Nigeria',
        role: 'customer',
        createdAt: existing?.createdAt || new Date().toISOString(),
      };

      StorageService.setCurrentUser(profile);
      onNavigate('customer-dashboard');
    }, 400);
  };

  return (
    <div className="min-h-[75vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md bg-white rounded-3xl p-8 border border-neutral-200 shadow-xl space-y-6">
        
        <div className="text-center space-y-2">
          <div className="flex justify-center">
            <Logo size="md" />
          </div>
          <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight pt-2">
            Client Portal Login
          </h1>
          <p className="text-xs text-neutral-500">
            Sign in to manage your shipments, verify payments, and book deliveries.
          </p>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">Email Address</label>
            <div className="relative flex items-center">
              <Mail className="w-4 h-4 text-neutral-400 absolute left-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@company.com"
                className="w-full pl-9 pr-3 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">Password</label>
            <div className="relative flex items-center">
              <Lock className="w-4 h-4 text-neutral-400 absolute left-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-neutral-950 hover:bg-neutral-800 active:bg-black text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In to Dashboard'}</span>
            <ArrowRight className="w-4 h-4 text-orange-500" />
          </button>
        </form>

        <div className="border-t border-neutral-100 pt-4 text-center text-xs text-neutral-600">
          Don't have an account yet?{' '}
          <button
            onClick={() => onNavigate('customer-register')}
            className="font-bold text-orange-600 hover:text-orange-700 underline cursor-pointer"
          >
            Create an Account
          </button>
        </div>

      </div>
    </div>
  );
};
