import React, { useState } from 'react';
import { IMAGES } from '../assets/images';
import { 
  Truck, 
  Plane, 
  MapPin, 
  ShieldCheck, 
  Clock, 
  ArrowRight, 
  Search, 
  CheckCircle2, 
  HelpCircle,
  Building2,
  ChevronDown
} from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface HomePageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const [quickTrackingNumber, setQuickTrackingNumber] = useState('');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTrackingNumber.trim()) return;
    onNavigate('track-package', { trackingNumber: quickTrackingNumber.trim() });
  };

  const faqs = [
    {
      q: 'How does the bank transfer payment system work?',
      a: 'After creating your delivery booking, you will be directed to our secure checkout page displaying our designated company Zenith Bank account details. Make your transfer via your bank app or USSD, then simply upload your transfer receipt on the checkout page. Our finance team will immediately review and confirm your payment to release your package for dispatch.',
    },
    {
      q: 'How fast is local city delivery in Lagos or Abuja?',
      a: 'We offer same-day express motorcycle and van dispatch for orders booked before 12:00 PM within Lagos and Abuja municipal districts. Deliveries booked in the afternoon are guaranteed first thing the next morning.',
    },
    {
      q: 'What is the transit time for nationwide interstate deliveries across Nigeria?',
      a: 'Interstate deliveries typically arrive within 2 to 3 business days for South-West and South-South states, and 3 to 5 business days for Northern states. All shipments travel in GPS-monitored secure transit vehicles.',
    },
    {
      q: 'Which countries do you ship to internationally from Nigeria?',
      a: 'We provide express air cargo and freight shipping to the United Kingdom, United States, Canada, Germany, France, Ireland, UAE (Dubai), South Africa, Ghana, Kenya, and over 80 other destinations with full customs handling.',
    },
    {
      q: 'Can I track my delivery in real time?',
      a: 'Yes! Every booking automatically generates an official SWIFTDROP tracking number (e.g., SWD-2026-XXXXX). You can enter this tracking number at any time on our website to see status checkpoints, current facility locations, and transit history.',
    },
    {
      q: 'How can I get immediate assistance regarding my shipment?',
      a: 'You can tap any of our WhatsApp buttons or call +234 902 497 1419. Our dedicated dispatch coordination team responds promptly with live status updates on your package.',
    },
  ];

  return (
    <div className="space-y-24 pb-20">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden bg-neutral-950 text-white pt-12 pb-20 lg:pt-20 lg:pb-32">
        {/* Subtle grid background pattern */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#f97316_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Value Prop & CTAs */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Trust Tag */}
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-orange-400 uppercase tracking-widest">
                <span>Nigeria & Global Shipping Partner</span>
                <span className="text-neutral-600">/</span>
                <span>Verified Express Logistics</span>
              </div>

              {/* Headline */}
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] text-white">
                Your Packages. Our Priority. <span className="text-orange-500">Delivered Everywhere.</span>
              </h1>

              {/* Subheading */}
              <p className="text-base sm:text-lg text-neutral-300 leading-relaxed max-w-2xl">
                Experience high-precision dispatch across Nigerian cities, reliable nationwide delivery to all 36 States, and accelerated international air cargo to the UK, USA, Canada, and beyond.
              </p>

              {/* Quick Tracking Search Bar (Embedded in Hero) */}
              <div className="pt-2 max-w-xl">
                <form 
                  onSubmit={handleTrackSubmit} 
                  className="p-2 bg-neutral-900 border border-neutral-800 rounded-xl flex flex-col sm:flex-row gap-2 shadow-2xl"
                >
                  <div className="relative flex-1 flex items-center">
                    <Search className="w-5 h-5 text-neutral-400 absolute left-3.5" />
                    <input
                      type="text"
                      placeholder="Enter Tracking ID (e.g. SWD-2026-89412)"
                      value={quickTrackingNumber}
                      onChange={(e) => setQuickTrackingNumber(e.target.value)}
                      className="w-full pl-11 pr-4 py-3 bg-neutral-950 text-white placeholder-neutral-500 rounded-lg text-sm border border-neutral-800 focus:outline-none focus:border-orange-500 transition-colors uppercase font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-6 py-3 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white font-bold text-sm rounded-lg transition-colors flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
                  >
                    <span>Track Now</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
                <div className="flex items-center gap-2 text-xs text-neutral-400 mt-2 px-1">
                  <span>Quick demo trackings:</span>
                  <button 
                    type="button"
                    onClick={() => { setQuickTrackingNumber('SWD-2026-89412'); onNavigate('track-package', { trackingNumber: 'SWD-2026-89412' }); }}
                    className="underline text-orange-400 hover:text-orange-300 font-mono text-[11px]"
                  >
                    SWD-2026-89412
                  </button>
                  <span>·</span>
                  <button 
                    type="button"
                    onClick={() => { setQuickTrackingNumber('SWD-2026-63104'); onNavigate('track-package', { trackingNumber: 'SWD-2026-63104' }); }}
                    className="underline text-orange-400 hover:text-orange-300 font-mono text-[11px]"
                  >
                    SWD-2026-63104
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => onNavigate('book-delivery')}
                  className="px-6 py-3.5 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white text-sm font-bold rounded-lg transition-colors shadow-lg shadow-orange-600/20 flex items-center gap-2 cursor-pointer"
                >
                  <span>Book a Delivery Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onNavigate('pricing')}
                  className="px-6 py-3.5 bg-neutral-900 hover:bg-neutral-800 text-white border border-neutral-800 text-sm font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Check Rates & Calculator
                </button>
                <WhatsAppButton variant="button" label="WhatsApp Help" className="py-3.5 text-xs font-semibold" />
              </div>

              {/* Verified Metrics Row */}
              <div className="grid grid-cols-3 gap-6 pt-6 border-t border-neutral-800/80">
                <div>
                  <div className="text-2xl lg:text-3xl font-extrabold text-white font-mono tabular-nums">99.4%</div>
                  <div className="text-xs text-neutral-400 mt-0.5">On-Time Delivery</div>
                </div>
                <div>
                  <div className="text-2xl lg:text-3xl font-extrabold text-white font-mono tabular-nums">36+</div>
                  <div className="text-xs text-neutral-400 mt-0.5">Nigerian States Covered</div>
                </div>
                <div>
                  <div className="text-2xl lg:text-3xl font-extrabold text-white font-mono tabular-nums">85+</div>
                  <div className="text-xs text-neutral-400 mt-0.5">International Hubs</div>
                </div>
              </div>

            </div>

            {/* Right Column: Hero Visual Showcase */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl bg-neutral-900 group">
                <img
                  src={IMAGES.hero}
                  alt="SWIFTDROP Cargo Freight Aircraft"
                  className="w-full h-[440px] object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
                
                {/* Visual Card Badge */}
                <div className="absolute bottom-6 left-6 right-6 p-4 bg-neutral-900/90 backdrop-blur-md rounded-xl border border-neutral-800">
                  <div className="flex items-center justify-between text-xs text-white">
                    <span className="font-bold flex items-center gap-1.5">
                      <Plane className="w-4 h-4 text-orange-500" />
                      Global Air Freight & Cargo
                    </span>
                    <span className="text-neutral-400 font-mono text-[11px]">Active Routing</span>
                  </div>
                  <p className="text-[11px] text-neutral-300 mt-1 leading-snug">
                    Direct flights from Murtala Muhammed Intl Airport (LOS) to UK, Europe & Americas with customs clearance.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. OUR SERVICES SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Core Capabilities</div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
            Tailored Logistics Solutions For Individuals & Businesses
          </h2>
          <p className="text-sm sm:text-base text-neutral-600 leading-relaxed">
            Whether dispatching an urgent contract across town, shipping commercial inventory nationwide, or air-freighting packages abroad, SWIFTDROP delivers with unmatched precision.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Card 1: Local Delivery */}
          <div className="bg-white rounded-2xl border border-neutral-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col">
            <div className="h-52 overflow-hidden relative">
              <img 
                src={IMAGES.dispatchRider} 
                alt="Local City Dispatch" 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 bg-neutral-900/90 text-white text-[11px] font-bold px-2.5 py-1 rounded-md">
                Same-Day Dispatch
              </div>
            </div>
            <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
              <div>
                <h3 className="text-lg font-bold text-neutral-900">Local Delivery (Intra-City)</h3>
                <p className="text-xs text-neutral-600 mt-2 leading-relaxed">
                  Fast motorbike and van delivery within Lagos, Abuja, Port Harcourt, and major metropolitan centres. Ideal for documents, parcels, ecommerce orders, and food items.
                </p>
                <ul className="mt-4 space-y-2 text-xs text-neutral-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>Express pickup within 45 minutes</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>Real-time dispatch rider tracking</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>Direct recipient phone notification</span>
                  </li>
                </ul>
              </div>
              <div className="pt-2 border-t border-neutral-100 flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-900 font-mono">From ₦3,000</span>
                <button
                  onClick={() => onNavigate('local-delivery')}
                  className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 cursor-pointer"
                >
                  <span>Learn more</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Card 2: Nationwide Delivery */}
          <div className="bg-white rounded-2xl border border-neutral-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col">
            <div className="h-52 overflow-hidden relative">
              <img 
                src={IMAGES.warehouseHub} 
                alt="Nationwide Sorting Distribution Hub" 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 bg-neutral-900/90 text-white text-[11px] font-bold px-2.5 py-1 rounded-md">
                All 36 States + FCT
              </div>
            </div>
            <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
              <div>
                <h3 className="text-lg font-bold text-neutral-900">Nationwide Delivery (Interstate)</h3>
                <p className="text-xs text-neutral-600 mt-2 leading-relaxed">
                  Reliable interstate cargo and parcel distribution network across Nigeria. From Lagos and Ibadan to Kano, Kaduna, Enugu, and Calabar.
                </p>
                <ul className="mt-4 space-y-2 text-xs text-neutral-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>Scheduled departure trucks & buses</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>Secure tamper-proof security packaging</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>Terminal-to-terminal or doorstep drop</span>
                  </li>
                </ul>
              </div>
              <div className="pt-2 border-t border-neutral-100 flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-900 font-mono">From ₦6,500</span>
                <button
                  onClick={() => onNavigate('nationwide-delivery')}
                  className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 cursor-pointer"
                >
                  <span>Learn more</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Card 3: International Shipping */}
          <div className="bg-white rounded-2xl border border-neutral-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col">
            <div className="h-52 overflow-hidden relative">
              <img 
                src={IMAGES.internationalCargo} 
                alt="International Shipping & Cargo Freight" 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 bg-neutral-900/90 text-white text-[11px] font-bold px-2.5 py-1 rounded-md">
                Worldwide Air & Ocean
              </div>
            </div>
            <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
              <div>
                <h3 className="text-lg font-bold text-neutral-900">International Cargo Shipping</h3>
                <p className="text-xs text-neutral-600 mt-2 leading-relaxed">
                  Fast export shipping from Nigeria to the United Kingdom, United States, Canada, European Union, and West Africa with smooth documentation handling.
                </p>
                <ul className="mt-4 space-y-2 text-xs text-neutral-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>3 to 7 business days air freight</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>Complete export customs clearing</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>Foodstuff, fashion & commercial goods</span>
                  </li>
                </ul>
              </div>
              <div className="pt-2 border-t border-neutral-100 flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-900 font-mono">From ₦35,000</span>
                <button
                  onClick={() => onNavigate('international-shipping')}
                  className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 cursor-pointer"
                >
                  <span>Learn more</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 3. HOW IT WORKS SECTION */}
      <section className="bg-neutral-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <div className="text-xs font-bold text-orange-400 uppercase tracking-widest">Simple 4-Step Process</div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              How Shipping Works With SWIFTDROP
            </h2>
            <p className="text-sm text-neutral-400">
              Straightforward, transparent, and built around verified security from booking to doorstep handover.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
            
            {/* Step 1 */}
            <div className="space-y-3 p-5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="w-10 h-10 rounded-lg bg-orange-600 text-white font-mono font-bold flex items-center justify-center text-sm">
                01
              </div>
              <h3 className="text-base font-bold text-white">Book Online</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Provide pickup and destination details, package weight, and category to receive an instant price quote and tracking number.
              </p>
            </div>

            {/* Step 2 */}
            <div className="space-y-3 p-5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="w-10 h-10 rounded-lg bg-neutral-800 text-orange-400 font-mono font-bold flex items-center justify-center text-sm border border-neutral-700">
                02
              </div>
              <h3 className="text-base font-bold text-white">Bank Transfer & Receipt</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Transfer the exact delivery fare to our verified Zenith Bank account and upload your receipt screenshot directly on our checkout page.
              </p>
            </div>

            {/* Step 3 */}
            <div className="space-y-3 p-5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="w-10 h-10 rounded-lg bg-neutral-800 text-orange-400 font-mono font-bold flex items-center justify-center text-sm border border-neutral-700">
                03
              </div>
              <h3 className="text-base font-bold text-white">Verification & Pickup</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Our accounts team promptly validates your payment, and an assigned courier is dispatched to pick up your package.
              </p>
            </div>

            {/* Step 4 */}
            <div className="space-y-3 p-5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="w-10 h-10 rounded-lg bg-neutral-800 text-orange-400 font-mono font-bold flex items-center justify-center text-sm border border-neutral-700">
                04
              </div>
              <h3 className="text-base font-bold text-white">Live Tracking & Dropoff</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Follow your package through every waypoint on our tracking portal until final safe signature handover at destination.
              </p>
            </div>

          </div>

          <div className="mt-12 text-center">
            <button
              onClick={() => onNavigate('book-delivery')}
              className="px-8 py-3.5 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white font-bold text-sm rounded-lg transition-colors cursor-pointer inline-flex items-center gap-2"
            >
              <span>Start Booking A Package</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 4. WHY CHOOSE SWIFTDROP */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <div className="space-y-6">
            <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Why Choose Us</div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
              Built On Integrity, Reliability And Verified Accountability
            </h2>
            <p className="text-sm text-neutral-600 leading-relaxed">
              We eliminated the chaos of lost packages and untraceable couriers. With SWIFTDROP, every package is logged, monitored, and handled with institutional care.
            </p>

            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 rounded-xl bg-neutral-50 border border-neutral-200/80">
                <div className="w-9 h-9 rounded-lg bg-orange-100 text-orange-700 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-neutral-900">100% Manual Payment Audit</h4>
                  <p className="text-xs text-neutral-600 mt-1">
                    Direct bank transfer verification ensures transparency and eliminates hidden third-party gateway deductions.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 rounded-xl bg-neutral-50 border border-neutral-200/80">
                <div className="w-9 h-9 rounded-lg bg-orange-100 text-orange-700 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-neutral-900">Granular Milestones Tracking</h4>
                  <p className="text-xs text-neutral-600 mt-1">
                    Real-time status updates at each hub: booking received, payment verified, transit progress, arrival, and delivery.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 rounded-xl bg-neutral-50 border border-neutral-200/80">
                <div className="w-9 h-9 rounded-lg bg-orange-100 text-orange-700 flex items-center justify-center shrink-0">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-neutral-900">Customs & Air Cargo Clearance</h4>
                  <p className="text-xs text-neutral-600 mt-1">
                    Specialized export cargo agents prepare documentation, invoices, and customs compliance for international transit.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Bento Box */}
          <div className="bg-neutral-950 text-white rounded-2xl p-8 border border-neutral-800 space-y-6">
            <h3 className="text-xl font-bold text-white">Coverage Snapshot</h3>
            <div className="space-y-4 text-xs text-neutral-300">
              <div className="p-4 bg-neutral-900 rounded-xl border border-neutral-800">
                <div className="font-bold text-orange-400 text-sm">Local Hubs (Same-Day)</div>
                <div className="mt-1 text-neutral-400">
                  Lagos (Island, Mainland, Ikorodu, Epe), Abuja Municipal, Port Harcourt, Ibadan, Kano Metro.
                </div>
              </div>
              <div className="p-4 bg-neutral-900 rounded-xl border border-neutral-800">
                <div className="font-bold text-orange-400 text-sm">Interstate Corridors (2-4 Days)</div>
                <div className="mt-1 text-neutral-400">
                  All 36 Nigerian States including Enugu, Delta, Anambra, Kaduna, Plateau, Benue, and Cross River.
                </div>
              </div>
              <div className="p-4 bg-neutral-900 rounded-xl border border-neutral-800">
                <div className="font-bold text-orange-400 text-sm">International Routes (3-7 Days)</div>
                <div className="mt-1 text-neutral-400">
                  United Kingdom (London, Manchester), United States (New York, Texas, California), Canada (Toronto, Calgary), Europe, and UAE.
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <div>
                <div className="text-[11px] text-neutral-400">Need immediate dispatch assistance?</div>
                <div className="text-xs font-semibold text-white">Call or WhatsApp +234 902 497 1419</div>
              </div>
              <WhatsAppButton variant="button" label="Chat Now" className="text-xs py-2 px-3" />
            </div>
          </div>

        </div>
      </section>

      {/* 5. CUSTOMER TESTIMONIALS */}
      <section className="bg-neutral-100/70 py-20 border-y border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14 space-y-3">
            <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Verified Client Reviews</div>
            <h2 className="text-3xl font-extrabold text-neutral-900 tracking-tight">
              Trusted by Merchants, Corporates & Senders
            </h2>
            <p className="text-sm text-neutral-600">
              Real feedback from businesses and individuals who count on SWIFTDROP daily.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-4">
              <p className="text-xs text-neutral-700 leading-relaxed italic">
                "SWIFTDROP revolutionized our e-commerce deliveries in Lagos. Their riders are courteous, prompt, and the tracking updates give our buyers 100% peace of mind."
              </p>
              <div className="border-t border-neutral-100 pt-3 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-orange-600 text-white font-bold text-xs flex items-center justify-center">
                  AO
                </div>
                <div>
                  <div className="text-xs font-bold text-neutral-900">Adebisi Ogundipe</div>
                  <div className="text-[11px] text-neutral-500">Founder, Lagos Luxe Apparel</div>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-4">
              <p className="text-xs text-neutral-700 leading-relaxed italic">
                "I sent critical legal contracts and original deed documents from Abuja to London. SWIFTDROP got it cleared through Heathrow cargo hub in 4 business days flat. Superb!"
              </p>
              <div className="border-t border-neutral-100 pt-3 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-neutral-900 text-white font-bold text-xs flex items-center justify-center">
                  EK
                </div>
                <div>
                  <div className="text-xs font-bold text-neutral-900">Barrister Emeka Kalu</div>
                  <div className="text-[11px] text-neutral-500">Senior Partner, Kalu & Associates</div>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-4">
              <p className="text-xs text-neutral-700 leading-relaxed italic">
                "Their manual bank transfer system is so straightforward. I transfer, attach my receipt, and their finance desk approves it within minutes. No failed card debits."
              </p>
              <div className="border-t border-neutral-100 pt-3 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-orange-600 text-white font-bold text-xs flex items-center justify-center">
                  FB
                </div>
                <div>
                  <div className="text-xs font-bold text-neutral-900">Fatima Balarabe</div>
                  <div className="text-[11px] text-neutral-500">Operations Lead, Sahel Agro Exports</div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 6. FAQS ACCORDION */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 space-y-3">
          <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Got Questions?</div>
          <h2 className="text-3xl font-extrabold text-neutral-900 tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-sm text-neutral-600">
            Everything you need to know about booking, bank transfer payments, and tracking with SWIFTDROP.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl border border-neutral-200 overflow-hidden transition-all"
            >
              <button
                onClick={() => setOpenFaq(openFaq === index ? null : index)}
                className="w-full text-left px-5 py-4 flex items-center justify-between text-sm font-bold text-neutral-900 hover:text-orange-600 cursor-pointer"
              >
                <span>{faq.q}</span>
                <ChevronDown className={`w-4 h-4 text-neutral-500 transition-transform ${openFaq === index ? 'rotate-180 text-orange-600' : ''}`} />
              </button>
              {openFaq === index && (
                <div className="px-5 pb-5 text-xs text-neutral-600 leading-relaxed border-t border-neutral-100 pt-3 bg-neutral-50/50">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* 7. BOTTOM CTA BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-neutral-950 text-white rounded-3xl p-8 sm:p-14 relative overflow-hidden border border-neutral-800">
          <div className="relative z-10 max-w-2xl space-y-4">
            <h3 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
              Ready to Dispatch Your Package?
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
              Book a delivery in less than 2 minutes, get your official tracking number, and experience dependable logistics with SWIFTDROP.
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={() => onNavigate('book-delivery')}
                className="px-6 py-3.5 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-2"
              >
                <span>Book a Delivery Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onNavigate('track-package')}
                className="px-6 py-3.5 bg-neutral-900 hover:bg-neutral-800 text-white border border-neutral-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Track An Existing Package
              </button>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
