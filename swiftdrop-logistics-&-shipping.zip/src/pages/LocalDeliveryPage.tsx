import React from 'react';
import { IMAGES } from '../assets/images';
import { CheckCircle2, Clock, MapPin, ArrowRight, ShieldCheck, PhoneCall } from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface LocalDeliveryPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const LocalDeliveryPage: React.FC<LocalDeliveryPageProps> = ({ onNavigate }) => {
  const hubs = [
    { city: 'Lagos State', zones: 'Lekki Phase 1, Victoria Island, Ikoyi, Ikeja, Yaba, Surulere, Festac, Ikorodu, Epe' },
    { city: 'Abuja (FCT)', zones: 'Maitama, Wuse 1 & 2, Garki, Jabi, Utako, Gwarinpa, Central Business District' },
    { city: 'Port Harcourt', zones: 'Old GRA, New GRA, Trans Amadi, Peter Odili Road, Rumuokoro' },
    { city: 'Ibadan', zones: 'Bodija, Ring Road, Dugbe, Jericho, Oluyole Estate, UI Campus' },
    { city: 'Kano Metro', zones: 'Bompai, Nassarawa GRA, Sabon Gari, Kano Central' },
  ];

  return (
    <div className="space-y-16 pb-20">
      
      {/* Hero */}
      <section className="bg-neutral-950 text-white py-16 border-b border-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="text-xs font-bold text-orange-400 uppercase tracking-widest">Intra-City Express Dispatch</div>
              <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
                Local City Delivery in Lagos, Abuja & Beyond
              </h1>
              <p className="text-sm text-neutral-300 leading-relaxed">
                Lightning-fast on-demand motorcycle couriers and compact express delivery vans. We navigate heavy urban traffic to ensure your urgent parcels, legal documents, food orders, and online store deliveries arrive safely.
              </p>
              <div className="pt-2 flex flex-wrap gap-4">
                <button
                  onClick={() => onNavigate('book-delivery', { deliveryType: 'local' })}
                  className="px-6 py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Book Local Delivery (From ₦3,000)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <WhatsAppButton variant="button" label="Book via WhatsApp" className="text-xs py-3.5" />
              </div>
            </div>
            <div className="lg:col-span-5">
              <div className="rounded-2xl overflow-hidden border border-neutral-800 shadow-xl">
                <img
                  src={IMAGES.dispatchRider}
                  alt="SWIFTDROP Motorcycle Courier"
                  className="w-full h-80 object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* City Hubs Breakdown */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Urban Presence</div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900">
            Active City Dispatch Zones
          </h2>
          <p className="text-xs sm:text-sm text-neutral-600">
            Our riders are stationed across key metropolitan corridors for minimal response times.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {hubs.map((hub, idx) => (
            <div key={idx} className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-3">
              <div className="flex items-center gap-2 text-sm font-bold text-neutral-900">
                <MapPin className="w-4 h-4 text-orange-600 shrink-0" />
                <span>{hub.city}</span>
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">
                {hub.zones}
              </p>
              <div className="pt-2 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500">
                <span>Dispatch: 45 - 90 mins</span>
                <span className="text-emerald-600 font-semibold">Active Daily</span>
              </div>
            </div>
          ))}

          {/* Quick Booking CTA Box */}
          <div className="bg-neutral-950 text-white p-6 rounded-2xl border border-neutral-800 flex flex-col justify-between space-y-4">
            <div>
              <div className="text-xs font-bold text-orange-400 uppercase tracking-wider">Fast Booking</div>
              <h3 className="text-base font-bold text-white mt-1">Need an urgent courier rider now?</h3>
              <p className="text-xs text-neutral-400 mt-2">
                Create a booking online or reach out immediately on WhatsApp to have a rider dispatched to your address.
              </p>
            </div>
            <button
              onClick={() => onNavigate('book-delivery', { deliveryType: 'local' })}
              className="w-full py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold transition-colors"
            >
              Book Delivery Now
            </button>
          </div>
        </div>
      </section>

      {/* Service Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-neutral-50 rounded-2xl p-8 border border-neutral-200">
          <h3 className="text-lg font-bold text-neutral-900 mb-6">Why Local Senders Prefer SWIFTDROP</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-neutral-700">
            <div className="space-y-2">
              <div className="font-bold text-neutral-900 text-sm">Pre-Screened Professional Riders</div>
              <p className="text-neutral-600 leading-relaxed">
                All couriers undergo comprehensive background audits, road safety certifications, and customer etiquette training.
              </p>
            </div>
            <div className="space-y-2">
              <div className="font-bold text-neutral-900 text-sm">Insulated Weatherproof Boxes</div>
              <p className="text-neutral-600 leading-relaxed">
                Rain, dust, and vibration protection ensure delicate electronics, crisp documents, and fashion items arrive spotless.
              </p>
            </div>
            <div className="space-y-2">
              <div className="font-bold text-neutral-900 text-sm">Direct Bank Audit Receipt</div>
              <p className="text-neutral-600 leading-relaxed">
                Enjoy transparent fees without surprise cash-on-delivery arguments. Simple transfer to our Zenith Bank account.
              </p>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
