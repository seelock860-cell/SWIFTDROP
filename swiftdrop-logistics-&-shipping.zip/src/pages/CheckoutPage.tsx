import React, { useState, useEffect } from 'react';
import { StorageService } from '../services/storageService';
import { Booking, PaymentRecord, BankSettings } from '../types';
import { StatusBadge } from '../components/common/StatusBadge';
import { 
  Building2, 
  Copy, 
  Check, 
  Upload, 
  ArrowRight, 
  ShieldCheck, 
  AlertCircle, 
  FileText, 
  Clock, 
  Eye, 
  Package,
  CheckCircle2
} from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface CheckoutPageProps {
  bookingId?: string;
  onNavigate: (page: string, params?: any) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ bookingId, onNavigate }) => {
  const [booking, setBooking] = useState<Booking | null>(null);
  const [payment, setPayment] = useState<PaymentRecord | null>(null);
  const [bankSettings, setBankSettings] = useState<BankSettings>(StorageService.getBankSettings());
  const [copied, setCopied] = useState(false);

  // Form states for manual receipt submission
  const [senderAccountName, setSenderAccountName] = useState('');
  const [senderBankName, setSenderBankName] = useState('');
  const [transactionRef, setTransactionRef] = useState('');
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null);
  const [receiptFilename, setReceiptFilename] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    // If bookingId provided, load booking
    if (bookingId) {
      const b = StorageService.getBookings().find(item => item.id === bookingId);
      if (b) {
        setBooking(b);
        const p = StorageService.getPaymentByBookingId(b.id);
        if (p) setPayment(p);
      }
    } else {
      // Default to most recent booking
      const all = StorageService.getBookings();
      if (all.length > 0) {
        setBooking(all[0]);
        const p = StorageService.getPaymentByBookingId(all[0].id);
        if (p) setPayment(p);
      }
    }
    setBankSettings(StorageService.getBankSettings());
  }, [bookingId]);

  const handleCopyAccount = () => {
    navigator.clipboard.writeText(bankSettings.accountNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setReceiptFilename(file.name);

    const reader = new FileReader();
    reader.onloadend = () => {
      setReceiptPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitReceipt = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!booking) {
      setErrorMessage('No booking selected.');
      return;
    }

    if (!receiptPreview) {
      setErrorMessage('Please attach or select your payment transfer receipt image/PDF.');
      return;
    }

    if (!senderAccountName.trim() || !senderBankName.trim()) {
      setErrorMessage('Please specify the Sender Account Name and Bank.');
      return;
    }

    setIsSubmitting(true);

    try {
      const updatedPayment = StorageService.submitPaymentReceipt({
        bookingId: booking.id,
        senderAccountName: senderAccountName.trim(),
        senderBankName: senderBankName.trim(),
        transactionReference: transactionRef.trim() || `TXN-${Date.now().toString().slice(-6)}`,
        receiptImageUrl: receiptPreview,
        receiptFilename: receiptFilename || 'transfer_receipt.png',
      });

      if (updatedPayment) {
        setPayment(updatedPayment);
        // Refresh booking status
        const refreshed = StorageService.getBookings().find(b => b.id === booking.id);
        if (refreshed) setBooking(refreshed);

        setSuccessMessage('Receipt submitted successfully! Your payment is now in the manual verification queue.');
      }
    } catch (err: any) {
      setErrorMessage('Failed to submit receipt. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!booking) {
    return (
      <div className="max-w-xl mx-auto py-24 px-4 text-center space-y-4">
        <Package className="w-12 h-12 text-neutral-400 mx-auto" />
        <h2 className="text-xl font-bold text-neutral-900">No Booking Found</h2>
        <p className="text-xs text-neutral-600">Please book a delivery first to proceed to the bank transfer checkout.</p>
        <button
          onClick={() => onNavigate('book-delivery')}
          className="px-6 py-2.5 bg-orange-600 text-white rounded-lg text-xs font-bold"
        >
          Book a Delivery
        </button>
      </div>
    );
  }

  const isReceiptSubmitted = payment?.paymentStatus === 'Receipt Submitted' || payment?.paymentStatus === 'Under Verification';
  const isApproved = payment?.paymentStatus === 'Payment Approved';
  const isRejected = payment?.paymentStatus === 'Payment Rejected';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      
      {/* Header */}
      <div className="mb-8">
        <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Manual Bank Checkout</div>
        <h1 className="text-3xl font-extrabold text-neutral-900 tracking-tight mt-1">
          Complete Your Bank Transfer
        </h1>
        <p className="text-xs sm:text-sm text-neutral-600 mt-2">
          Make a direct transfer to our verified corporate bank account, then upload your transaction receipt for administrator audit.
        </p>
      </div>

      {successMessage && (
        <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-start gap-2.5">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold">Confirmation Successful</div>
            <div>{successMessage}</div>
          </div>
        </div>
      )}

      {errorMessage && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Bank Details & Instructions */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Official Bank Account Card */}
          <div className="bg-neutral-950 text-white rounded-2xl p-6 sm:p-7 border border-neutral-800 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4 w-32 h-32 bg-orange-600/10 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-orange-500" />
                <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">Designated Bank Account</span>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> Official
              </span>
            </div>

            <div className="mt-6 space-y-4">
              
              {/* Account Number with 1-Click Copy */}
              <div>
                <div className="text-[11px] text-neutral-400 uppercase tracking-wide">Account Number</div>
                <div className="flex items-center justify-between mt-1 bg-neutral-900 border border-neutral-800 p-3 rounded-xl">
                  <span className="text-2xl font-bold font-mono tracking-widest text-white">
                    {bankSettings.accountNumber}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyAccount}
                    className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              {/* Bank Name */}
              <div className="grid grid-cols-2 gap-4 pt-2">
                <div>
                  <div className="text-[11px] text-neutral-400 uppercase tracking-wide">Bank Name</div>
                  <div className="text-sm font-bold text-white mt-0.5">{bankSettings.bankName}</div>
                </div>
                <div>
                  <div className="text-[11px] text-neutral-400 uppercase tracking-wide">Account Name</div>
                  <div className="text-sm font-bold text-white mt-0.5">{bankSettings.accountName}</div>
                </div>
              </div>

              {/* Sort Code / Branch */}
              {bankSettings.sortCode && (
                <div className="text-[11px] text-neutral-400 pt-1">
                  Sort Code: <span className="font-mono text-neutral-300">{bankSettings.sortCode}</span>
                </div>
              )}

            </div>

            {/* Narration Instruction */}
            <div className="mt-6 p-3.5 bg-neutral-900/90 rounded-xl border border-neutral-800 text-xs text-neutral-300 space-y-1">
              <div className="font-bold text-orange-400">Important Narration Rule:</div>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Please enter your tracking number <span className="font-mono font-bold text-white bg-black px-1.5 py-0.5 rounded">{booking.trackingNumber}</span> as the payment description or narration in your banking app.
              </p>
            </div>

          </div>

          {/* Receipt Upload Form */}
          <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-sm space-y-5">
            <div className="border-b border-neutral-100 pb-3 flex items-center justify-between">
              <h2 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                <Upload className="w-4 h-4 text-orange-600" />
                <span>Upload Payment Receipt</span>
              </h2>
              <span className="text-[11px] text-neutral-500 font-medium">Step 2 of 2</span>
            </div>

            {isApproved ? (
              <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 text-center">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <h3 className="text-sm font-bold text-emerald-900">Payment Confirmed & Approved</h3>
                <p className="text-xs text-emerald-700 leading-relaxed">
                  Your manual transfer of ₦{booking.totalAmount.toLocaleString()} has been audited and approved by the SWIFTDROP accounts desk. Your delivery is now released for dispatch!
                </p>
                <button
                  onClick={() => onNavigate('track-package', { trackingNumber: booking.trackingNumber })}
                  className="mt-3 px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-lg inline-flex items-center gap-1.5"
                >
                  <span>Track Consignment</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmitReceipt} className="space-y-4">
                
                {isRejected && (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                    <span className="font-bold">Previous receipt was rejected: </span>
                    {payment?.rejectionReason || 'Please upload a clear proof of payment.'}
                  </div>
                )}

                {isReceiptSubmitted && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Receipt is currently under administrator audit. You can upload a new receipt below if you made an error.</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-neutral-700 mb-1">Sender Account Name *</label>
                    <input
                      type="text"
                      required
                      value={senderAccountName}
                      onChange={(e) => setSenderAccountName(e.target.value)}
                      placeholder="Name on your bank account"
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-neutral-700 mb-1">Your Bank Name *</label>
                    <input
                      type="text"
                      required
                      value={senderBankName}
                      onChange={(e) => setSenderBankName(e.target.value)}
                      placeholder="e.g. GTBank, Access, Zenith, Kuda"
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">Transaction Reference / Session ID (Optional)</label>
                  <input
                    type="text"
                    value={transactionRef}
                    onChange={(e) => setTransactionRef(e.target.value)}
                    placeholder="Bank reference number or transfer session ID"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-900 focus:outline-none focus:border-orange-500"
                  />
                </div>

                {/* File Attachment Dropzone */}
                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">Transfer Receipt Screenshot / PDF *</label>
                  <div className="border-2 border-dashed border-neutral-300 hover:border-orange-500 rounded-xl p-4 text-center cursor-pointer transition-colors bg-neutral-50/50">
                    <input
                      type="file"
                      id="receiptUpload"
                      accept="image/*,application/pdf"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <label htmlFor="receiptUpload" className="cursor-pointer block space-y-1">
                      <Upload className="w-6 h-6 text-neutral-400 mx-auto" />
                      <div className="text-xs font-semibold text-neutral-800">
                        {receiptFilename ? receiptFilename : 'Click to select receipt image or screenshot'}
                      </div>
                      <div className="text-[11px] text-neutral-500">Supports JPG, PNG, PDF up to 10MB</div>
                    </label>
                  </div>

                  {receiptPreview && (
                    <div className="mt-3 p-2 bg-neutral-100 rounded-lg flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs text-neutral-700 truncate max-w-xs">
                        <FileText className="w-4 h-4 text-orange-600 shrink-0" />
                        <span className="truncate">{receiptFilename}</span>
                      </div>
                      <span className="text-[11px] text-emerald-600 font-semibold">Attached</span>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>{isSubmitting ? 'Submitting Receipt...' : 'Submit Payment Confirmation'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

              </form>
            )}

          </div>

        </div>

        {/* Right Column: Order & Verification Status Box */}
        <div className="lg:col-span-5 space-y-6">
          
          <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <span className="text-xs font-bold text-neutral-900 uppercase tracking-wider">Booking Particulars</span>
              <span className="text-xs font-mono font-bold text-orange-600">{booking.trackingNumber}</span>
            </div>

            <div className="space-y-3 text-xs text-neutral-600">
              <div className="flex justify-between">
                <span>Customer:</span>
                <span className="font-semibold text-neutral-900">{booking.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span>Phone:</span>
                <span className="font-mono text-neutral-900">{booking.customerPhone}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Type:</span>
                <span className="font-semibold text-neutral-900 capitalize">{booking.deliveryType} Delivery</span>
              </div>
              <div className="flex justify-between">
                <span>Pickup:</span>
                <span className="font-medium text-neutral-800 truncate max-w-[180px]">{booking.pickupCity}, {booking.pickupState}</span>
              </div>
              <div className="flex justify-between">
                <span>Destination:</span>
                <span className="font-medium text-neutral-800 truncate max-w-[180px]">{booking.destinationCity}, {booking.destinationCountry}</span>
              </div>
              <div className="flex justify-between">
                <span>Package Weight:</span>
                <span className="font-mono text-neutral-900">{booking.packageWeight} kg</span>
              </div>
            </div>

            <div className="border-t border-neutral-100 pt-4">
              <div className="text-xs text-neutral-500">Amount To Pay</div>
              <div className="text-2xl font-extrabold text-neutral-900 font-mono mt-0.5">
                ₦{booking.totalAmount.toLocaleString()}
              </div>
            </div>

            {/* Payment Audit Status */}
            <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1.5">
              <div className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wide">Audit Status</div>
              <div>
                <StatusBadge 
                  status={payment?.paymentStatus || 'Awaiting Payment'} 
                  type="payment" 
                  className="text-xs" 
                />
              </div>
              <p className="text-[11px] text-neutral-500 leading-snug pt-1">
                {payment?.paymentStatus === 'Payment Approved'
                  ? 'Payment has been cleared. Dispatch in progress.'
                  : payment?.paymentStatus === 'Receipt Submitted' || payment?.paymentStatus === 'Under Verification'
                  ? 'Receipt received. An accounts administrator will verify within 15-30 minutes.'
                  : 'Awaiting your transfer and receipt upload to begin courier dispatch.'}
              </p>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => onNavigate('track-package', { trackingNumber: booking.trackingNumber })}
                className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>View Full Tracking Details</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <WhatsAppButton 
                variant="button" 
                label="Confirm Receipt via WhatsApp" 
                message={`Hello SWIFTDROP! I have made payment for tracking number ${booking.trackingNumber} and uploaded my receipt.`}
                className="w-full text-xs py-2.5" 
              />
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
