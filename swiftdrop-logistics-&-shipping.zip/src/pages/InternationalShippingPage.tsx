import React from 'react';
import { IMAGES } from '../assets/images';
import { Plane, Globe, ShieldCheck, CheckCircle2, ArrowRight, FileCheck, Package } from 'lucide-react';
import { WhatsAppButton } from '../components/common/WhatsAppButton';

interface InternationalShippingPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const InternationalShippingPage: React.FC<InternationalShippingPageProps> = ({ onNavigate }) => {
  const globalDestinations = [
    {
      country: 'United Kingdom',
      cities: 'London (Heathrow Cargo Hub), Manchester, Birmingham, Glasgow',
      transit: '3 - 5 Business Days',
      rate: 'From ₦42,000',
    },
    {
      country: 'United States & Canada',
      cities: 'New York (JFK), Houston, Atlanta, Chicago, Toronto, Calgary',
      transit: '5 - 8 Business Days',
      rate: 'From ₦52,000',
    },
    {
      country: 'United Arab Emirates (UAE)',
      cities: 'Dubai (DXB Cargo Terminal), Abu Dhabi, Sharjah',
      transit: '3 - 6 Business Days',
      rate: 'From ₦38,000',
    },
    {
      country: 'Western Europe',
      cities: 'Germany (Frankfurt), France (Paris CDG), Ireland (Dublin), Italy',
      transit: '4 - 7 Business Days',
      rate: 'From ₦45,000',
    },
    {
      country: 'West & South Africa',
      cities: 'Ghana (Accra), South Africa (Johannesburg), Kenya (Nairobi)',
      transit: '3 - 5 Business Days',
      rate: 'From ₦26,000',
    },
    {
      country: 'Asia & Middle East',
      cities: 'China (Guangzhou / Hong Kong), India (Mumbai), Qatar',
      transit: '5 - 8 Business Days',
      rate: 'From ₦48,000',
    },
  ];

  const allowedGoods = [
    'Traditional Attires, Aso-Ebi & Fashion Garments',
    'Packaged Dry African Foodstuffs (Garri, Crayfish, Egusi, Spices)',
    'Official Educational Transcripts & Legal Certificates',
    'Commercial Samples, Crafts & Artworks',
    'Cosmetics, Shea Butter & Skincare Formulations',
    'E-commerce Merchandise & Manufactured Consumer Items',
  ];

  return (
    <div className="space-y-16 pb-20">
      
      {/* Hero */}
      <section className="bg-neutral-950 text-white py-16 border-b border-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="text-xs font-bold text-orange-400 uppercase tracking-widest">Global Air Freight & Cargo Export</div>
              <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
                International Shipping From Nigeria to the World
              </h1>
              <p className="text-sm text-neutral-300 leading-relaxed">
                Connect the Nigerian diaspora and global trade partners with swift, secure air cargo. We handle export customs documentation, air waybill issuance, and expedited customs clearance to the UK, USA, Canada, and over 80 countries.
              </p>
              <div className="pt-2 flex flex-wrap gap-4">
                <button
                  onClick={() => onNavigate('book-delivery', { deliveryType: 'international' })}
                  className="px-6 py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Book International Shipment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <WhatsAppButton variant="button" label="International Freight Desk" className="text-xs py-3.5" />
              </div>
            </div>
            <div className="lg:col-span-5">
              <div className="rounded-2xl overflow-hidden border border-neutral-800 shadow-xl">
                <img
                  src={IMAGES.hero}
                  alt="International air cargo loading"
                  className="w-full h-80 object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popular International Destinations */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <div className="text-xs font-bold text-orange-600 uppercase tracking-widest">Key Flight Corridors</div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900">
            Express Air Cargo Destinations & Timelines
          </h2>
          <p className="text-xs sm:text-sm text-neutral-600">
            Scheduled weekly air cargo departures departing from Murtala Muhammed International Airport (LOS).
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {globalDestinations.map((dest, idx) => (
            <div key={idx} className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-neutral-900">{dest.country}</span>
                  <span className="text-xs font-bold font-mono text-orange-600">{dest.rate}</span>
                </div>
                <div className="text-[11px] text-neutral-500 font-medium mt-1">
                  Air Cargo Transit: <span className="text-neutral-800 font-semibold">{dest.transit}</span>
                </div>
                <p className="text-xs text-neutral-600 mt-3 leading-relaxed">
                  <span className="font-semibold text-neutral-700">Hubs Served:</span> {dest.cities}
                </p>
              </div>

              <div className="pt-3 border-t border-neutral-100 flex items-center justify-between">
                <span className="text-[11px] text-neutral-500 font-mono">Customs Included</span>
                <button
                  onClick={() => onNavigate('book-delivery', { deliveryType: 'international' })}
                  className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1"
                >
                  <span>Ship Now</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Allowed Goods & Customs Guidelines */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center bg-neutral-900 text-white rounded-2xl p-8 sm:p-12 border border-neutral-800">
          <div className="space-y-4">
            <div className="text-xs font-bold text-orange-400 uppercase tracking-widest">Compliant Freight</div>
            <h3 className="text-2xl font-extrabold text-white">
              Approved Items For International Shipping
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
              We ensure complete compliance with international civil aviation and customs regulations (IATA, TSA, UK Border Force). All packages undergo export scanning and certified packing.
            </p>
            <div className="pt-2">
              <WhatsAppButton 
                variant="button" 
                label="Check Item Eligibility on WhatsApp" 
                className="text-xs py-2.5" 
              />
            </div>
          </div>

          <div className="space-y-3 bg-neutral-950/60 p-6 rounded-xl border border-neutral-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-orange-400">Commonly Exported Categories</h4>
            <div className="space-y-2 text-xs text-neutral-300">
              {allowedGoods.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
            <div className="text-[11px] text-neutral-500 pt-2 border-t border-neutral-800">
              * Note: Liquids, batteries, and prohibited agricultural items require special regulatory permits. Contact our desk for advice.
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
