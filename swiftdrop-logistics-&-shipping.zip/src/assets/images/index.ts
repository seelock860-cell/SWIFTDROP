export const IMAGES = {
  hero: '/src/assets/images/hero_cargo_aircraft_logistics_1793430818437.jpg',
  dispatchRider: '/src/assets/images/delivery_dispatch_rider_1793430819507.jpg',
  warehouseHub: '/src/assets/images/logistics_warehouse_hub_1793430819860.jpg',
  internationalCargo: '/src/assets/images/international_freight_cargo_1793430819881.jpg',
};
