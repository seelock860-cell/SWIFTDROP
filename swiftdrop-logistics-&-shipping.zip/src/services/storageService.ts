import { 
  BankSettings, 
  Booking, 
  Customer, 
  DeliveryPricing, 
  PaymentRecord, 
  TrackingCheckpoint, 
  WebsiteSettings,
  Profile
} from '../types';
import { supabase, isSupabaseConfigured, SupabaseRemote } from '../lib/supabase';

const STORAGE_KEYS = {
  BANK_SETTINGS: 'swiftdrop_bank_settings',
  PRICING: 'swiftdrop_pricing',
  BOOKINGS: 'swiftdrop_bookings',
  PAYMENTS: 'swiftdrop_payments',
  TRACKING: 'swiftdrop_tracking_history',
  CUSTOMERS: 'swiftdrop_customers',
  WEBSITE_SETTINGS: 'swiftdrop_website_settings',
  CURRENT_USER: 'swiftdrop_current_user',
  ADMIN_SESSION: 'swiftdrop_admin_session',
};

// Default Initial Bank Transfer Settings
export const DEFAULT_BANK_SETTINGS: BankSettings = {
  id: 'bank-default-1',
  bankName: 'Zenith Bank Nigeria',
  accountName: 'SWIFTDROP LOGISTICS LTD',
  accountNumber: '1019842590',
  sortCode: '057150013',
  instructions: 'Please use your unique Tracking Number as payment narration/reference. Upload your transfer receipt immediately for instant verification.',
  isActive: true,
  updatedAt: new Date().toISOString(),
};

// Default Pricing Matrix
export const DEFAULT_PRICING: DeliveryPricing[] = [
  {
    id: 'price-1',
    deliveryType: 'local',
    destinationRegion: 'Lagos Intra-City (Island & Mainland)',
    basePrice: 3000,
    pricePerKg: 600,
    estimatedDaysMin: 0,
    estimatedDaysMax: 1,
    currency: 'NGN',
    isActive: true,
  },
  {
    id: 'price-2',
    deliveryType: 'local',
    destinationRegion: 'Abuja Municipal / Central Area',
    basePrice: 3500,
    pricePerKg: 700,
    estimatedDaysMin: 0,
    estimatedDaysMax: 1,
    currency: 'NGN',
    isActive: true,
  },
  {
    id: 'price-3',
    deliveryType: 'local',
    destinationRegion: 'Port Harcourt / Ibadan Metro',
    basePrice: 3200,
    pricePerKg: 650,
    estimatedDaysMin: 0,
    estimatedDaysMax: 1,
    currency: 'NGN',
    isActive: true,
  },
  {
    id: 'price-4',
    deliveryType: 'nationwide',
    destinationRegion: 'South-West & South-South States',
    basePrice: 6500,
    pricePerKg: 1200,
    estimatedDaysMin: 2,
    estimatedDaysMax: 3,
    currency: 'NGN',
    isActive: true,
  },
  {
    id: 'price-5',
    deliveryType: 'nationwide',
    destinationRegion: 'North-Central & FCT Interstate',
    basePrice: 7500,
    pricePerKg: 1400,
    estimatedDaysMin: 2,
    estimatedDaysMax: 4,
    currency: 'NGN',
    isActive: true,
  },
  {
    id: 'price-6',
    deliveryType: 'nationwide',
    destinationRegion: 'North-West & North-East States',
    basePrice: 8500,
    pricePerKg: 1600,
    estimatedDaysMin: 3,
    estimatedDaysMax: 5,
    currency: 'NGN',
    isActive: true,
  },
  {
    id: 'price-7',
    deliveryType: 'international',
    destinationRegion: 'United Kingdom & Western Europe',
    basePrice: 42000,
    pricePerKg: 8500,
    estimatedDaysMin: 4,
    estimatedDaysMax: 7,
    currency: 'NGN',
    isActive: true,
  },
  {
    id: 'price-8',
    deliveryType: 'international',
    destinationRegion: 'USA & Canada (Express Air Cargo)',
    basePrice: 52000,
    pricePerKg: 10500,
    estimatedDaysMin: 5,
    estimatedDaysMax: 8,
    currency: 'NGN',
    isActive: true,
  },
  {
    id: 'price-9',
    deliveryType: 'international',
    destinationRegion: 'UAE / Dubai & Middle East',
    basePrice: 38000,
    pricePerKg: 8000,
    estimatedDaysMin: 3,
    estimatedDaysMax: 6,
    currency: 'NGN',
    isActive: true,
  },
  {
    id: 'price-10',
    deliveryType: 'international',
    destinationRegion: 'West African Coast (Ghana, Togo, Benin)',
    basePrice: 26000,
    pricePerKg: 5000,
    estimatedDaysMin: 3,
    estimatedDaysMax: 5,
    currency: 'NGN',
    isActive: true,
  },
];

// Default Website Settings
export const DEFAULT_WEBSITE_SETTINGS: WebsiteSettings = {
  companyName: 'SWIFTDROP Logistics & Shipping',
  whatsappNumber: '09024971419',
  contactEmail: 'support@swiftdrop.ng',
  phoneNumber: '+234 902 497 1419',
  officeAddress: 'Plot 14B Admiralty Way, Lekki Phase 1, Lagos, Nigeria',
  workingHours: 'Mon - Sat: 8:00 AM - 7:00 PM',
  announcementBanner: 'Same-day delivery across Lagos & Abuja. Fast air freight to UK, USA & Europe!',
};

// Seed Customers
const SEED_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    fullName: 'Adewale Johnson',
    email: 'adewale.j@example.com',
    phone: '08034567890',
    companyName: 'Lekki Commerce Ltd',
    address: '15 Admiralty Way',
    city: 'Lekki',
    state: 'Lagos',
    country: 'Nigeria',
    totalBookings: 3,
    totalSpent: 54500,
    createdAt: '2026-09-10T10:00:00Z',
  },
  {
    id: 'cust-2',
    fullName: 'Chioma Okonkwo',
    email: 'chioma.o@example.com',
    phone: '08129876543',
    companyName: 'Okonkwo Fashion Hub',
    address: '42 Gana Street, Maitama',
    city: 'Abuja',
    state: 'FCT',
    country: 'Nigeria',
    totalBookings: 2,
    totalSpent: 89000,
    createdAt: '2026-09-18T14:30:00Z',
  },
  {
    id: 'cust-3',
    fullName: 'Ibrahim Danjuma',
    email: 'ibrahim.d@example.com',
    phone: '07051234567',
    companyName: 'Northern Agro Traders',
    address: '88 Bompai Road',
    city: 'Kano',
    state: 'Kano',
    country: 'Nigeria',
    totalBookings: 1,
    totalSpent: 11700,
    createdAt: '2026-10-02T08:15:00Z',
  },
];

// Seed Bookings
const SEED_BOOKINGS: Booking[] = [
  {
    id: 'b-101',
    trackingNumber: 'SWD-2026-89412',
    customerId: 'cust-1',
    customerName: 'Adewale Johnson',
    customerEmail: 'adewale.j@example.com',
    customerPhone: '08034567890',
    pickupCountry: 'Nigeria',
    pickupState: 'Lagos',
    pickupCity: 'Ikeja',
    pickupAddress: 'Block 4, Allen Avenue',
    destinationCountry: 'Nigeria',
    destinationState: 'Lagos',
    destinationCity: 'Victoria Island',
    destinationAddress: '23 Adeola Odeku Street',
    packageDescription: 'Confidential legal contracts and business documents in water-sealed pouch',
    packageCategory: 'documents',
    packageWeight: 1.5,
    deliveryType: 'local',
    preferredPickupDate: '2026-10-30',
    additionalInstructions: 'Please deliver strictly to the reception desk on 3rd floor.',
    totalAmount: 3900,
    currency: 'NGN',
    bookingStatus: 'In Transit',
    estimatedDeliveryDate: '2026-10-31',
    createdAt: '2026-10-30T09:12:00Z',
    updatedAt: '2026-10-31T06:30:00Z',
  },
  {
    id: 'b-102',
    trackingNumber: 'SWD-2026-63104',
    customerId: 'cust-2',
    customerName: 'Chioma Okonkwo',
    customerEmail: 'chioma.o@example.com',
    customerPhone: '08129876543',
    pickupCountry: 'Nigeria',
    pickupState: 'Lagos',
    pickupCity: 'Yaba',
    pickupAddress: '78 Commercial Avenue',
    destinationCountry: 'Nigeria',
    destinationState: 'FCT',
    destinationCity: 'Abuja',
    destinationAddress: 'Plot 104, Diplomatic Zone, Central Business District',
    packageDescription: 'High-end designer traditional attires and beadwork',
    packageCategory: 'fashion',
    packageWeight: 4.8,
    deliveryType: 'nationwide',
    preferredPickupDate: '2026-10-28',
    additionalInstructions: 'Handle with care. Fabric is luxury lace.',
    totalAmount: 13260,
    currency: 'NGN',
    bookingStatus: 'Arrived at Destination',
    estimatedDeliveryDate: '2026-10-31',
    createdAt: '2026-10-28T11:45:00Z',
    updatedAt: '2026-10-31T04:20:00Z',
  },
  {
    id: 'b-103',
    trackingNumber: 'SWD-2026-14782',
    customerId: 'cust-1',
    customerName: 'Adewale Johnson',
    customerEmail: 'adewale.j@example.com',
    customerPhone: '08034567890',
    pickupCountry: 'Nigeria',
    pickupState: 'Lagos',
    pickupCity: 'Lekki',
    pickupAddress: '15 Admiralty Way',
    destinationCountry: 'United Kingdom',
    destinationState: 'Greater London',
    destinationCity: 'London',
    destinationAddress: '14 Rotherhithe Street, Canary Wharf',
    packageDescription: 'Commercial craft samples and packaged dry spices for European distribution',
    packageCategory: 'parcel',
    packageWeight: 6.2,
    deliveryType: 'international',
    preferredPickupDate: '2026-10-31',
    additionalInstructions: 'Recipient will pay customs duties upon clearance at Heathrow cargo hub.',
    totalAmount: 94700,
    currency: 'NGN',
    bookingStatus: 'Payment Pending',
    estimatedDeliveryDate: '2026-11-06',
    createdAt: '2026-10-30T16:20:00Z',
    updatedAt: '2026-10-30T16:20:00Z',
  },
  {
    id: 'b-104',
    trackingNumber: 'SWD-2026-55291',
    customerId: 'cust-3',
    customerName: 'Ibrahim Danjuma',
    customerEmail: 'ibrahim.d@example.com',
    customerPhone: '07051234567',
    pickupCountry: 'Nigeria',
    pickupState: 'Kano',
    pickupCity: 'Kano',
    pickupAddress: '88 Bompai Road',
    destinationCountry: 'Nigeria',
    destinationState: 'Kaduna',
    destinationCity: 'Kaduna',
    destinationAddress: '12 Ahmadu Bello Way',
    packageDescription: 'Industrial precision pump components and fittings',
    packageCategory: 'industrial',
    packageWeight: 2.0,
    deliveryType: 'nationwide',
    preferredPickupDate: '2026-10-27',
    additionalInstructions: 'Recipient phone must be called 30 mins before arrival.',
    totalAmount: 11700,
    currency: 'NGN',
    bookingStatus: 'Delivered',
    estimatedDeliveryDate: '2026-10-29',
    createdAt: '2026-10-27T08:00:00Z',
    updatedAt: '2026-10-29T15:10:00Z',
  },
];

// Seed Tracking Checkpoints
const SEED_TRACKING: TrackingCheckpoint[] = [
  // b-101
  {
    id: 'tr-101-1',
    bookingId: 'b-101',
    trackingNumber: 'SWD-2026-89412',
    status: 'Booking Received',
    location: 'Ikeja Dispatch Terminal, Lagos',
    notes: 'Order initiated online. Awaiting dispatch assignment.',
    recordedBy: 'Automated Booking Engine',
    timestamp: '2026-10-30T09:12:00Z',
  },
  {
    id: 'tr-101-2',
    bookingId: 'b-101',
    trackingNumber: 'SWD-2026-89412',
    status: 'Payment Confirmed',
    location: 'SWIFTDROP Finance Department',
    notes: 'Bank transfer verified. Receipt reference ZNB-992384. Approved.',
    recordedBy: 'Admin (swift)',
    timestamp: '2026-10-30T10:05:00Z',
  },
  {
    id: 'tr-101-3',
    bookingId: 'b-101',
    trackingNumber: 'SWD-2026-89412',
    status: 'Package Picked Up',
    location: 'Allen Avenue, Ikeja',
    notes: 'Courier rider Kayode (Rider #14) collected sealed document package.',
    recordedBy: 'Courier Kayode',
    timestamp: '2026-10-30T14:40:00Z',
  },
  {
    id: 'tr-101-4',
    bookingId: 'b-101',
    trackingNumber: 'SWD-2026-89412',
    status: 'In Transit',
    location: 'Third Mainland Bridge en route to Victoria Island Hub',
    notes: 'Package is on motorcycle express dispatch transit.',
    recordedBy: 'Dispatch Operations',
    timestamp: '2026-10-31T06:30:00Z',
  },

  // b-102
  {
    id: 'tr-102-1',
    bookingId: 'b-102',
    trackingNumber: 'SWD-2026-63104',
    status: 'Booking Received',
    location: 'Lagos Main Logistics Hub',
    notes: 'Nationwide dispatch order created.',
    recordedBy: 'System',
    timestamp: '2026-10-28T11:45:00Z',
  },
  {
    id: 'tr-102-2',
    bookingId: 'b-102',
    trackingNumber: 'SWD-2026-63104',
    status: 'Payment Confirmed',
    location: 'SWIFTDROP Accounts',
    notes: 'Payment verified via bank transfer.',
    recordedBy: 'Admin (swift)',
    timestamp: '2026-10-28T12:15:00Z',
  },
  {
    id: 'tr-102-3',
    bookingId: 'b-102',
    trackingNumber: 'SWD-2026-63104',
    status: 'Package Picked Up',
    location: 'Commercial Avenue, Yaba, Lagos',
    notes: 'Goods weighed, tagged, and loaded on interstate secure vehicle.',
    recordedBy: 'Driver Tunde',
    timestamp: '2026-10-28T16:00:00Z',
  },
  {
    id: 'tr-102-4',
    bookingId: 'b-102',
    trackingNumber: 'SWD-2026-63104',
    status: 'In Transit',
    location: 'Lokoja - Abuja Highway Corridor',
    notes: 'Interstate cargo carrier in transit under GPS monitoring.',
    recordedBy: 'Fleet Control',
    timestamp: '2026-10-29T19:00:00Z',
  },
  {
    id: 'tr-102-5',
    bookingId: 'b-102',
    trackingNumber: 'SWD-2026-63104',
    status: 'Arrived at Destination',
    location: 'Abuja Central Sorting Facility, Idu Industrial Area',
    notes: 'Consignment sorted. Prepared for local last-mile dispatch.',
    recordedBy: 'Hub Supervisor',
    timestamp: '2026-10-31T04:20:00Z',
  },

  // b-103
  {
    id: 'tr-103-1',
    bookingId: 'b-103',
    trackingNumber: 'SWD-2026-14782',
    status: 'Booking Received',
    location: 'Lekki Booking Office, Lagos',
    notes: 'International air freight booking registered. Awaiting customer bank payment.',
    recordedBy: 'System',
    timestamp: '2026-10-30T16:20:00Z',
  },

  // b-104
  {
    id: 'tr-104-1',
    bookingId: 'b-104',
    trackingNumber: 'SWD-2026-55291',
    status: 'Delivered',
    location: '12 Ahmadu Bello Way, Kaduna',
    notes: 'Signed and accepted by Malam Sanusi on 29 Oct.',
    recordedBy: 'Courier Agent',
    timestamp: '2026-10-29T15:10:00Z',
  },
];

// Seed Payments
const SEED_PAYMENTS: PaymentRecord[] = [
  {
    id: 'pay-1',
    bookingId: 'b-101',
    trackingNumber: 'SWD-2026-89412',
    amount: 3900,
    currency: 'NGN',
    bankNamePaidTo: 'Zenith Bank Nigeria',
    accountNumberPaidTo: '1019842590',
    senderAccountName: 'Adewale Johnson',
    senderBankName: 'GTBank',
    transactionReference: 'ZNB-992384-LAG',
    receiptImageUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
    receiptFilename: 'gtb_transfer_receipt_3900.jpg',
    paymentStatus: 'Payment Approved',
    verifiedBy: 'swift (Admin)',
    verifiedAt: '2026-10-30T10:05:00Z',
    createdAt: '2026-10-30T09:45:00Z',
    updatedAt: '2026-10-30T10:05:00Z',
  },
  {
    id: 'pay-2',
    bookingId: 'b-102',
    trackingNumber: 'SWD-2026-63104',
    amount: 13260,
    currency: 'NGN',
    bankNamePaidTo: 'Zenith Bank Nigeria',
    accountNumberPaidTo: '1019842590',
    senderAccountName: 'Chioma Okonkwo',
    senderBankName: 'Access Bank',
    transactionReference: 'ACC-883190-FCT',
    receiptImageUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
    receiptFilename: 'access_bank_receipt_13260.png',
    paymentStatus: 'Payment Approved',
    verifiedBy: 'swift (Admin)',
    verifiedAt: '2026-10-28T12:15:00Z',
    createdAt: '2026-10-28T12:00:00Z',
    updatedAt: '2026-10-28T12:15:00Z',
  },
  {
    id: 'pay-3',
    bookingId: 'b-103',
    trackingNumber: 'SWD-2026-14782',
    amount: 94700,
    currency: 'NGN',
    bankNamePaidTo: 'Zenith Bank Nigeria',
    accountNumberPaidTo: '1019842590',
    senderAccountName: 'Adewale Johnson',
    senderBankName: 'Zenith Bank',
    transactionReference: 'ZNB-774012-INTL',
    receiptImageUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
    receiptFilename: 'zenith_app_transfer_receipt.jpg',
    paymentStatus: 'Under Verification',
    createdAt: '2026-10-30T17:10:00Z',
    updatedAt: '2026-10-30T17:10:00Z',
  },
  {
    id: 'pay-4',
    bookingId: 'b-104',
    trackingNumber: 'SWD-2026-55291',
    amount: 11700,
    currency: 'NGN',
    bankNamePaidTo: 'Zenith Bank Nigeria',
    accountNumberPaidTo: '1019842590',
    senderAccountName: 'Ibrahim Danjuma',
    senderBankName: 'First Bank',
    transactionReference: 'FBN-332190-KD',
    receiptImageUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
    receiptFilename: 'firstbank_transfer.pdf',
    paymentStatus: 'Payment Approved',
    verifiedBy: 'swift (Admin)',
    verifiedAt: '2026-10-27T08:45:00Z',
    createdAt: '2026-10-27T08:20:00Z',
    updatedAt: '2026-10-27T08:45:00Z',
  },
];

// Helper to initialize local storage
function initStorage() {
  if (!localStorage.getItem(STORAGE_KEYS.BANK_SETTINGS)) {
    localStorage.setItem(STORAGE_KEYS.BANK_SETTINGS, JSON.stringify(DEFAULT_BANK_SETTINGS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.PRICING)) {
    localStorage.setItem(STORAGE_KEYS.PRICING, JSON.stringify(DEFAULT_PRICING));
  }
  if (!localStorage.getItem(STORAGE_KEYS.WEBSITE_SETTINGS)) {
    localStorage.setItem(STORAGE_KEYS.WEBSITE_SETTINGS, JSON.stringify(DEFAULT_WEBSITE_SETTINGS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.CUSTOMERS)) {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(SEED_CUSTOMERS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.BOOKINGS)) {
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(SEED_BOOKINGS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.TRACKING)) {
    localStorage.setItem(STORAGE_KEYS.TRACKING, JSON.stringify(SEED_TRACKING));
  }
  if (!localStorage.getItem(STORAGE_KEYS.PAYMENTS)) {
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(SEED_PAYMENTS));
  }
}

// Ensure storage is initialized on module load
if (typeof window !== 'undefined') {
  initStorage();
}

export const StorageService = {
  // BANK SETTINGS
  getBankSettings(): BankSettings {
    const raw = localStorage.getItem(STORAGE_KEYS.BANK_SETTINGS);
    return raw ? JSON.parse(raw) : DEFAULT_BANK_SETTINGS;
  },

  updateBankSettings(settings: Partial<BankSettings>): BankSettings {
    const current = this.getBankSettings();
    const updated: BankSettings = {
      ...current,
      ...settings,
      updatedAt: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEYS.BANK_SETTINGS, JSON.stringify(updated));
    SupabaseRemote.syncBankSettings(updated);
    return updated;
  },

  // PRICING
  getPricing(): DeliveryPricing[] {
    const raw = localStorage.getItem(STORAGE_KEYS.PRICING);
    return raw ? JSON.parse(raw) : DEFAULT_PRICING;
  },

  updatePricing(id: string, updates: Partial<DeliveryPricing>): DeliveryPricing[] {
    const list = this.getPricing();
    const index = list.findIndex(p => p.id === id);
    if (index !== -1) {
      list[index] = { ...list[index], ...updates };
      localStorage.setItem(STORAGE_KEYS.PRICING, JSON.stringify(list));
    }
    return list;
  },

  calculatePrice(deliveryType: string, weightKg: number): { amount: number; estimatedDays: string } {
    const pricingList = this.getPricing();
    const tier = pricingList.find(p => p.deliveryType === deliveryType && p.isActive) || pricingList[0];
    const weight = Math.max(1, weightKg);
    const extraWeight = Math.max(0, weight - 1);
    const total = tier.basePrice + (extraWeight * tier.pricePerKg);
    const days = tier.estimatedDaysMin === 0 
      ? 'Same-day delivery' 
      : `${tier.estimatedDaysMin} - ${tier.estimatedDaysMax} business days`;
    return { amount: Math.round(total), estimatedDays: days };
  },

  // BOOKINGS
  getBookings(): Booking[] {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
    return raw ? JSON.parse(raw) : [];
  },

  getBookingByTrackingNumber(trackingNum: string): Booking | null {
    const cleanNum = trackingNum.trim().toUpperCase();
    const bookings = this.getBookings();
    return bookings.find(b => b.trackingNumber.toUpperCase() === cleanNum) || null;
  },

  getBookingsByCustomer(email: string): Booking[] {
    const cleanEmail = email.trim().toLowerCase();
    const bookings = this.getBookings();
    return bookings.filter(b => b.customerEmail.toLowerCase() === cleanEmail);
  },

  createBooking(data: Omit<Booking, 'id' | 'trackingNumber' | 'createdAt' | 'updatedAt'>): Booking {
    const bookings = this.getBookings();
    // Unique Tracking Number format: SWD-YEAR-5DIGITS
    const randomDigits = Math.floor(10000 + Math.random() * 90000);
    const currentYear = new Date().getFullYear();
    const trackingNumber = `SWD-${currentYear}-${randomDigits}`;

    const newBooking: Booking = {
      ...data,
      id: `booking-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      trackingNumber,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    bookings.unshift(newBooking);
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
    SupabaseRemote.insertBooking(newBooking);

    // Initial tracking event
    this.addTrackingCheckpoint({
      bookingId: newBooking.id,
      trackingNumber: newBooking.trackingNumber,
      status: 'Booking Received',
      location: `${newBooking.pickupCity}, ${newBooking.pickupState}`,
      notes: `Order created. Delivery method: ${newBooking.deliveryType.toUpperCase()}. Awaiting manual bank payment confirmation.`,
      recordedBy: 'SWIFTDROP Booking Portal',
    });

    // Initial Payment Record
    this.createPaymentRecord({
      bookingId: newBooking.id,
      trackingNumber: newBooking.trackingNumber,
      amount: newBooking.totalAmount,
      currency: newBooking.currency,
      bankNamePaidTo: this.getBankSettings().bankName,
      accountNumberPaidTo: this.getBankSettings().accountNumber,
      paymentStatus: 'Awaiting Payment',
    });

    // Update customer stats
    this.registerOrUpdateCustomer({
      fullName: newBooking.customerName,
      email: newBooking.customerEmail,
      phone: newBooking.customerPhone,
      city: newBooking.pickupCity,
      state: newBooking.pickupState,
      country: newBooking.pickupCountry,
      address: newBooking.pickupAddress,
    }, newBooking.totalAmount);

    return newBooking;
  },

  updateBookingStatus(id: string, newStatus: Booking['bookingStatus'], locationNote?: string): Booking | null {
    const bookings = this.getBookings();
    const index = bookings.findIndex(b => b.id === id);
    if (index === -1) return null;

    bookings[index].bookingStatus = newStatus;
    bookings[index].updatedAt = new Date().toISOString();
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
    SupabaseRemote.updateBookingStatus(id, newStatus);

    // Automatically record checkpoint in tracking history
    this.addTrackingCheckpoint({
      bookingId: bookings[index].id,
      trackingNumber: bookings[index].trackingNumber,
      status: newStatus,
      location: locationNote || `${bookings[index].destinationCity}, ${bookings[index].destinationState}`,
      notes: `Status updated to ${newStatus}.`,
      recordedBy: 'SWIFTDROP Dispatch Center',
    });

    return bookings[index];
  },

  // TRACKING
  getTrackingCheckpoints(trackingNumber: string): TrackingCheckpoint[] {
    const clean = trackingNumber.trim().toUpperCase();
    const raw = localStorage.getItem(STORAGE_KEYS.TRACKING);
    const list: TrackingCheckpoint[] = raw ? JSON.parse(raw) : [];
    return list
      .filter(t => t.trackingNumber.toUpperCase() === clean)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  },

  addTrackingCheckpoint(data: Omit<TrackingCheckpoint, 'id' | 'timestamp'>): TrackingCheckpoint {
    const raw = localStorage.getItem(STORAGE_KEYS.TRACKING);
    const list: TrackingCheckpoint[] = raw ? JSON.parse(raw) : [];

    const newCheckpoint: TrackingCheckpoint = {
      ...data,
      id: `chk-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString(),
    };

    list.push(newCheckpoint);
    localStorage.setItem(STORAGE_KEYS.TRACKING, JSON.stringify(list));
    SupabaseRemote.insertTrackingCheckpoint(newCheckpoint);
    return newCheckpoint;
  },

  // PAYMENTS (Bank Transfer only)
  getPayments(): PaymentRecord[] {
    const raw = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    return raw ? JSON.parse(raw) : [];
  },

  getPaymentByBookingId(bookingId: string): PaymentRecord | null {
    const payments = this.getPayments();
    return payments.find(p => p.bookingId === bookingId) || null;
  },

  getPaymentByTrackingNumber(trackingNumber: string): PaymentRecord | null {
    const clean = trackingNumber.trim().toUpperCase();
    const payments = this.getPayments();
    return payments.find(p => p.trackingNumber.toUpperCase() === clean) || null;
  },

  createPaymentRecord(data: Omit<PaymentRecord, 'id' | 'createdAt' | 'updatedAt'>): PaymentRecord {
    const payments = this.getPayments();
    const newRecord: PaymentRecord = {
      ...data,
      id: `pay-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    payments.unshift(newRecord);
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
    return newRecord;
  },

  submitPaymentReceipt(params: {
    bookingId: string;
    senderAccountName: string;
    senderBankName: string;
    transactionReference: string;
    receiptImageUrl: string;
    receiptFilename: string;
  }): PaymentRecord | null {
    const payments = this.getPayments();
    let payment = payments.find(p => p.bookingId === params.bookingId);
    
    if (payment) {
      payment.senderAccountName = params.senderAccountName;
      payment.senderBankName = params.senderBankName;
      payment.transactionReference = params.transactionReference;
      payment.receiptImageUrl = params.receiptImageUrl;
      payment.receiptFilename = params.receiptFilename;
      payment.paymentStatus = 'Receipt Submitted';
      payment.updatedAt = new Date().toISOString();
    } else {
      // Find booking to create payment record
      const booking = this.getBookings().find(b => b.id === params.bookingId);
      if (!booking) return null;
      payment = {
        id: `pay-${Date.now()}`,
        bookingId: booking.id,
        trackingNumber: booking.trackingNumber,
        amount: booking.totalAmount,
        currency: booking.currency,
        bankNamePaidTo: this.getBankSettings().bankName,
        accountNumberPaidTo: this.getBankSettings().accountNumber,
        senderAccountName: params.senderAccountName,
        senderBankName: params.senderBankName,
        transactionReference: params.transactionReference,
        receiptImageUrl: params.receiptImageUrl,
        receiptFilename: params.receiptFilename,
        paymentStatus: 'Receipt Submitted',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      payments.unshift(payment);
    }

    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
    if (payment) SupabaseRemote.syncPayment(payment);

    // Update booking status to Payment Pending / Under Verification
    const bookings = this.getBookings();
    const bIndex = bookings.findIndex(b => b.id === params.bookingId);
    if (bIndex !== -1) {
      bookings[bIndex].bookingStatus = 'Payment Pending';
      bookings[bIndex].updatedAt = new Date().toISOString();
      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));

      this.addTrackingCheckpoint({
        bookingId: bookings[bIndex].id,
        trackingNumber: bookings[bIndex].trackingNumber,
        status: 'Payment Pending',
        location: 'SWIFTDROP Verification Queue',
        notes: `Transfer receipt uploaded (${params.receiptFilename}). Pending manual admin verification.`,
        recordedBy: 'Client Portal',
      });
    }

    return payment;
  },

  approvePayment(paymentId: string, adminUsername: string = 'swift'): PaymentRecord | null {
    const payments = this.getPayments();
    const pIndex = payments.findIndex(p => p.id === paymentId);
    if (pIndex === -1) return null;

    payments[pIndex].paymentStatus = 'Payment Approved';
    payments[pIndex].verifiedBy = `${adminUsername} (Administrator)`;
    payments[pIndex].verifiedAt = new Date().toISOString();
    payments[pIndex].updatedAt = new Date().toISOString();
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
    SupabaseRemote.syncPayment(payments[pIndex]);

    // Automatically update booking status to "Payment Confirmed"
    const bookings = this.getBookings();
    const bIndex = bookings.findIndex(b => b.id === payments[pIndex].bookingId);
    if (bIndex !== -1) {
      bookings[bIndex].bookingStatus = 'Payment Confirmed';
      bookings[bIndex].updatedAt = new Date().toISOString();
      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));

      this.addTrackingCheckpoint({
        bookingId: bookings[bIndex].id,
        trackingNumber: bookings[bIndex].trackingNumber,
        status: 'Payment Confirmed',
        location: 'SWIFTDROP Accounts & Operations',
        notes: `Bank transfer payment of ₦${payments[pIndex].amount.toLocaleString()} confirmed and verified by admin. Shipment authorized for dispatch.`,
        recordedBy: `Admin (${adminUsername})`,
      });
    }

    return payments[pIndex];
  },

  rejectPayment(paymentId: string, reason: string, adminUsername: string = 'swift'): PaymentRecord | null {
    const payments = this.getPayments();
    const pIndex = payments.findIndex(p => p.id === paymentId);
    if (pIndex === -1) return null;

    payments[pIndex].paymentStatus = 'Payment Rejected';
    payments[pIndex].rejectionReason = reason;
    payments[pIndex].verifiedBy = `${adminUsername} (Administrator)`;
    payments[pIndex].verifiedAt = new Date().toISOString();
    payments[pIndex].updatedAt = new Date().toISOString();
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
    SupabaseRemote.syncPayment(payments[pIndex]);

    // Update checkpoint
    const bookings = this.getBookings();
    const b = bookings.find(item => item.id === payments[pIndex].bookingId);
    if (b) {
      this.addTrackingCheckpoint({
        bookingId: b.id,
        trackingNumber: b.trackingNumber,
        status: 'Payment Pending',
        location: 'SWIFTDROP Accounts Department',
        notes: `Receipt was rejected by auditor: ${reason}. Please re-upload a clear and valid bank transfer receipt.`,
        recordedBy: `Admin (${adminUsername})`,
      });
    }

    return payments[pIndex];
  },

  // CUSTOMERS
  getCustomers(): Customer[] {
    const raw = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    return raw ? JSON.parse(raw) : [];
  },

  registerOrUpdateCustomer(data: {
    fullName: string;
    email: string;
    phone: string;
    companyName?: string;
    address?: string;
    city?: string;
    state?: string;
    country?: string;
  }, additionalSpent: number = 0): Customer {
    const customers = this.getCustomers();
    const cleanEmail = data.email.trim().toLowerCase();
    const index = customers.findIndex(c => c.email.toLowerCase() === cleanEmail);

    if (index !== -1) {
      customers[index].totalBookings += 1;
      customers[index].totalSpent += additionalSpent;
      customers[index].phone = data.phone || customers[index].phone;
      if (data.address) customers[index].address = data.address;
      if (data.city) customers[index].city = data.city;
      if (data.state) customers[index].state = data.state;
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
      return customers[index];
    } else {
      const newCustomer: Customer = {
        id: `cust-${Date.now()}`,
        fullName: data.fullName,
        email: cleanEmail,
        phone: data.phone,
        companyName: data.companyName,
        address: data.address,
        city: data.city,
        state: data.state,
        country: data.country || 'Nigeria',
        totalBookings: 1,
        totalSpent: additionalSpent,
        createdAt: new Date().toISOString(),
      };
      customers.push(newCustomer);
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
      return newCustomer;
    }
  },

  // WEBSITE SETTINGS
  getWebsiteSettings(): WebsiteSettings {
    const raw = localStorage.getItem(STORAGE_KEYS.WEBSITE_SETTINGS);
    return raw ? JSON.parse(raw) : DEFAULT_WEBSITE_SETTINGS;
  },

  updateWebsiteSettings(settings: Partial<WebsiteSettings>): WebsiteSettings {
    const current = this.getWebsiteSettings();
    const updated = { ...current, ...settings };
    localStorage.setItem(STORAGE_KEYS.WEBSITE_SETTINGS, JSON.stringify(updated));
    return updated;
  },

  // USER / AUTH
  getCurrentUser(): Profile | null {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return raw ? JSON.parse(raw) : null;
  },

  setCurrentUser(user: Profile | null) {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  },

  getAdminSession(): { isAuthenticated: boolean; username: string; loggedInAt: string } | null {
    const raw = localStorage.getItem(STORAGE_KEYS.ADMIN_SESSION);
    return raw ? JSON.parse(raw) : null;
  },

  setAdminSession(session: { isAuthenticated: boolean; username: string } | null) {
    if (session) {
      localStorage.setItem(STORAGE_KEYS.ADMIN_SESSION, JSON.stringify({
        ...session,
        loggedInAt: new Date().toISOString(),
      }));
    } else {
      localStorage.removeItem(STORAGE_KEYS.ADMIN_SESSION);
    }
  },
};
