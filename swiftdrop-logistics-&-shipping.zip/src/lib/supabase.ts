import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Default to user's configured Supabase project details
const rawUrl = import.meta.env.VITE_SUPABASE_URL || 'https://qjoxulzoeksszetkdaun.supabase.co';
const rawKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFqb3h1bHpvZWtzc3pldGtkYXVuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM0Mjk3ODIsImV4cCI6MjEwOTAwNTc4Mn0.sXr7qi7Lh9LYhEJeUNMzqkTniwbDkjKuy27Jvv-qFTk';

// Sanitize URL to ensure standard Supabase base origin (without trailing /rest/v1 or trailing slashes)
export const sanitizeSupabaseUrl = (url: string): string => {
  return url.trim().replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
};

export const SUPABASE_URL = sanitizeSupabaseUrl(rawUrl);
export const SUPABASE_ANON_KEY = rawKey.trim();

export const isSupabaseConfigured = Boolean(
  SUPABASE_URL && 
  SUPABASE_ANON_KEY && 
  SUPABASE_URL.startsWith('http') && 
  !SUPABASE_URL.includes('your-project-id')
);

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    })
  : null;

// Remote database helper functions
export const SupabaseRemote = {
  async testConnection(): Promise<{ ok: boolean; message: string }> {
    if (!supabase) return { ok: false, message: 'Supabase client not initialized' };
    try {
      const { data, error } = await supabase.from('bank_settings').select('*').limit(1);
      if (error && error.code !== 'PGRST116') {
        // Table may not have been created yet or RLS error
        return { ok: true, message: `Connected to Supabase endpoint (${SUPABASE_URL}). Table status: ${error.message}` };
      }
      return { ok: true, message: `Successfully connected to Supabase database (${SUPABASE_URL})!` };
    } catch (err: any) {
      return { ok: false, message: err.message || 'Connection failed' };
    }
  },

  async insertBooking(booking: any) {
    if (!supabase) return;
    try {
      await supabase.from('bookings').upsert({
        id: booking.id,
        tracking_number: booking.trackingNumber,
        customer_name: booking.customerName,
        customer_email: booking.customerEmail,
        customer_phone: booking.customerPhone,
        pickup_country: booking.pickupCountry,
        pickup_state: booking.pickupState,
        pickup_city: booking.pickupCity,
        pickup_address: booking.pickupAddress,
        destination_country: booking.destinationCountry,
        destination_state: booking.destinationState,
        destination_city: booking.destinationCity,
        destination_address: booking.destinationAddress,
        package_description: booking.packageDescription,
        package_category: booking.packageCategory,
        package_weight: booking.packageWeight,
        delivery_type: booking.deliveryType,
        preferred_pickup_date: booking.preferredPickupDate,
        additional_instructions: booking.additionalInstructions,
        total_amount: booking.totalAmount,
        currency: booking.currency || 'NGN',
        booking_status: booking.bookingStatus,
        estimated_delivery_date: booking.estimatedDeliveryDate,
      });
    } catch (e) {
      console.warn('Supabase insertBooking error (handled):', e);
    }
  },

  async updateBookingStatus(id: string, status: string) {
    if (!supabase) return;
    try {
      await supabase.from('bookings').update({ booking_status: status }).eq('id', id);
    } catch (e) {
      console.warn('Supabase updateBookingStatus error (handled):', e);
    }
  },

  async insertTrackingCheckpoint(cp: any) {
    if (!supabase) return;
    try {
      await supabase.from('tracking_history').insert({
        booking_id: cp.bookingId,
        tracking_number: cp.trackingNumber,
        status: cp.status,
        location: cp.location,
        notes: cp.notes,
        recorded_by: cp.recordedBy,
      });
    } catch (e) {
      console.warn('Supabase insertTrackingCheckpoint error (handled):', e);
    }
  },

  async syncBankSettings(settings: any) {
    if (!supabase) return;
    try {
      await supabase.from('bank_settings').upsert({
        bank_name: settings.bankName,
        account_name: settings.accountName,
        account_number: settings.accountNumber,
        sort_code: settings.sortCode,
        instructions: settings.instructions,
        is_active: settings.isActive,
      });
    } catch (e) {
      console.warn('Supabase syncBankSettings error (handled):', e);
    }
  },

  async syncPayment(payment: any) {
    if (!supabase) return;
    try {
      await supabase.from('payments').upsert({
        id: payment.id,
        booking_id: payment.bookingId,
        tracking_number: payment.trackingNumber,
        amount: payment.amount,
        currency: payment.currency,
        bank_name_paid_to: payment.bankNamePaidTo,
        account_number_paid_to: payment.accountNumberPaidTo,
        sender_account_name: payment.senderAccountName,
        sender_bank_name: payment.senderBankName,
        transaction_reference: payment.transactionReference,
        receipt_image_url: payment.receiptImageUrl,
        receipt_filename: payment.receiptFilename,
        payment_status: payment.paymentStatus,
        rejection_reason: payment.rejectionReason,
        verified_by: payment.verifiedBy,
        verified_at: payment.verifiedAt,
      });
    } catch (e) {
      console.warn('Supabase syncPayment error (handled):', e);
    }
  },
};
