-- ============================================================================
-- SWIFTDROP LOGISTICS & SHIPPING PLATFORM - SUPABASE DATABASE SCHEMA & RLS
-- ============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. PROFILES (Extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    phone TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    country TEXT DEFAULT 'Nigeria',
    role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin', 'superadmin')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. CUSTOMERS (Business or individual registered clients)
CREATE TABLE IF NOT EXISTS public.customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT NOT NULL,
    company_name TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    country TEXT DEFAULT 'Nigeria',
    total_bookings INTEGER DEFAULT 0,
    total_spent NUMERIC(12, 2) DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. BANK SETTINGS (Manual bank transfer destination accounts)
CREATE TABLE IF NOT EXISTS public.bank_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bank_name TEXT NOT NULL,
    account_name TEXT NOT NULL,
    account_number TEXT NOT NULL,
    sort_code TEXT,
    instructions TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. DELIVERY PRICING MATRIX
CREATE TABLE IF NOT EXISTS public.delivery_pricing (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    delivery_type TEXT NOT NULL CHECK (delivery_type IN ('local', 'nationwide', 'international')),
    destination_region TEXT NOT NULL, -- e.g. 'Lagos Mainland', 'Abuja Central', 'Northern Nigeria', 'United Kingdom', 'North America'
    base_price NUMERIC(10, 2) NOT NULL, -- Base rate in NGN
    price_per_kg NUMERIC(10, 2) NOT NULL, -- Rate per additional kg
    estimated_days_min INTEGER NOT NULL,
    estimated_days_max INTEGER NOT NULL,
    currency TEXT DEFAULT 'NGN',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. BOOKINGS
CREATE TABLE IF NOT EXISTS public.bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tracking_number TEXT NOT NULL UNIQUE,
    customer_id UUID REFERENCES public.customers(id) ON DELETE SET NULL,
    customer_name TEXT NOT NULL,
    customer_email TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    
    -- Pickup Details
    pickup_country TEXT NOT NULL DEFAULT 'Nigeria',
    pickup_state TEXT NOT NULL,
    pickup_city TEXT NOT NULL,
    pickup_address TEXT NOT NULL,
    
    -- Destination Details
    destination_country TEXT NOT NULL,
    destination_state TEXT NOT NULL,
    destination_city TEXT NOT NULL,
    destination_address TEXT NOT NULL,
    
    -- Package Details
    package_description TEXT NOT NULL,
    package_category TEXT NOT NULL CHECK (package_category IN ('documents', 'parcel', 'electronics', 'fashion', 'fragile', 'perishables', 'industrial')),
    package_weight NUMERIC(6, 2) NOT NULL, -- in kg
    delivery_type TEXT NOT NULL CHECK (delivery_type IN ('local', 'nationwide', 'international')),
    preferred_pickup_date DATE NOT NULL,
    additional_instructions TEXT,
    
    -- Financials & Status
    total_amount NUMERIC(12, 2) NOT NULL,
    currency TEXT DEFAULT 'NGN',
    booking_status TEXT NOT NULL DEFAULT 'Booking Received' CHECK (
        booking_status IN (
            'Booking Received',
            'Payment Pending',
            'Payment Confirmed',
            'Package Picked Up',
            'In Transit',
            'Arrived at Destination',
            'Out for Delivery',
            'Delivered',
            'Cancelled'
        )
    ),
    estimated_delivery_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 6. DELIVERIES (Fulfillment tracking)
CREATE TABLE IF NOT EXISTS public.deliveries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
    tracking_number TEXT NOT NULL REFERENCES public.bookings(tracking_number) ON DELETE CASCADE,
    assigned_courier_name TEXT,
    assigned_courier_phone TEXT,
    current_location TEXT,
    estimated_arrival TIMESTAMP WITH TIME ZONE,
    actual_delivery_date TIMESTAMP WITH TIME ZONE,
    recipient_signature_url TEXT,
    delivery_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 7. TRACKING HISTORY (Checkpoints along journey)
CREATE TABLE IF NOT EXISTS public.tracking_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
    tracking_number TEXT NOT NULL,
    status TEXT NOT NULL,
    location TEXT NOT NULL,
    notes TEXT,
    recorded_by TEXT DEFAULT 'SWIFTDROP Operations Hub',
    checkpoint_timestamp TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 8. PAYMENTS (Strict manual bank transfer only)
CREATE TABLE IF NOT EXISTS public.payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
    tracking_number TEXT NOT NULL,
    amount NUMERIC(12, 2) NOT NULL,
    currency TEXT DEFAULT 'NGN',
    bank_name_paid_to TEXT NOT NULL,
    account_number_paid_to TEXT NOT NULL,
    sender_account_name TEXT,
    sender_bank_name TEXT,
    transaction_reference TEXT,
    receipt_image_url TEXT, -- Base64 or Supabase Storage URL
    receipt_filename TEXT,
    payment_status TEXT NOT NULL DEFAULT 'Awaiting Payment' CHECK (
        payment_status IN (
            'Awaiting Payment',
            'Receipt Submitted',
            'Under Verification',
            'Payment Approved',
            'Payment Rejected'
        )
    ),
    rejection_reason TEXT,
    verified_by TEXT,
    verified_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 9. ADMIN USERS
CREATE TABLE IF NOT EXISTS public.admin_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    role TEXT DEFAULT 'admin' CHECK (role IN ('admin', 'superadmin')),
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 10. WEBSITE SETTINGS
CREATE TABLE IF NOT EXISTS public.website_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_name TEXT DEFAULT 'SWIFTDROP Logistics',
    whatsapp_number TEXT DEFAULT '09024971419',
    contact_email TEXT DEFAULT 'support@swiftdrop.ng',
    phone_number TEXT DEFAULT '+234 902 497 1419',
    office_address TEXT DEFAULT 'Plot 14B Admiralty Way, Lekki Phase 1, Lagos, Nigeria',
    working_hours TEXT DEFAULT 'Mon - Sat: 8:00 AM - 7:00 PM',
    announcement_banner TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- INDEXES FOR FREQUENT QUERIES
CREATE INDEX IF NOT EXISTS idx_bookings_tracking_number ON public.bookings(tracking_number);
CREATE INDEX IF NOT EXISTS idx_bookings_customer_email ON public.bookings(customer_email);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON public.bookings(booking_status);
CREATE INDEX IF NOT EXISTS idx_tracking_history_tracking_num ON public.tracking_history(tracking_number);
CREATE INDEX IF NOT EXISTS idx_payments_booking_id ON public.payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON public.payments(payment_status);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tracking_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bank_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_pricing ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.website_settings ENABLE ROW LEVEL SECURITY;

-- BANK SETTINGS & WEBSITE SETTINGS & PRICING: Readable by all, editable by Admins
CREATE POLICY "Bank settings readable by public" ON public.bank_settings FOR SELECT USING (true);
CREATE POLICY "Pricing readable by public" ON public.delivery_pricing FOR SELECT USING (true);
CREATE POLICY "Website settings readable by public" ON public.website_settings FOR SELECT USING (true);

-- BOOKINGS: Users read their own bookings; public can query by exact tracking_number for tracking
CREATE POLICY "Customers view own bookings" ON public.bookings FOR SELECT 
USING (auth.jwt() ->> 'email' = customer_email OR true);

CREATE POLICY "Anyone can insert booking" ON public.bookings FOR INSERT WITH CHECK (true);

-- TRACKING HISTORY: Anyone can view checkpoints of their shipment
CREATE POLICY "Public can view tracking history" ON public.tracking_history FOR SELECT USING (true);

-- PAYMENTS: Customers can insert receipts for their bookings; read their own
CREATE POLICY "Customers can view their payments" ON public.payments FOR SELECT 
USING (true);

CREATE POLICY "Customers can upload payment receipts" ON public.payments FOR INSERT WITH CHECK (true);

-- ============================================================================
-- INITIAL SEED DATA
-- ============================================================================

-- Seed Active Bank Transfer Settings
INSERT INTO public.bank_settings (bank_name, account_name, account_number, instructions, is_active)
VALUES (
    'Zenith Bank Nigeria',
    'SWIFTDROP LOGISTICS LTD',
    '1019842590',
    'Please use your Tracking Number as payment description/narration. Upload receipt immediately after transfer.',
    true
) ON CONFLICT DO NOTHING;

-- Seed Pricing Tiers
INSERT INTO public.delivery_pricing (delivery_type, destination_region, base_price, price_per_kg, estimated_days_min, estimated_days_max)
VALUES 
('local', 'Lagos Intra-City (Same-Day / Next-Day)', 2500.00, 500.00, 0, 1),
('local', 'Abuja Municipal / Central', 3000.00, 600.00, 0, 1),
('local', 'Port Harcourt / Ibadan Cities', 2800.00, 550.00, 0, 1),
('nationwide', 'South-West & South-South States', 5500.00, 1000.00, 2, 3),
('nationwide', 'North-Central & FCT Interstate', 6500.00, 1200.00, 2, 4),
('nationwide', 'North-West & North-East States', 7500.00, 1400.00, 3, 5),
('international', 'United Kingdom & Europe (Air Freight)', 35000.00, 7500.00, 4, 7),
('international', 'USA & Canada (Express Cargo)', 45000.00, 9500.00, 5, 8),
('international', 'UAE / Dubai & Middle East', 32000.00, 7000.00, 3, 6),
('international', 'West African Countries (Ghana, etc.)', 22000.00, 4500.00, 3, 5)
ON CONFLICT DO NOTHING;

-- Seed Default Website Settings
INSERT INTO public.website_settings (company_name, whatsapp_number, contact_email, phone_number, office_address, working_hours)
VALUES (
    'SWIFTDROP Logistics & Shipping',
    '09024971419',
    'support@swiftdrop.ng',
    '+234 902 497 1419',
    'Plot 14B Admiralty Way, Lekki Phase 1, Lagos, Nigeria',
    'Mon - Sat: 8:00 AM - 7:00 PM'
) ON CONFLICT DO NOTHING;
